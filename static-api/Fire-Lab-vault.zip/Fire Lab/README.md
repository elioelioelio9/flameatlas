---
generated: "Fire Lab knowledge engine"
---
# Fire Lab vault

Generated from the Fire Lab knowledge engine (NASA PSI combustion data, CC0, plus your documents).
Open this folder as an Obsidian vault and use the graph view. Each relationship section states its definition and basis (metadata, text, table, computed, curated, inferred, wikilink). Inferred links are not stated facts.
