---
id: "data:ignition_power_w"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# ignition power w

Measured quantity

## Linked from
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
