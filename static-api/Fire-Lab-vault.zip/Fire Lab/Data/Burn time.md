---
id: "data:burn_time_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Burn time

Duration of burning

## Linked from
- [[ACME CFI-G]] · measures
- [[FLEX]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
