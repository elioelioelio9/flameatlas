---
id: "data:adiabatic_flame_temperature"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Adiabatic flame temperature

ACME

## Linked from
- [[ACME Flame Design]] · measures
- [[ACME CFI-G]] · measures
