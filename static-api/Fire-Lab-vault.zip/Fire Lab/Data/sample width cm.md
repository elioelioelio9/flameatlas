---
id: "data:sample_width_cm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# sample width cm

Measured quantity

## Linked from
- [[SAFFIRE-III]] · measures
- [[BASS-II]] · measures
- [[BASS]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
