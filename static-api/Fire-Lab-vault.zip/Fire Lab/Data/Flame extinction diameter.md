---
id: "data:flame_extinction_diameter"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Flame extinction diameter

FLEX: droplet diameter at visible flame extinction

## Linked from
- [[FLEX]] · measures
