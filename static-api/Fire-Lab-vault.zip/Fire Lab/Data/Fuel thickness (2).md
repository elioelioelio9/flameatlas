---
id: "data:thickness_mm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Fuel thickness

Test condition recorded in PSI tables (mm).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Fuel thickness]] (metadata)

## Linked from
- [[SAFFIRE-III]] · measures
- [[BASS-II]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
