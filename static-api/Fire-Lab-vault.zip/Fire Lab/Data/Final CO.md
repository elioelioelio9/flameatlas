---
id: "data:co_final_ppm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Final CO

BASS-II

## Linked from
- [[BASS-II]] · measures
