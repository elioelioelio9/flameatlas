---
id: "data:habitat-mars_habitat"
type: "data"
tags: ["fire-lab/data"]
source: "Assumption: same candidate exploration atmospheres as above"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — Mars surface habitat

26.0–35.0 % O2, 54.0–72.5 kPa, martian (hypothetical).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “Assumption: same candidate exploration atmospheres as above” (metadata)
- [[Mars]] — “Atmosphere not fixed; partial gravity (0.38 g) not covered by PSI data.” (metadata)

## Linked from
- [[ACME CFI-G]] · contains related data
- [[FLEX]] · contains related data
