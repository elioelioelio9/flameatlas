---
id: "data:habitat-exploration_26"
type: "data"
tags: ["fire-lab/data"]
source: "PSI-20 objective: NASA-considered atmosphere for human space missions"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — Exploration atmosphere 10.2 psia / 26.5 % O2

26.0–27.0 % O2, 68.0–72.5 kPa, microgravity (documented).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “PSI-20 objective: NASA-considered atmosphere for human space missions” (metadata)
- [[International Space Station]] — “Intermediate atmosphere (e.g. vehicles preparing EVAs).” (metadata)
