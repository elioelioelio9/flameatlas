---
id: "data:aging_duration_min"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# aging duration min

Measured quantity

## Linked from
- [[SAME]] · measures
