---
id: "data:sample_length_cm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# sample length cm

Measured quantity

## Linked from
- [[SAFFIRE-III]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
