---
id: "data:sample_diameter_mm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# sample diameter mm

Measured quantity

## Linked from
- [[BASS-II]] · measures
- [[BASS]] · measures
