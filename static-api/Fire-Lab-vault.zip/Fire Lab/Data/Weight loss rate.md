---
id: "data:weight_loss_rate"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Weight loss rate

SAME

## Linked from
- [[SAME]] · measures
