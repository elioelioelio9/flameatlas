---
id: "data:burning_rate_constant"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Burning-rate constant K

FLEX: d²-law burning rate (header unit 'mm' in PSI — verify)

## Linked from
- [[FLEX]] · measures
