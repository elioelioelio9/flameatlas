---
id: "data:o2_final_pct"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Final O2

BASS-II chamber O2 after the test

## Linked from
- [[BASS-II]] · measures
