---
id: "data:primary_mixing_time_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# primary mixing time s

Measured quantity

## Linked from
- [[SAME-R]] · measures
