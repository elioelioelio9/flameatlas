---
id: "data:he_mole_frac"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Helium mole fraction

Test condition recorded in PSI tables (-).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Suppressant diluent]] (metadata)

## Linked from
- [[CFI]] · measures
- [[FLEX]] · measures
