---
id: "data:flames_ignited"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Flames ignited

ACME session tables

## Linked from
- [[ACME CLD Flame]] · measures
- [[ACME E-FIELD Flames]] · measures
- [[ACME s-Flame]] · measures
