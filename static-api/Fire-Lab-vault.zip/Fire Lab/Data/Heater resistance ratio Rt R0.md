---
id: "data:heater_resistance_ratio"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Heater resistance ratio Rt/R0

SAME-R: proxy for heater temperature

## Linked from
- [[SAME-R]] · measures
