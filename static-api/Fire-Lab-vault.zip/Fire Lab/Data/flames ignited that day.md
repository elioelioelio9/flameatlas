---
id: "data:flames_ignited_that_day"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# flames ignited that day

Measured quantity

## Linked from
- [[ACME BRE]] · measures
