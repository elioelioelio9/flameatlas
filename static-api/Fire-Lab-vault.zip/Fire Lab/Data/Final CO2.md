---
id: "data:co2_final_pct"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Final CO2

BASS-II

## Linked from
- [[BASS-II]] · measures
