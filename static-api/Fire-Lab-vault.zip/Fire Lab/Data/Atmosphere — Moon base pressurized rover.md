---
id: "data:habitat-lunar_base"
type: "data"
tags: ["fire-lab/data"]
source: "Challenge statement (https://www.spaceappschallenge.org/2026/challenges/flame-in-freefall/): likely \u226530 % O2 at \u226410.2 psi"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — Moon base / pressurized rover

30.0–35.0 % O2, 54.0–70.3 kPa, lunar (planning_assumption).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “Challenge statement (https://www.spaceappschallenge.org/2026/challenges/flame-in-freefall/): likely ≥30 % O2 at ≤10.2 psi” (metadata)
- [[Moon]] — “Partial gravity: no PSI combustion data yet (LUCI, FM2 planned). Microgravity and 1-g results bound it.” (metadata)

## Linked from
- [[ACME CFI-G]] · contains related data
