---
id: "data:co_initial_ppm"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# co initial ppm

Measured quantity

## Linked from
- [[BASS-II]] · measures
