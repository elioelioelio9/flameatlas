---
id: "data:peak_burner_temperature_c"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# peak burner temperature c

Measured quantity

## Linked from
- [[ACME CFI-G]] · measures
