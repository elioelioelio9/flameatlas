---
id: "data:flow_cm_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Flow velocity

Test condition recorded in PSI tables (cm/s).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Forced flow]] (metadata)

## Linked from
- [[SAFFIRE-III]] · measures
- [[SAME-R]] · measures
- [[SAME]] · measures
- [[SPICE]] · measures
- [[ACME BRE]] · measures
- [[BASS-II]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
