---
id: "data:droplet_initial_diameter"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Initial droplet diameter

FLEX

## Linked from
- [[FLEX]] · measures
