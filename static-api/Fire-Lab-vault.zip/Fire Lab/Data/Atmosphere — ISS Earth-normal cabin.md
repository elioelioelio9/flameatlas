---
id: "data:habitat-iss"
type: "data"
tags: ["fire-lab/data"]
source: "PSI-20 objective (14.7 psia, 21 % O2 listed as a NASA-considered atmosphere)"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — ISS / Earth-normal cabin

20.5–21.5 % O2, 97.0–103.0 kPa, microgravity (documented).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “PSI-20 objective (14.7 psia, 21 % O2 listed as a NASA-considered atmosphere)” (metadata)
- [[International Space Station]] — “Sea-level-like atmosphere.” (metadata)

## Linked from
- [[ACME Flame Design]] · contains related data
- [[ACME CFI-G]] · contains related data
- [[CFI]] · contains related data
- [[FLEX]] · contains related data
