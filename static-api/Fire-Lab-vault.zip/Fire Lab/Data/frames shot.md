---
id: "data:frames_shot"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# frames shot

Measured quantity

## Linked from
- [[BASS-II]] · measures
