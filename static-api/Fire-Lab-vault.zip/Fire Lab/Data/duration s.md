---
id: "data:duration_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# duration s

Measured quantity

## Linked from
- [[SAME-R]] · measures
