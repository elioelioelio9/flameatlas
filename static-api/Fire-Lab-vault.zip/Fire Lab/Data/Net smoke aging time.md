---
id: "data:net_aging_time_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Net smoke aging time

SAME-R

## Linked from
- [[SAME-R]] · measures
