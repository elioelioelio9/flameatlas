---
id: "data:burner_diameter"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# burner diameter

Measured quantity

## Linked from
- [[ACME BRE]] · measures
