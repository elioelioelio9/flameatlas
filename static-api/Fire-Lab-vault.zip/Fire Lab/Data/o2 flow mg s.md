---
id: "data:o2_flow_mg_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# o2 flow mg s

Measured quantity

## Linked from
- [[ACME Flame Design]] · measures
- [[ACME CFI-G]] · measures
