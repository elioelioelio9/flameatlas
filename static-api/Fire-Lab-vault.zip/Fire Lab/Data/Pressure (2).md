---
id: "data:pressure_kpa"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Pressure

Test condition recorded in PSI tables (kPa).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Pressure]] (metadata)

## Linked from
- [[ACME Flame Design]] · measures
- [[ACME CFI-G]] · measures
- [[CFI]] · measures
- [[FLEX]] · measures
