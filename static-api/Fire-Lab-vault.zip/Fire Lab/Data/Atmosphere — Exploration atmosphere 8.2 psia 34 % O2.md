---
id: "data:habitat-exploration_34"
type: "data"
tags: ["fire-lab/data"]
source: "PSI-20 objective: NASA-considered atmosphere for human space missions"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — Exploration atmosphere 8.2 psia / 34 % O2

33.0–35.0 % O2, 54.0–59.0 kPa, microgravity (documented).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “PSI-20 objective: NASA-considered atmosphere for human space missions” (metadata)
- [[International Space Station]] — “Reduces EVA pre-breathe time; markedly higher O2 mole fraction than Earth.” (metadata)
