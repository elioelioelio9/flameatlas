---
id: "data:primary_aging_time_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# primary aging time s

Measured quantity

## Linked from
- [[SAME-R]] · measures
