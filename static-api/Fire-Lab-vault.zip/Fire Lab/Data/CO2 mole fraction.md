---
id: "data:co2_mole_frac"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# CO2 mole fraction

Test condition recorded in PSI tables (-).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Suppressant diluent]] (metadata)

## Linked from
- [[FLEX]] · measures
