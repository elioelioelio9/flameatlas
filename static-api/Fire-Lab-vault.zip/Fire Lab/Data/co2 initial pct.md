---
id: "data:co2_initial_pct"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# co2 initial pct

Measured quantity

## Linked from
- [[BASS-II]] · measures
