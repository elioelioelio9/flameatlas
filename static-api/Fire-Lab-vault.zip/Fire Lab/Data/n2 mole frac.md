---
id: "data:n2_mole_frac"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# n2 mole frac

Measured quantity

## Linked from
- [[CFI]] · measures
- [[FLEX]] · measures
