---
id: "data:stoichiometric_mixture_fraction"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Zst

ACME

## Linked from
- [[ACME Flame Design]] · measures
- [[ACME CFI-G]] · measures
