---
id: "data:ignition_time_s"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# ignition time s

Measured quantity

## Linked from
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
