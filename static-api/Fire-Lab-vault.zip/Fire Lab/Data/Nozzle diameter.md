---
id: "data:nozzle_diameter"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# Nozzle diameter

SPICE

## Linked from
- [[SPICE]] · measures
