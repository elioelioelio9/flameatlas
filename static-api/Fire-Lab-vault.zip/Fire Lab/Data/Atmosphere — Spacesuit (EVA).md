---
id: "data:habitat-eva_suit"
type: "data"
tags: ["fire-lab/data"]
source: "Challenge statement (https://www.spaceappschallenge.org/2026/challenges/flame-in-freefall/): 100 % O2 at 4.3 psi"
generated: "Fire Lab knowledge engine"
---

# Atmosphere — Spacesuit (EVA)

99.0–100.0 % O2, 28.0–31.0 kPa, microgravity (documented).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Spacecraft atmosphere]] — “Challenge statement (https://www.spaceappschallenge.org/2026/challenges/flame-in-freefall/): 100 % O2 at 4.3 psi” (metadata)
- [[International Space Station]] — “Pure oxygen: far outside every PSI combustion test atmosphere.” (metadata)
