---
id: "data:o2_mole_frac"
type: "data"
tags: ["fire-lab/data"]
generated: "Fire Lab knowledge engine"
---

# O2 mole fraction

Test condition recorded in PSI tables (-).

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Oxygen concentration]] (metadata)

## Linked from
- [[ACME Flame Design]] · measures
- [[ACME CFI-G]] · measures
- [[ACME BRE]] · measures
- [[ACME s-Flame]] · measures
- [[BASS-II]] · measures
- [[CFI]] · measures
- [[FLEX]] · measures
- [[SAFFIRE-I]] · measures
- [[SAFFIRE-II]] · measures
