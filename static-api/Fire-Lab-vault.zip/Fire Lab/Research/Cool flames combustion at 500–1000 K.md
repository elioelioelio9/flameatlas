---
id: "research:cool-flames-low-temperature"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Cool flames: combustion at 500–1000 K

Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “…lames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)
- [[Diffusion flame]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in micro…” (text)
- [[Droplet combustion]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)
- [[Cool flame]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)
- [[Temperature]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)

## Linked from
- [[ACME CFI-G]] · supports
- [[CFI]] · supports
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · supports
