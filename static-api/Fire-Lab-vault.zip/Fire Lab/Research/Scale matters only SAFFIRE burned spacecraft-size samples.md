---
id: "research:saffire-large-scale"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Scale matters: only SAFFIRE burned spacecraft-size samples

SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the only realistic-scale fire data in PSI.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the onl” (text)
- [[Suppressant diluent]] — “SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the onl” (text)
- [[Temperature]] — “SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the onl” (text)

## Linked from
- [[SAFFIRE-I]] · supports
- [[SAFFIRE-III]] · supports
