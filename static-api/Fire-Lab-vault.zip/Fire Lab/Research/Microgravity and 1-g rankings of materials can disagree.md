---
id: "research:saffire2-ug-vs-1g"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Microgravity and 1-g rankings of materials can disagree

In SAFFIRE-II, 4 of 4 silicone samples (0.27–1.03 mm) had a burn length of about 0 in microgravity at 20 cm/s, while 2 of the 4 matching 1-g reference burns were complete. Flames did spread in microgravity over: PMMA, SIBAL (cotton-fiberglass fabric).

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “…f about 0 in microgravity at 20 cm/s, while 2 of the 4 matching 1-g reference burns were complete. Flames did spread in microgravity over: PMMA, SIBAL (cotton-” (text)
- [[Microgravity]] — “In SAFFIRE-II, 4 of 4 silicone samples (0.27–1.03 mm) had a burn length of about 0 in microgravity at 20 cm/s, while 2 of the 4 matching 1-g reference burns wer” (text)

## Contradicts
_The source reports a result opposing the target statement (curated, with the passage)._

- [[Material flammability]] — “In SAFFIRE-II, 4 of 4 silicone samples (0.27–1.03 mm) had a burn length of about 0 in microgravity at 20 cm/s, while 2 of the 4 matching 1-g reference burns wer” (curated)

## Linked from
- [[SAFFIRE-II]] · supports
