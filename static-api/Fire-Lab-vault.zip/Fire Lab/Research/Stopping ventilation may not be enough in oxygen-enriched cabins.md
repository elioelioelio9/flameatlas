---
id: "research:bre-elevated-o2-no-flow"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Stopping ventilation may not be enough in oxygen-enriched cabins

In quiescent microgravity, BRE flames emulating condensed materials (e.g. PMMA, nylon) kept burning quasi-steadily in the elevated-oxygen atmospheres considered for future spacecraft, whereas comparable flames at 21 % O2 self-extinguished in a short time. PSI describes these results as preliminary.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Oxygen concentration]] — “…steadily in the elevated-oxygen atmospheres considered for future spacecraft, whereas comparable flames at 21 % O2 self-extinguished in a short time. PSI descr” (text)
- [[Forced flow]] — “In quiescent microgravity, BRE flames emulating condensed materials (e.g. PMMA, nylon) kept burning quasi-steadily in the elevated-oxygen atmospheres considered” (text)
- [[Microgravity]] — “In quiescent microgravity, BRE flames emulating condensed materials (e.g. PMMA, nylon) kept burning quasi-steadily in the elevated-oxyg…” (text)

## Linked from
- [[ACME BRE]] · supports
