---
id: "research:daft-dust-vs-smoke"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Dust can look like smoke to a particle counter

DAFT showed that a modified commercial particle counter could be used in microgravity, measuring a test dust aerosol released on the ISS.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “DAFT showed that a modified commercial particle counter could be used in microgravity, measuring a test dust aerosol released on the ISS.” (text)
- [[Smoke]] — “DAFT showed that a modified commercial particle counter could be used in microgravity, measuring a test dust aerosol released on the ISS.” (text)
- [[Particle size]] — “DAFT showed that a modified commercial particle counter could be used in microgravity, measuring a test dust aerosol released on the ISS.” (text)

## Linked from
- [[DAFT DAFT-2]] · supports
