---
id: "research:flex-diluents"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# FLEX compares CO2 and helium as gaseous suppressants

At 21 % O2, share of FLEX tests ending in flame extinction before burnout by atmosphere — N2 only: 14/29; CO2: 13/18; He: 7/7. FLEX varied CO2 up to 0.7 and He up to 0.45 mole fraction.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “At 21 % O2, share of FLEX tests ending in flame extinction before burnout by atmosphere — N2 only: 14/29; CO2: 13/18; He: 7/7. FLEX varied CO2 up to 0.7 and He” (text)
- [[Oxygen concentration]] — “At 21 % O2, share of FLEX tests ending in flame extinction before burnout by atmosphere — N2 only: 14/29; CO2: 13/18; He…” (text)
- [[Suppressant diluent]] — “At 21 % O2, share of FLEX tests ending in flame extinction before burnout by atmosphere — N2 only: 14/29; CO2: 13/18; He: 7/7. FLEX varied CO2 up to 0.7 and He” (text)

## Linked from
- [[FLEX]] · supports
