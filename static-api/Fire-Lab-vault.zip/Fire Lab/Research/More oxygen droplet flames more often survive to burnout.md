---
id: "research:flex-o2-burnout"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# More oxygen: droplet flames more often survive to burnout

FLEX droplet tests in N2-only atmospheres that ended in flame extinction before burnout — Heptane: 5/17 at 21 % O2 vs 0/11 at 30–34 % O2; Methanol: 9/12 at 21 % O2 vs 2/13 at 30–34 % O2. Remaining tests ended in burnout ('completion') or droplet disruption.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “FLEX droplet tests in N2-only atmospheres that ended in flame extinction before burnout — Heptane: 5/17 at 21 % O2 vs 0/11 at 30–34 % O2; Methanol: 9/12 at 21 %” (text)
- [[Oxygen concentration]] — “FLEX droplet tests in N2-only atmospheres that ended in flame extinction before burnout — Heptane: 5/17 at 21 % O2 vs 0/11 at 30–34 % O2; Methanol: 9/12 at 21 %” (text)
- [[Droplet combustion]] — “FLEX droplet tests in N2-only atmospheres that ended in flame extinction before burnout — Heptane: 5/17 at 21 % O2 vs 0/11…” (text)

## Linked from
- [[FLEX]] · supports
