---
id: "research:bass2-reduced-o2"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# BASS-II maps solid-fuel burning down to 13.6 % O2

BASS-II ran 129 tests with initial O2 between 13.6 and 22.2 % vol, mostly on PMMA, SIBAL (cotton-fiberglass fabric), Nomex. Flow annotations record extinction in 15 tests, blow-off in 3 and no ignition in 1.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “…between 13.6 and 22.2 % vol, mostly on PMMA, SIBAL (cotton-fiberglass fabric), Nomex. Flow annotations record extinction in 15 tests, blow-off in 3 and no igni” (text)
- [[Ignition]] — “…SIBAL (cotton-fiberglass fabric), Nomex. Flow annotations record extinction in 15 tests, blow-off in 3 and no ignition in 1.” (text)
- [[Oxygen concentration]] — “BASS-II ran 129 tests with initial O2 between 13.6 and 22.2 % vol, mostly on PMMA, SIBAL (cotton-fiberglass fabric), Nomex. Flow annotations record extinction i” (text)

## Linked from
- [[BASS-II]] · supports
