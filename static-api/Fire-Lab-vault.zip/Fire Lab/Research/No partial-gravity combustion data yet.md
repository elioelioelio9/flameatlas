---
id: "research:partial-gravity-gap"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# No partial-gravity combustion data yet

PSI currently holds no combustion data at lunar or martian gravity. The challenge notes that microgravity and normal-gravity results can bound intermediate gravity levels, and that E-FIELD (PSI-22) mimicked partial gravity with ion-driven forces.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “PSI currently holds no combustion data at lunar or martian gravity. The challenge notes that microgravity and normal-gravity results can bound intermediate grav” (text)
- [[Partial gravity]] — “…ogravity and normal-gravity results can bound intermediate gravity levels, and that E-FIELD (PSI-22) mimicked partial gravity with ion-driven forces.” (text)
- [[Electric field]] — “…challenge notes that microgravity and normal-gravity results can bound intermediate gravity levels, and that E-FIELD (PSI-22) mimicked partial gravity with ion” (text)

## Linked from
- [[ACME E-FIELD Flames]] · supports
