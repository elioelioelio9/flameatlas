---
id: "research:bass-1g-screening-gap"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# 1-g material screening is not automatically conservative

Spacecraft material selection relies on NASA-STD-6001 Test 1, which ranks materials by 1-g behaviour. BASS and BASS-II were built on the hypothesis that, with adequate ventilation, materials burn as well if not better in microgravity than in normal gravity.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Forced flow]] — “…1, which ranks materials by 1-g behaviour. BASS and BASS-II were built on the hypothesis that, with adequate ventilation, materials burn as well if not better” (text)
- [[Microgravity]] — “…BASS-II were built on the hypothesis that, with adequate ventilation, materials burn as well if not better in microgravity than in normal gravity.” (text)
- [[Material flammability]] — “Spacecraft material selection relies on NASA-STD-6001 Test 1, which ranks materials by 1-g behaviour. BASS and BASS-II were built on the hypothesis that, with a” (text)

## Linked from
- [[BASS]] · supports
- [[BASS-II]] · supports
