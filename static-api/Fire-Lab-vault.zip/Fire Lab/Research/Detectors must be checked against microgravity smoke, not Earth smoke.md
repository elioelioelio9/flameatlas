---
id: "research:same-smoke-particles"
type: "research"
tags: ["fire-lab/research"]
generated: "Fire Lab knowledge engine"
---

# Detectors must be checked against microgravity smoke, not Earth smoke

SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide quantitative data on detector sensitivity to reduced-gravity smoke.

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)
- [[Microgravity]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)
- [[Smoke]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)
- [[Particle size]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)
- [[Smoke detection]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)

## Linked from
- [[SAME]] · supports
- [[SAME-R]] · supports
