---
id: "concept:spacecraft-atmosphere"
type: "concept"
aliases: ["spacecraft atmosphere", "exploration atmosphere", "cabin atmosphere", "habitat atmosphere", "8.2 psia", "10.2 psia", "14.7 psia"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Spacecraft atmosphere

Pressure and composition of crewed-cabin air.

## Linked from
- [[ACME BRE]] · mentions
- [[Atmosphere — ISS Earth-normal cabin]] · contains related data
- [[Atmosphere — Exploration atmosphere 10.2 psia 26.5 % O2]] · contains related data
- [[Atmosphere — Exploration atmosphere 8.2 psia 34 % O2]] · contains related data
- [[Atmosphere — Moon base pressurized rover]] · contains related data
- [[Atmosphere — Mars surface habitat]] · contains related data
- [[Atmosphere — Spacesuit (EVA)]] · contains related data
