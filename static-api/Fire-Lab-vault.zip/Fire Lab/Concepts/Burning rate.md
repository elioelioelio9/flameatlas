---
id: "concept:burning-rate"
type: "concept"
aliases: ["burning rate", "burn rate", "mass loss rate", "regression rate", "burning rate constant", "vitesse de combustion"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Burning rate

Rate at which fuel is consumed.

## Linked from
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME BRE]] · mentions
- [[ACME s-Flame]] · mentions
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates (2)]] · mentions
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · mentions
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates]] · mentions
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure (2)]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in  (2)]] · mentions
- [[Experimental Investigation of Liquid and Gas Fueled Flames Towards the Development of a Burning Rate Emulator ]] · mentions
- [[A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity]] · mentions
- [[Stabilization mechanisms and burning rates of cylindrical burner flames]] · mentions
