---
id: "concept:fuel-thickness"
type: "concept"
aliases: ["thickness", "thick fuel", "thin fuel", "\u00e9paisseur"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Fuel thickness

Sample thickness, which controls thermal behaviour of solids.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[STDCE-1]] · mentions
- [[A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spr]] · mentions
- [[Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment]] · mentions
- [[Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow]] · mentions
- [[A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin F]] · mentions
- [[Fuel thickness (2)]] · contains related data
