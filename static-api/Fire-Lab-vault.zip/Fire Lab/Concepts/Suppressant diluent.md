---
id: "concept:suppressant"
type: "concept"
aliases: ["suppressant", "suppression", "diluent", "dilution", "inert", "helium", "co2", "carbon dioxide", "nitrogen", "extinguisher", "extincteur", "water mist"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Suppressant / diluent

Agents that weaken or extinguish a flame.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[STDCE-1]] · mentions
- [[Temperature and CO2 fields of a downward spreading flame over thin cellulose A comparison of experimental and ]] · mentions
- [[Results from on-board CSA-CP and CDM Sensor Readings during the Burning and Suppression of Solids - II (BASS-I]] · mentions
- [[Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems (2)]] · mentions
- [[Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity]] · mentions
- [[Methanol Droplet Extinction in Oxygen Carbon-dioxide Nitrogen Mixtures in Microgravity Results from the Intern]] · mentions
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets ]] · mentions
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments]] · mentions
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · mentions
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY]] · mentions
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity (2)]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets  (2)]] · mentions
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments (2)]] · mentions
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity (2)]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in  (2)]] · mentions
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments (2)]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY (2)]] · mentions
- [[Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity]] · mentions
- [[Dilution effects on laminar jet diffusion flame lengths]] · mentions
- [[Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution]] · mentions
- [[Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames A computational and exper]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (2)]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (3)]] · mentions
- [[Effects of Fuel Dilution and Gravity on Laminar Coflow Methane-Air Diffusion Flames A Computational and Experi]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems]] · mentions
- [[Oscillatory thermocapillary flows in open cylindrical containers induced by CO2 laser heating]] · mentions
- [[CO2 mole fraction]] · contains related data
- [[Helium mole fraction]] · contains related data
- [[Scale matters only SAFFIRE burned spacecraft-size samples]] · mentions
- [[FLEX compares CO2 and helium as gaseous suppressants]] · mentions
