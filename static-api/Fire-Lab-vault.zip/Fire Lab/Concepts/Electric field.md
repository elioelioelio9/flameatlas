---
id: "concept:electric-field"
type: "concept"
aliases: ["electric field", "e-field", "electric-field", "ions", "ionic wind", "champ \u00e9lectrique"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Electric field

Electric fields acting on charged species in a flame.

## Linked from
- [[ACME E-FIELD Flames]] · mentions
- [[Ion Current and Flame Changes with Electric Fields in Microgravity]] · mentions
- [[Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface]] · mentions
- [[The Influence of Electric Field Power Systems on Flame Behavior]] · mentions
- [[Modelling electric field driven convection in small combustion plasmas and surrounding gases]] · mentions
- [[Detailed characterization of DC electric field effects on small non-premixed flames]] · mentions
- [[Ion current and carbon monoxide release from an impinging methane air coflow flame in an electric field]] · mentions
- [[Electric field-controlled mesoscale burners]] · mentions
- [[Using large electric fields to control transport in microgravity.]] · mentions
- [[Inducing gas flow and swirl in tubes using ionic wind from corona discharges]] · mentions
- [[Electric-field effects on methane coflow flames aboard the international space station (ISS) ACME E-FIELD flam]] · mentions
- [[No partial-gravity combustion data yet]] · mentions
