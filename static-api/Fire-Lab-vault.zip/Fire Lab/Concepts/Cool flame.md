---
id: "concept:cool-flame"
type: "concept"
aliases: ["cool flame", "cool-flame", "low temperature combustion", "low-temperature chemistry", "flamme froide"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Cool flame

Low-temperature chemical reaction zone that can persist after hot-flame extinction.

## Linked from
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME s-Flame]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion (2)]] · mentions
- [[Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames (2)]] · mentions
- [[Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry (2)]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (3)]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (3)]] · mentions
- [[Can cool flames support quasi-steady alkane droplet burning (3)]] · mentions
- [[Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet combustion in elevated pressure micro]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion]] · mentions
- [[Can cool flames support quasi-steady alkane droplet burning]] · mentions
- [[Cool-flame dodecane-droplet extinction diameters]] · mentions
- [[Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction]] · mentions
- [[Can cool flames support quasi-steady alkane droplet burning (2)]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (2)]] · mentions
- [[Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (2)]] · mentions
- [[Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry]] · mentions
- [[Science in Short Cool Flames]] · mentions
- [[Initiation and propagation of laminar premixed cool flames]] · mentions
- [[Extended flammability limits of n-heptane air mixtures with cool flames]] · mentions
- [[Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air]] · mentions
- [[Initial diameter effects on combustion of unsupported equi-volume n-heptane iso-octane mixture droplets and th]] · mentions
- [[Oscillatory cool flame combustion behavior of submillimeter sized n-alkane droplet under near limit conditions]] · mentions
- [[Cool Flame Combustion of Sub-Millimeter Sized Higher n-Alkane Droplets at Atmospheric Condition (2017)]] · mentions
- [[Non-Premixed - Partially Premixed to Diffusive Burning Initial Transient of Direct Cool Flame Burn (2017)]] · mentions
- [[Oscillatory Cool Flame Combustion Behavior of Submillimeter Sized n-Alkane Droplet under Near Limit Conditions (2)]] · mentions
- [[Dynamics of cool flames (2019)]] · mentions
- [[Dynamics of cool flames]] · mentions
- [[The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alka]] · mentions
- [[On the propagation limits and speeds of premixed cool flames at elevated pressures]] · mentions
- [[SUPPLEMENTARY MATERIAL The radical index and the effect of oxygen concentration on non-premixed cool flame ext]] · mentions
- [[Cool flames combustion at 500–1000 K]] · mentions
