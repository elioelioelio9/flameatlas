---
id: "concept:smoldering"
type: "concept"
aliases: ["smolder", "smoldering", "smoulder", "smouldering", "couvant"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Smoldering

Slow, flameless surface combustion.

## Linked from
- [[SAME-R]] · mentions
- [[SAME]] · mentions
