---
id: "concept:material-flammability"
type: "concept"
aliases: ["flammability", "flammable", "inflammabilit\u00e9", "material screening", "nasa-std-6001", "std-6001", "upward flammability", "flammability limit"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Material flammability

Whether and how a material burns in given conditions.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME s-Flame]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Simplified model for predicting difference between flammability limits of a thin material in normal gravity an]] · mentions
- [[Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment]] · mentions
- [[Microgravity flammability boundary for PMMA rods in axial stagnation flow Experimental results and energy bala]] · mentions
- [[Microgravity Flammability of PMMA Rods in Concurrent Flow]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)]] · mentions
- [[Fire safety in space – beyond flammability testing of small samples]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire), ]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire),  (2)]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets ]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets  (2)]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY (2)]] · mentions
- [[Flammability maps for microgravity burning of a small flat material in a quiescent ambient]] · mentions
- [[Extinction mechanisms of near-limit premixed flames and extended limits of flammability]] · mentions
- [[Extended flammability limits of n-heptane air mixtures with cool flames]] · mentions
- [[Microgravity flammability boundary for PMMA rods in axial stagnation flow Experimental results and energy bala (2)]] · mentions
- [[Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using de]] · mentions
- [[1-g material screening is not automatically conservative]] · mentions
- [[Microgravity and 1-g rankings of materials can disagree]] · contradicts
