---
id: "concept:extinction"
type: "concept"
aliases: ["extinction", "extinguish", "extinguishment", "self-extinguish", "quench", "blowoff", "blow-off", "auto-extinction", "\u00e9teindre", "eteindre", "\u00e9teint"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Extinction

The flame going out, by starvation, cooling, dilution or strain.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread Results of Experiments]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow i]] · mentions
- [[Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits]] · mentions
- [[Methanol Droplet Extinction in Oxygen Carbon-dioxide Nitrogen Mixtures in Microgravity Results from the Intern]] · mentions
- [[A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions]] · mentions
- [[Activation energy asymptotics for methanol droplet extinction in microgravity]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (3)]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (3)]] · mentions
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st (2)]] · mentions
- [[Experiments on Submillimeter Free Droplet Flame Extinction]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets]] · mentions
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st]] · mentions
- [[Experiments on Submillimeter Free Droplet Flame Extinction (2)]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in  (2)]] · mentions
- [[Cool-flame dodecane-droplet extinction diameters]] · mentions
- [[Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction]] · mentions
- [[Radiative extinction of burner-supported spherical diffusion flames A scaling analysis]] · mentions
- [[Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (2)]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (2)]] · mentions
- [[The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames]] · mentions
- [[Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffus]] · mentions
- [[Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surfa]] · mentions
- [[Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames]] · mentions
- [[Radiative extinction of gaseous spherical diffusion flames in microgravity]] · mentions
- [[The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spheri]] · mentions
- [[Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion]] · mentions
- [[Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames]] · mentions
- [[Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity A Computational S]] · mentions
- [[Analysis of extinction and sustained ignition]] · mentions
- [[Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner]] · mentions
- [[Extinction mechanisms of near-limit premixed flames and extended limits of flammability]] · mentions
- [[Oscillatory extinction of spherical diffusion flames Micro-buoyancy experiment and computation]] · mentions
- [[Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity]] · mentions
- [[Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air]] · mentions
- [[The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alka]] · mentions
- [[Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction]] · mentions
- [[SUPPLEMENTARY MATERIAL The radical index and the effect of oxygen concentration on non-premixed cool flame ext]] · mentions
- [[More oxygen droplet flames more often survive to burnout]] · mentions
- [[FLEX compares CO2 and helium as gaseous suppressants]] · mentions
- [[BASS-II maps solid-fuel burning down to 13.6 % O2]] · mentions
