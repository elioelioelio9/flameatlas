---
id: "concept:smoke"
type: "concept"
aliases: ["smoke", "fum\u00e9e", "fumee", "aerosol", "a\u00e9rosol", "pyrolysis products"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Smoke

Airborne products of combustion or pyrolysis.

## Linked from
- [[SAFFIRE-I]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[ACME BRE]] · mentions
- [[SPICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Smoke Aerosol Measurement Experiment-2 Comparison of Flight Experiment Results with Ground Test Results]] · mentions
- [[Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2]] · mentions
- [[Preliminary Results from the Smoke Aerosol Measurement Experiment - Reflight]] · mentions
- [[Detection of Smoke from Microgravity Fires (2)]] · mentions
- [[Evaluation of spacecraft smoke detector performance in the low-gravity environment]] · mentions
- [[Measurement of Smoke Particle Size under Low-Gravity Conditions]] · mentions
- [[Properties of Smoke from Overheated Spacecraft Materials in Low-Gravity]] · mentions
- [[Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design]] · mentions
- [[Spacecraft Fire Detection Smoke Properties and Transport in Low-Gravity]] · mentions
- [[ISS Destiny Laboratory Smoke Detection Model]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection, Seventh International Microgravity ]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Characterization of Nuisance Particulates in the ISS Space Smoke Aerosols and Lunar Dust Abatement]] · mentions
- [[Detection of Smoke from Microgravity Fires (3)]] · mentions
- [[Pyrolysis Smoke Generated Under Low-Gravity Conditions]] · mentions
- [[Smoke Characterization and Feasibility of the Moment Method for Spacecraft Fire Detection]] · mentions
- [[Evaluation of spacecraft smoke detector performance in the low-gravity environment (2)]] · mentions
- [[Laminar Smoke Points in Coflow Measured Aboard the International Space Station]] · mentions
- [[Smoke Points of Microgravity and Normal Gravity Coflow Diffusion]] · mentions
- [[Laminar smoke points of coflowing flames in microgravity]] · mentions
- [[Detection of Smoke from Microgravity Fires]] · mentions
- [[Detectors must be checked against microgravity smoke, not Earth smoke]] · mentions
- [[Dust can look like smoke to a particle counter]] · mentions
