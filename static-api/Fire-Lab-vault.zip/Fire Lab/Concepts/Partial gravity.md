---
id: "concept:partial-gravity"
type: "concept"
aliases: ["partial gravity", "lunar gravity", "martian gravity", "fractional gravity", "gravit\u00e9 partielle"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Partial gravity

Gravity levels between orbit and Earth (Moon 0.17 g, Mars 0.38 g).

## Linked from
- [[ACME E-FIELD Flames]] · mentions
- [[No partial-gravity combustion data yet]] · mentions
