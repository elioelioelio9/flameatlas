---
id: "concept:modeling"
type: "concept"
aliases: ["modeling", "modelling", "numerical model", "numerical simulation", "computational", "cfd", "mod\u00e9lisation"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Numerical modeling

Computational models of combustion.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[STDCE-1]] · mentions
- [[OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread Results of Experiments]] · mentions
- [[Temperature and CO2 fields of a downward spreading flame over thin cellulose A comparison of experimental and ]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments (2)]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced  (2)]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St (2)]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model (2)]] · mentions
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical (2)]] · mentions
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity]] · mentions
- [[Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle ]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced ]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model]] · mentions
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical]] · mentions
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity (2)]] · mentions
- [[Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle  (2)]] · mentions
- [[Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity A Computational S]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions]] · mentions
- [[Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames A computational and exper]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (2)]] · mentions
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal ]] · mentions
- [[A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot grow]] · mentions
- [[Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames]] · mentions
- [[Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame]] · mentions
- [[Modelling electric field driven convection in small combustion plasmas and surrounding gases]] · mentions
- [[Numerical simulation of a tubular ion-driven wind generator]] · mentions
- [[Modeling of Elevated Pressure Diffusion Flames with Water Addition]] · mentions
- [[Development of Comprehensive Detailed and Reduced Reaction Mechanisms for Combustion Modeling]] · mentions
- [[Response of spherical diffusion flames subjected to rotation Microgravity experimentation and computational si]] · mentions
- [[Direct Numerical Simulation of turbulent nonpremixed “cool” flames Applicability of flamelet models]] · mentions
- [[Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (3)]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2)]] · mentions
- [[Effects of Fuel Dilution and Gravity on Laminar Coflow Methane-Air Diffusion Flames A Computational and Experi]] · mentions
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal  (2)]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (3)]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2022)]] · mentions
- [[Initial diameter effects on combustion of unsupported equi-volume n-heptane iso-octane mixture droplets and th]] · mentions
- [[Counterflow flame experiments and chemical kinetic modeling of dimethyl ether methane mixtures]] · mentions
