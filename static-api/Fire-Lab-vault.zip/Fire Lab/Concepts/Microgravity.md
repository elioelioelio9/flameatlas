---
id: "concept:microgravity"
type: "concept"
aliases: ["microgravity", "micro-gravity", "reduced gravity", "low gravity", "weightless", "microgravit\u00e9", "zero-g"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Microgravity

Free-fall environment where buoyancy is negligible.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[STDCE-1]] · mentions
- [[The Microgravity Science Glovebox as a Platform for Exploration Research on the International Space Station]] · mentions
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal (2)]] · mentions
- [[Simplified model for predicting difference between flammability limits of a thin material in normal gravity an]] · mentions
- [[Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment]] · mentions
- [[Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment]] · mentions
- [[Microgravity flammability boundary for PMMA rods in axial stagnation flow Experimental results and energy bala]] · mentions
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Results from on-board CSA-CP and CDM Sensor Readings during the Burning and Suppression of Solids - II (BASS-I]] · mentions
- [[Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow]] · mentions
- [[Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow i]] · mentions
- [[Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow i]] · mentions
- [[A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin F]] · mentions
- [[Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits]] · mentions
- [[Fire in Microgravity]] · mentions
- [[Microgravity Flammability of PMMA Rods in Concurrent Flow]] · mentions
- [[Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox]] · mentions
- [[Flame spread Effects of microgravity and scale]] · mentions
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr]] · mentions
- [[Flame spread Effects of microgravity and scale (2)]] · mentions
- [[Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity]] · mentions
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr (2)]] · mentions
- [[Detection of Smoke from Microgravity Fires (2)]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection, Seventh International Microgravity ]] · mentions
- [[Detection of Smoke from Microgravity Fires (3)]] · mentions
- [[The Microgravity Science Glovebox (MSG), a Resource for Gravity-Dependent Phenomena Research on the Internatio (2)]] · mentions
- [[AN OVERVIEW OF THE MICROGRAVITY SCIENCE GLOVEBOX (MSG) FACILITY, AND THE GRAVITY-DEPENDENT PHENOMENARESEARCH P]] · mentions
- [[Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity]] · mentions
- [[Methanol Droplet Extinction in Oxygen Carbon-dioxide Nitrogen Mixtures in Microgravity Results from the Intern]] · mentions
- [[A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions]] · mentions
- [[Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions]] · mentions
- [[Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity]] · mentions
- [[Activation energy asymptotics for methanol droplet extinction in microgravity]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion (2)]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments (2)]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced  (2)]] · mentions
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St (2)]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (3)]] · mentions
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity (2)]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model (2)]] · mentions
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st (2)]] · mentions
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure]] · mentions
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments]] · mentions
- [[Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet combustion in elevated pressure micro]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced ]] · mentions
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and Heptane Droplets]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity]] · mentions
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model]] · mentions
