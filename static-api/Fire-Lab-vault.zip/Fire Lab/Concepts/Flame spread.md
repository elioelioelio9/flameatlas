---
id: "concept:flame-spread"
type: "concept"
aliases: ["flame spread", "spread rate", "flame propagation", "propagation de flamme", "spreading flame", "spread"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Flame spread

Advance of a flame front over a solid surface.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal (2)]] · mentions
- [[A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spr]] · mentions
- [[Radiation signature in opposed-flow flame spread]] · mentions
- [[OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread Results of Experiments]] · mentions
- [[Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment]] · mentions
- [[A novel apparatus for flame spread study]] · mentions
- [[Opposed-Flow Flame Spread in a Narrow Channel Apparatus over Thin PMMA Sheets]] · mentions
- [[Temperature and CO2 fields of a downward spreading flame over thin cellulose A comparison of experimental and ]] · mentions
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Experimental validation of a correlation capturing the boundary layer effect on spread rate in the kinetic reg]] · mentions
- [[Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow i]] · mentions
- [[Radiative, thermal, and kinetic regimes of opposed-flow flame spread A comparison between experiment and theor]] · mentions
- [[Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow i]] · mentions
- [[A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin F]] · mentions
- [[Flame spread Effects of microgravity and scale]] · mentions
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr]] · mentions
- [[Flame spread Effects of microgravity and scale (2)]] · mentions
- [[Buoyancy effects on concurrent flame spread over thick PMMA]] · mentions
- [[Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity]] · mentions
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr (2)]] · mentions
- [[Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)]] · mentions
- [[Microgravity and 1-g rankings of materials can disagree]] · mentions
