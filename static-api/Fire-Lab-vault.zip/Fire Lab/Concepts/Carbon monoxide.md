---
id: "concept:carbon-monoxide"
type: "concept"
aliases: ["carbon monoxide", "co concentration", "co_final", "monoxyde de carbone"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Carbon monoxide

Toxic product of incomplete combustion.

## Linked from
- [[ACME E-FIELD Flames]] · mentions
- [[Ion current and carbon monoxide release from an impinging methane air coflow flame in an electric field]] · mentions
