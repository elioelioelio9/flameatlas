---
id: "concept:radiation"
type: "concept"
aliases: ["radiation", "radiative", "radiative loss", "radiative heat", "rayonnement"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Radiative heat loss

Heat leaving the flame as radiation, a driver of extinction in weak flames.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Radiation signature in opposed-flow flame spread]] · mentions
- [[Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Radiative, thermal, and kinetic regimes of opposed-flow flame spread A comparison between experiment and theor]] · mentions
- [[Radiative extinction of burner-supported spherical diffusion flames A scaling analysis]] · mentions
- [[Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity]] · mentions
- [[The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames]] · mentions
- [[On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation ]] · mentions
- [[Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffus]] · mentions
- [[An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen]] · mentions
- [[Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames]] · mentions
- [[Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames]] · mentions
- [[Radiative extinction of gaseous spherical diffusion flames in microgravity]] · mentions
- [[Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames]] · mentions
- [[Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity A Computational S]] · mentions
- [[On intrinsic oscillation in radiation-affected diffusion flames]] · mentions
- [[Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)]] · mentions
- [[Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using de]] · mentions
- [[Two-color pyrometry based flame to fuel surface radiative heat flux diagnostic using flamelets]] · mentions
- [[Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames]] · mentions
