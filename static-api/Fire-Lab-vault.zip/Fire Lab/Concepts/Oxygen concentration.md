---
id: "concept:oxygen-concentration"
type: "concept"
aliases: ["oxygen concentration", "oxygen mole fraction", "o2 concentration", "% o2", "o2 mole fraction", "oxygen-enriched", "elevated oxygen", "reduced oxygen", "oxyg\u00e8ne"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Oxygen concentration

Amount of O2 available to the flame.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Stability of spray combustion for water alcohols mixtures in oxygen-enriched air]] · mentions
- [[Measurement and analysis of soot inception limits of oxygen-enriched coflow flames]] · mentions
- [[Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion]] · mentions
- [[SOOTING LIMITS OF MICROGRAVITY SPHERICAL DIFFUSION FLAMES IN OXYGEN-ENRICHED AIR AND DILUTED FUEL]] · mentions
- [[The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alka]] · mentions
- [[SUPPLEMENTARY MATERIAL The radical index and the effect of oxygen concentration on non-premixed cool flame ext]] · mentions
- [[O2 mole fraction]] · contains related data
- [[Stopping ventilation may not be enough in oxygen-enriched cabins]] · mentions
- [[More oxygen droplet flames more often survive to burnout]] · mentions
- [[FLEX compares CO2 and helium as gaseous suppressants]] · mentions
- [[BASS-II maps solid-fuel burning down to 13.6 % O2]] · mentions
