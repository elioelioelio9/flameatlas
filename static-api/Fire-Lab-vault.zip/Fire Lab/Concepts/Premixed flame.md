---
id: "concept:premixed-flame"
type: "concept"
aliases: ["premixed", "pre-mixed", "flamme pr\u00e9m\u00e9lang\u00e9e"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Premixed flame

Flame burning a mixture already containing fuel and oxidizer.

## Linked from
- [[ACME Flame Design]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion II. Flame structure effects on soot precursor kinet]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion I. The presence of appreciable oxygen at the locati]] · mentions
- [[A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot grow]] · mentions
- [[Measurements and calculations of formaldehyde concentrations in a methane N2 air, non-premixed flame Implicati]] · mentions
- [[Detailed characterization of DC electric field effects on small non-premixed flames]] · mentions
- [[Non-premixed axisymmetric flames driven by ion currents]] · mentions
- [[Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations]] · mentions
- [[CO emission from an impinging non-premixed flame]] · mentions
- [[On burner-stabilized cylindrical premixed flames in microgravity]] · mentions
- [[Extinction mechanisms of near-limit premixed flames and extended limits of flammability]] · mentions
- [[On the response of spherical premixed flames under rotation]] · mentions
- [[Structure, aerodynamics, and geometry of premixed flamelets]] · mentions
- [[Initiation and propagation of laminar premixed cool flames]] · mentions
- [[Non-Premixed - Partially Premixed to Diffusive Burning Initial Transient of Direct Cool Flame Burn (2017)]] · mentions
- [[The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alka]] · mentions
- [[On the propagation limits and speeds of premixed cool flames at elevated pressures]] · mentions
- [[SUPPLEMENTARY MATERIAL The radical index and the effect of oxygen concentration on non-premixed cool flame ext]] · mentions
- [[Transient interactions between a premixed double flame and a vortex]] · mentions
