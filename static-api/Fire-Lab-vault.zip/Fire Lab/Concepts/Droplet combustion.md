---
id: "concept:droplet-combustion"
type: "concept"
aliases: ["droplet", "droplets", "gouttelette", "fiber-supported", "free-floated"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Droplet combustion

Burning of an isolated liquid fuel droplet.

## Linked from
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME s-Flame]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity]] · mentions
- [[Methanol Droplet Extinction in Oxygen Carbon-dioxide Nitrogen Mixtures in Microgravity Results from the Intern]] · mentions
- [[A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions]] · mentions
- [[Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions]] · mentions
- [[Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity]] · mentions
- [[Activation energy asymptotics for methanol droplet extinction in microgravity]] · mentions
- [[Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmospher (2)]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion (2)]] · mentions
- [[Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames (2)]] · mentions
- [[Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry (2)]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments (2)]] · mentions
- [[Droplet Combustion Experiments Aboard the International Space Station (2)]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced  (2)]] · mentions
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets]] · mentions
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates (2)]] · mentions
- [[Combustion of n-Butanol, Gasoline, and n-Butanol Gasoline Mixture Droplets]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St (2)]] · mentions
- [[The effect of support fibers on micro-convection in droplet combustion experiments (2)]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (3)]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (3)]] · mentions
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity (2)]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model (2)]] · mentions
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical (2)]] · mentions
- [[The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tall (2)]] · mentions
- [[Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A (2)]] · mentions
- [[AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS (2)]] · mentions
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st (2)]] · mentions
- [[A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane (2)]] · mentions
- [[Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convectio (2)]] · mentions
- [[Can cool flames support quasi-steady alkane droplet burning (3)]] · mentions
- [[Experiments on Submillimeter Free Droplet Flame Extinction]] · mentions
- [[Influences of support fibers on vaporizing fuel droplets]] · mentions
- [[Numerical studies of flows over liquid droplets on cylindrical fibers]] · mentions
- [[Interpretation of Backlit Droplet Images from ISS Droplet Combustion Experiments]] · mentions
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity]] · mentions
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets ]] · mentions
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments]] · mentions
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity]] · mentions
- [[Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle ]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · mentions
- [[Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets]] · mentions
- [[Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets]] · mentions
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments]] · mentions
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY]] · mentions
- [[Developing Surrogates for Liquid Transportation Fuels The Role of Spherically Symmetric Droplet Combustion]] · mentions
- [[Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmospher]] · mentions
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments]] · mentions
- [[Droplet Combustion Experiments Aboard the International Space Station]] · mentions
- [[Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet combustion in elevated pressure micro]] · mentions
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced ]] · mentions
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and Heptane Droplets]] · mentions
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates]] · mentions
- [[Combustion of Butanol, Gasoline, and Butanol Gasoline Mixture Droplets]] · mentions
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St]] · mentions
- [[The effect of support fibers on micro-convection in droplet combustion experiments]] · mentions
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity]] · mentions
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets]] · mentions
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity]] · mentions
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion]] · mentions
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model]] · mentions
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical]] · mentions
- [[The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tall]] · mentions
- [[Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A]] · mentions
- [[AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS]] · mentions
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st]] · mentions
- [[A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane]] · mentions
- [[Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convectio]] · mentions
- [[Can cool flames support quasi-steady alkane droplet burning]] · mentions
- [[Experiments on Submillimeter Free Droplet Flame Extinction (2)]] · mentions
- [[Influences of support fibers on vaporizing fuel droplets (2)]] · mentions
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity (2)]] · mentions
