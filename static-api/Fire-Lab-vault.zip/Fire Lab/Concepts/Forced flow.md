---
id: "concept:flow-velocity"
type: "concept"
aliases: ["flow velocity", "air flow", "airflow", "forced flow", "flow speed", "ventilation", "imposed flow", "opposed flow", "concurrent flow", "\u00e9coulement"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Forced flow

Gas flow imposed past the flame (ventilation or test flow).

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[ACME BRE]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spr]] · mentions
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · mentions
- [[Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow]] · mentions
- [[Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow i]] · mentions
- [[Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow i]] · mentions
- [[Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits]] · mentions
- [[Microgravity Flammability of PMMA Rods in Concurrent Flow]] · mentions
- [[Flow velocity]] · contains related data
- [[Stopping ventilation may not be enough in oxygen-enriched cabins]] · mentions
- [[1-g material screening is not automatically conservative]] · mentions
