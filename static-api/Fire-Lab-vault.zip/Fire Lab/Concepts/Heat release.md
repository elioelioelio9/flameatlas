---
id: "concept:heat-release"
type: "concept"
aliases: ["heat release", "heat-release", "hrr", "energy release", "calorimetry"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Heat release

Rate at which a fire releases energy.

## Linked from
- [[BASS]] · mentions
- [[ACME CLD Flame]] · mentions
- [[SLICE]] · mentions
- [[Analysis of CH concentration and flame heat release rate in laminar coflow diffusion flames under microgravity]] · mentions
- [[Measurements and calculations of formaldehyde concentrations in a methane N2 air, non-premixed flame Implicati]] · mentions
- [[Analysis of CH concentration and flame heat release rate in laminar coflow diffusion flames under microgravity (2)]] · mentions
