---
id: "concept:buoyancy"
type: "concept"
aliases: ["buoyancy", "buoyant", "natural convection", "flottabilit\u00e9"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Buoyancy

Gravity-driven flow of hot gas; absent in microgravity.

## Linked from
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SPICE]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[STDCE-1]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire), ]] · mentions
- [[Buoyancy effects on concurrent flame spread over thick PMMA]] · mentions
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire),  (2)]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · mentions
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in  (2)]] · mentions
- [[Canceling buoyancy of gaseous fuel flames in a gravitational environment using an ion-driven wind.]] · mentions
- [[On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen methane flam]] · mentions
- [[Chemiluminescent OH and CH flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusi]] · mentions
- [[Oscillatory extinction of spherical diffusion flames Micro-buoyancy experiment and computation]] · mentions
- [[On burner-supported, spherical diffusion flames under micro-buoyancy conditions]] · mentions
- [[Weakly Buoyant Spherical Diffusion Flames Properties of Hydrogen-CO Ethylene Flames]] · mentions
- [[Oscillatory convection due to combined buoyancy and thermocapillarity]] · mentions
- [[Detectors must be checked against microgravity smoke, not Earth smoke]] · mentions
