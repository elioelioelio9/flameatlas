---
id: "concept:temperature"
type: "concept"
aliases: ["temperature", "thermocouple", "flame temperature", "temp\u00e9rature"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Temperature

Gas or surface temperature measurements.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[STDCE-1]] · mentions
- [[Temperature and CO2 fields of a downward spreading flame over thin cellulose A comparison of experimental and ]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures (2)]] · mentions
- [[Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures]] · mentions
- [[Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets (2)]] · mentions
- [[Experimental Observations of the Low-Temperature Burning of Decane Hexanol Droplets in Microgravity]] · mentions
- [[Low Temperature n-Dodecane Droplet Combustion Experiments Aboard the International Space Station]] · mentions
- [[Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffus]] · mentions
- [[A new method of flame temperature measurement utilizing the acoustic emissions from laser-induced plasmas]] · mentions
- [[An Approach to Thermocouple Measurements That Reduces Uncertainties in High-Temperature Environments]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion I. The presence of appreciable oxygen at the locati]] · mentions
- [[Constrained-temperature solutions of coflow laminar diffusion flames]] · mentions
- [[Absolute light calibration using S-type thermocouples]] · mentions
- [[Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air]] · mentions
- [[Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction]] · mentions
- [[Low-temperature multistage warm diffusion flames]] · mentions
- [[On the chemical characteristics and dynamics of n-alkane low-temperature multistage diffusion flames]] · mentions
- [[Quantitative measurements of HO 2 H 2 O 2 and intermediate species in low and intermediate temperature oxidati]] · mentions
- [[Infrared Surface Temperature Measurements for the Surface Tension Driven Convection Experiment]] · mentions
- [[Cool flames combustion at 500–1000 K]] · mentions
- [[Scale matters only SAFFIRE burned spacecraft-size samples]] · mentions
