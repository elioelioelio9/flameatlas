---
id: "concept:soot"
type: "concept"
aliases: ["soot", "sooting", "suie", "carbonaceous"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Soot

Carbon particles produced in fuel-rich flame regions.

## Linked from
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Soot Formation in Spherical Diffusion Flames]] · mentions
- [[Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames]] · mentions
- [[Numerical study of flame structure and soot inception interpreted in carbon-to-oxygen atom ratio space]] · mentions
- [[Numerical investigation of spherical diffusion flames at their sooting limits]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion II. Flame structure effects on soot precursor kinet]] · mentions
- [[Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion]] · mentions
- [[On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure]] · mentions
- [[Measurement and analysis of soot inception limits of oxygen-enriched coflow flames]] · mentions
- [[A theoretical study on soot inception in spherical burner-stabilized diffusion flames]] · mentions
- [[SOOTING LIMITS OF MICROGRAVITY SPHERICAL DIFFUSION FLAMES IN OXYGEN-ENRICHED AIR AND DILUTED FUEL]] · mentions
- [[Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions]] · mentions
- [[Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames]] · mentions
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal ]] · mentions
- [[A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot grow]] · mentions
- [[Soot and thin-filament pyrometry using a color digital camera]] · mentions
- [[Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames]] · mentions
- [[Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene air coflow diffusion fl]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2)]] · mentions
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal  (2)]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (3)]] · mentions
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2022)]] · mentions
