---
id: "concept:pressure"
type: "concept"
aliases: ["pressure", "psia", "kpa", "atmospheric pressure", "ambient pressure", "low pressure", "reduced pressure", "pression"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Pressure

Total ambient pressure of the atmosphere.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures (2)]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets ]] · mentions
- [[Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet combustion in elevated pressure micro]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures]] · mentions
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets  (2)]] · mentions
- [[The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spheri]] · mentions
- [[Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames A computational and exper]] · mentions
- [[PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures]] · mentions
- [[Modeling of Elevated Pressure Diffusion Flames with Water Addition]] · mentions
- [[On the propagation limits and speeds of premixed cool flames at elevated pressures]] · mentions
- [[Dynamics and burning limits of near-limit hot, warm, and cool diffusion flames of dimethyl ether at elevated p]] · mentions
- [[Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames]] · mentions
- [[Pressure (2)]] · contains related data
- [[Scale matters only SAFFIRE burned spacecraft-size samples]] · mentions
