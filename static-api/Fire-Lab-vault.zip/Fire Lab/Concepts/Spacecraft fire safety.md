---
id: "concept:fire-safety"
type: "concept"
aliases: ["fire safety", "fire-safety", "fire hazard", "fire risk", "s\u00e9curit\u00e9 incendie", "fire prevention"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Spacecraft fire safety

Preventing, detecting and suppressing fires in crewed vehicles.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME BRE]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox]] · mentions
- [[Fire safety in space – beyond flammability testing of small samples]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems (2)]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems]] · mentions
