---
id: "concept:ignition"
type: "concept"
aliases: ["ignition", "ignite", "igniter", "allumage", "autoignition", "auto-ignition"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Ignition

Onset of combustion.

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME BRE]] · mentions
- [[ACME s-Flame]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures (2)]] · mentions
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments]] · mentions
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures]] · mentions
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments (2)]] · mentions
- [[Analysis of extinction and sustained ignition]] · mentions
- [[Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner]] · mentions
- [[Theory of first-stage ignition delay in hydrocarbon NTC chemistry]] · mentions
- [[On Radical-Induced Ignition in Combustion Systems]] · mentions
- [[BASS-II maps solid-fuel burning down to 13.6 % O2]] · mentions
