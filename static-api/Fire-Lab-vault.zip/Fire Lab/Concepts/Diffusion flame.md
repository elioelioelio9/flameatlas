---
id: "concept:diffusion-flame"
type: "concept"
aliases: ["diffusion flame", "non-premixed", "nonpremixed", "laminar flame", "jet flame", "flamme de diffusion"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Diffusion flame

Flame where fuel and oxidizer meet by diffusion.

## Linked from
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Theory of the propagation dynamics of spiral edges of diffusion flames in von Kármán swirling flows]] · mentions
- [[Analysis of the melt phase of a rotating polymer disc supporting a diffusion flame]] · mentions
- [[Radiative extinction of burner-supported spherical diffusion flames A scaling analysis]] · mentions
- [[Spherical gas-fueled cool diffusion flames]] · mentions
- [[Cool diffusion flames in a stably stratified stagnation flow]] · mentions
- [[The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames]] · mentions
- [[Soot Formation in Spherical Diffusion Flames]] · mentions
- [[On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation ]] · mentions
- [[Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffus]] · mentions
- [[An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen]] · mentions
- [[SPHERICAL DIFFUSION FLAME IN MICROGRAVITY CONDITIONS FIRST RESULTS OF JOINT RUSSIAN-AMERICAN SPACE EXPERIMENT ]] · mentions
- [[Observations of long duration microgravity spherical diffusion flames aboard the International Space Station]] · mentions
- [[Double blue zones in inverse and normal laminar jet diffusion flames]] · mentions
- [[Dilution effects on laminar jet diffusion flame lengths]] · mentions
- [[Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surfa]] · mentions
- [[Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames]] · mentions
- [[Observation of water–gas shift equilibrium in diffusion flames]] · mentions
- [[Modeled quenching limits of spherical hydrogen diffusion flames]] · mentions
- [[Simplifying the complexity of diffusion flames through interpretation in C O ratio space]] · mentions
- [[Numerical investigation of spherical diffusion flames at their sooting limits]] · mentions
- [[Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion II. Flame structure effects on soot precursor kinet]] · mentions
- [[Characteristics of non-premixed oxygen-enhanced combustion I. The presence of appreciable oxygen at the locati]] · mentions
- [[Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion]] · mentions
- [[Radiative extinction of gaseous spherical diffusion flames in microgravity]] · mentions
- [[Numerical and experimental observations of spherical diffusion flames]] · mentions
- [[The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spheri]] · mentions
- [[On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure]] · mentions
- [[A theoretical study on soot inception in spherical burner-stabilized diffusion flames]] · mentions
- [[SOOTING LIMITS OF MICROGRAVITY SPHERICAL DIFFUSION FLAMES IN OXYGEN-ENRICHED AIR AND DILUTED FUEL]] · mentions
- [[Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames]] · mentions
- [[Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames]] · mentions
- [[Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity A Computational S]] · mentions
- [[Analysis of CH concentration and flame heat release rate in laminar coflow diffusion flames under microgravity]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution]] · mentions
- [[Constrained-temperature solutions of coflow laminar diffusion flames]] · mentions
- [[Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames A computational and exper]] · mentions
- [[Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames]] · mentions
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (2)]] · mentions
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal ]] · mentions
- [[A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot grow]] · mentions
- [[Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames]] · mentions
- [[Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene air coflow diffusion fl]] · mentions
- [[Measurements and calculations of formaldehyde concentrations in a methane N2 air, non-premixed flame Implicati]] · mentions
- [[Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame]] · mentions
- [[Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface]] · mentions
- [[Detailed characterization of DC electric field effects on small non-premixed flames]] · mentions
- [[Microgravity burner-generated spherical diffusion flames experiment and computation. Currently at Department o]] · mentions
- [[PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures]] · mentions
- [[Non-premixed axisymmetric flames driven by ion currents]] · mentions
- [[Impinging nonpremixed coflow methane–air flames with unity Lewis number]] · mentions
- [[Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations]] · mentions
- [[CO emission from an impinging non-premixed flame]] · mentions
- [[Behavior of a small diffusion flame as an electrically active component in a high-voltage circuit]] · mentions
- [[Numerical prediction of ion current from a small methane jet flame]] · mentions
- [[Modeling of Elevated Pressure Diffusion Flames with Water Addition]] · mentions
- [[On the spreading of unsteady cylindrical diffusion flames]] · mentions
- [[On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen methane flam]] · mentions
- [[Microgravity burner-generated spherical diffusion flames experiment and computation‡‡Currently at Department o]] · mentions
- [[Chemiluminescent OH and CH flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusi]] · mentions
- [[Oscillatory extinction of spherical diffusion flames Micro-buoyancy experiment and computation]] · mentions
- [[Response of spherical diffusion flames under rotation with general Lewis numbers]] · mentions
- [[On intrinsic oscillation in radiation-affected diffusion flames]] · mentions
- [[Effects of variable density on response of spherical diffusion flames under rotation]] · mentions
- [[Response of spherical diffusion flames subjected to rotation Microgravity experimentation and computational si]] · mentions
- [[Direct Numerical Simulation of turbulent nonpremixed “cool” flames Applicability of flamelet models]] · mentions
- [[On burner-supported, spherical diffusion flames under micro-buoyancy conditions]] · mentions
