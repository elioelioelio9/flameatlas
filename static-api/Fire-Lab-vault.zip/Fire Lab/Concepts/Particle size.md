---
id: "concept:particle-size"
type: "concept"
aliases: ["particle size", "particle size distribution", "particulate", "particle", "particles", "taille des particules"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Particle size

Size of airborne particles, which governs detector response.

## Linked from
- [[SAFFIRE-II]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[STDCE-1]] · mentions
- [[Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions]] · mentions
- [[Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2]] · mentions
- [[Measurement of Smoke Particle Size under Low-Gravity Conditions]] · mentions
- [[Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection, Seventh International Microgravity ]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Characterization of Nuisance Particulates in the ISS Space Smoke Aerosols and Lunar Dust Abatement]] · mentions
- [[Particle Image Velocimetry for the Surface Tensions Driven Convection Experiment Using a Particle Displacement]] · mentions
- [[Detectors must be checked against microgravity smoke, not Earth smoke]] · mentions
- [[Dust can look like smoke to a particle counter]] · mentions
