---
id: "concept:smoke-detection"
type: "concept"
aliases: ["smoke detector", "detector", "detection", "d\u00e9tecteur", "alarm", "sensor", "capteur"]
tags: ["fire-lab/concept"]
generated: "Fire Lab knowledge engine"
---

# Smoke detection

Sensing fire signatures in time to act.

## Linked from
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[ACME BRE]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[SLICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Results from on-board CSA-CP and CDM Sensor Readings during the Burning and Suppression of Solids - II (BASS-I]] · mentions
- [[Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions]] · mentions
- [[Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Detection of Smoke from Microgravity Fires (2)]] · mentions
- [[Evaluation of spacecraft smoke detector performance in the low-gravity environment]] · mentions
- [[Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design]] · mentions
- [[Spacecraft Fire Detection Smoke Properties and Transport in Low-Gravity]] · mentions
- [[ISS Destiny Laboratory Smoke Detection Model]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection, Seventh International Microgravity ]] · mentions
- [[Smoke Characterization of Smoke Particulate for Spacecraft Fire Detection]] · mentions
- [[Detection of Smoke from Microgravity Fires (3)]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems (2)]] · mentions
- [[Smoke Characterization and Feasibility of the Moment Method for Spacecraft Fire Detection]] · mentions
- [[Evaluation of spacecraft smoke detector performance in the low-gravity environment (2)]] · mentions
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems]] · mentions
- [[Detection of Smoke from Microgravity Fires]] · mentions
- [[Detectors must be checked against microgravity smoke, not Earth smoke]] · mentions
