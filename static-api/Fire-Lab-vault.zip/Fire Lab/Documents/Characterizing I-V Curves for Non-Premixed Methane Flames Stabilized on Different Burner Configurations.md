---
id: "pub:254"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2017.1331218"
generated: "Fire Lab knowledge engine"
---

# Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations

Tinajero Jesse, Bernard Guillaume, Autef Louise, Dunn-Rankin Derek

DOI: [10.1080/00102202.2017.1331218](https://doi.org/10.1080/00102202.2017.1331218)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations” (text)
- [[Premixed flame]] — “Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations” (text)
