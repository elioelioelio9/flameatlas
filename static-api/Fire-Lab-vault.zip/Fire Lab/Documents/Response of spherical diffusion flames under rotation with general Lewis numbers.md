---
id: "pub:279"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830500098423"
generated: "Fire Lab knowledge engine"
---

# Response of spherical diffusion flames under rotation with general Lewis numbers

Yoo S. W., Qian J., Bechtold J. K., Law C. K.

DOI: [10.1080/13647830500098423](https://doi.org/10.1080/13647830500098423)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Response of spherical diffusion flames under rotation with general Lewis numbers” (text)
