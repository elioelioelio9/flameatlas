---
id: "pub:110"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2008.06.221"
generated: "Fire Lab knowledge engine"
---

# Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium

Bae J.H., Avedisian C.T.

DOI: [10.1016/j.proci.2008.06.221](https://doi.org/10.1016/j.proci.2008.06.221)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium” (text)
- [[Buoyancy]] — “Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium” (text)
- [[Droplet combustion]] — “Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium” (text)
- [[Burning rate]] — “Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium” (text)
- [[Suppressant diluent]] — “Nonane droplet combustion with and without buoyant convection: Flame structure, burning rate and extinction in air and helium” (text)
