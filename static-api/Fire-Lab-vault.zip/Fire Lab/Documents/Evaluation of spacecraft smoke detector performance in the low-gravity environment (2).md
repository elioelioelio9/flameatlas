---
id: "pub:63"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2018.04.004"
generated: "Fire Lab knowledge engine"
---

# Evaluation of spacecraft smoke detector performance in the low-gravity environment

Meyer Marit E., Urban David L., Mulholland George W., Bryg Victoria, Yuan Zeng-Guang, Ruff Gary A., Cleary Thomas, Yang Jiann

DOI: [10.1016/j.firesaf.2018.04.004](https://doi.org/10.1016/j.firesaf.2018.04.004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Evaluation of spacecraft smoke detector performance in the low-gravity environment” (text)
- [[Smoke detection]] — “Evaluation of spacecraft smoke detector performance in the low-gravity environment” (text)
