---
id: "pub:52"
type: "document"
tags: ["fire-lab/document"]
doi: "10.4271/2009-01-2468"
generated: "Fire Lab knowledge engine"
---

# Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design

Urban David L., Ruff Gary A., Mulholland George W., Cleary Thomas G., Yang Jiann C., Yuan Zengguang, Bryg Victoria

DOI: [10.4271/2009-01-2468](https://doi.org/10.4271/2009-01-2468)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design” (text)
- [[Particle size]] — “Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design” (text)
- [[Smoke detection]] — “Smoke Particle Sizes in Low-Gravity and Implications for Spacecraft Smoke Detector Design” (text)
