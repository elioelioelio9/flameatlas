---
id: "pub:186"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2016.07.025"
generated: "Fire Lab knowledge engine"
---

# Observation of water–gas shift equilibrium in diffusion flames

Wu Wendong, Yablonsky Gregory, Axelbaum Richard L.

DOI: [10.1016/j.combustflame.2016.07.025](https://doi.org/10.1016/j.combustflame.2016.07.025)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Observation of water–gas shift equilibrium in diffusion flames” (text)
