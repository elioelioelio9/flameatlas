---
id: "pub:172"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2022.07.015"
generated: "Fire Lab knowledge engine"
---

# Spherical gas-fueled cool diffusion flames

Kim Minhyeng, Waddell Kendyl A., Sunderland Peter B., Nayagam Vedha, Stocker Dennis P., Dietrich Daniel L., Ju Yiguang, Williams Forman A., Irace Phillip, Axelbaum Richard L.

DOI: [10.1016/j.proci.2022.07.015](https://doi.org/10.1016/j.proci.2022.07.015)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CFI-G]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Spherical gas-fueled cool diffusion flames” (text)
