---
id: "doc:PSI-62"
type: "document"
tags: ["fire-lab/document", "family/Ground-study"]
doi: "10.60555/e9xp-ex83"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-62"
generated: "Fire Lab knowledge engine"
---

# Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Experiments using Two-Color Tomography

Develops and validates concurrent flame-spread models against BASS microgravity experiments.

DOI: [10.60555/e9xp-ex83](https://doi.org/10.60555/e9xp-ex83)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[NASA Glenn Research Center]] — “Glenn Research Center (GRC)” (metadata)
- [[Flame spread]] — “Develops and validates concurrent flame-spread models against BASS microgravity experiments.” (text)
- [[Microgravity]] — “Develops and validates concurrent flame-spread models against BASS microgravity experiments.” (text)
- [[Numerical modeling]] — “The objective of this research was to develop and validate new flamelet generated manifold (FGM) modeling techniques for concurrent flame spread in microgravity” (text)
- [[Material flammability]] — “…S and BASS-II) experiments as benchmarks. Ultimately, the long-term goal was to enable accurate prediction of flammability limits for spacecraft materials and” (text)
- [[Suppressant diluent]] — “…e this methodology to simulate solid fuel combustion processes with high fidelity, using the NASA Burning and Suppression of Solids (BASS and BASS-II) experime” (text)
- [[Soot]] — “…rocessed using newly developed two-color tomography methods with DSLR cameras, enabling 3D reconstructions of soot and temperature fields for direct comparison” (text)
- [[Temperature]] — “…using newly developed two-color tomography methods with DSLR cameras, enabling 3D reconstructions of soot and temperature fields for direct comparison to model” (text)
- [[Earth]] — “…y zone reported by Olson and Ferkul. Comparative analyses were also carried out with a parallel NSF-supported terrestrial flame spread project, ensuring that t” (text)
- [[Spacecraft fire safety]] — “…stion modeling by deepening our understanding of coupled thermal, chemical, and flow processes, which betters fire safety standards. The computational methods” (text)
- [[Diffusion flame]] — “…uel flame spread in microgravity (2023); Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed m” (text)
- [[Radiative heat loss]] — “…bility bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023); Two-color pyrometry based flame” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[BASS-II]] (metadata)
- [[BASS]] (metadata)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[BASS-II]] (metadata)
- [[BASS]] (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Microgravity flammability boundary for PMMA rods in axial stagnation flow Experimental results and energy bala (2)]] · describes
- [[Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)]] · describes
- [[Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using de]] · describes
- [[Two-color pyrometry based flame to fuel surface radiative heat flux diagnostic using flamelets]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[Computational and Experimental Analysis of SPICE Data Sets]] · shares concept
