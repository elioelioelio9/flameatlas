---
id: "pub:278"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/2.7289"
generated: "Fire Lab knowledge engine"
---

# Development of Comprehensive Detailed and Reduced Reaction Mechanisms for Combustion Modeling

Law C. K., Sung C. J., Wang H., Lu T. F.

DOI: [10.2514/2.7289](https://doi.org/10.2514/2.7289)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Numerical modeling]] — “Development of Comprehensive Detailed and Reduced Reaction Mechanisms for Combustion Modeling” (text)
