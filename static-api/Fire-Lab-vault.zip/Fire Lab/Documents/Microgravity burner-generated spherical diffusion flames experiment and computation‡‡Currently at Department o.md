---
id: "pub:275"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0010-2180(01)00247-4"
generated: "Fire Lab knowledge engine"
---

# Microgravity burner-generated spherical diffusion flames: experiment and computation‡‡Currently at Department of Mechanical and Aerospace Engineering, Case Western Reserve University, Cleveland, OH 44106.

Tse Stephen D, Zhu Delin, Sung Chih-Jen, Ju Yiguang, Law Chung K

DOI: [10.1016/S0010-2180(01)00247-4](https://doi.org/10.1016/S0010-2180(01)00247-4)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Microgravity burner-generated spherical diffusion flames: experiment and computation‡‡Currently at Department of Mechanical and Aerospace Engineering, Case West” (text)
- [[Diffusion flame]] — “Microgravity burner-generated spherical diffusion flames: experiment and computation‡‡Currently at Department of Mechanical and Aerospace Engineering, Case West” (text)
