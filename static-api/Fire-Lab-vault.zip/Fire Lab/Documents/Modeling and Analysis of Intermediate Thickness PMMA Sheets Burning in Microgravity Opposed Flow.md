---
id: "pub:17"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow

TJ Shah, FJ Miller, S Olson, I Wichman

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Forced flow]] — “Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow” (text)
- [[Microgravity]] — “Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow” (text)
- [[Fuel thickness]] — “Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow” (text)
- [[Numerical modeling]] — “Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow” (text)
