---
id: "pub:234"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2010.05.006"
generated: "Fire Lab knowledge engine"
---

# Soot and thin-filament pyrometry using a color digital camera

Kuhn Peter B., Ma Bin, Connelly Blair C., Smooke Mitchell D., Long Marshall B.

DOI: [10.1016/j.proci.2010.05.006](https://doi.org/10.1016/j.proci.2010.05.006)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Soot]] — “Soot and thin-filament pyrometry using a color digital camera” (text)
