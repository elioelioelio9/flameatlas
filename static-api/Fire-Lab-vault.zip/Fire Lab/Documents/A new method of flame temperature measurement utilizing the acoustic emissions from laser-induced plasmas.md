---
id: "pub:183"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.07.096"
generated: "Fire Lab knowledge engine"
---

# A new method of flame temperature measurement utilizing the acoustic emissions from laser-induced plasmas

Wu Wendong, Adeosun Adewale, Axelbaum Richard L.

DOI: [10.1016/j.proci.2018.07.096](https://doi.org/10.1016/j.proci.2018.07.096)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Temperature]] — “A new method of flame temperature measurement utilizing the acoustic emissions from laser-induced plasmas” (text)
