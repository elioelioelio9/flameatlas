---
id: "doc:PSI-101"
type: "document"
aliases: ["SAME-R"]
tags: ["fire-lab/document", "family/SAME"]
doi: "10.60555/2np7-jv14"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-101"
generated: "Fire Lab knowledge engine"
---

# SAME-R — Smoke Aerosol Measurement Experiment-Reflight

Reflight of SAME: sizes of smoke particles produced by spacecraft materials (Kapton, silicone, lamp wick, Pyrell, Teflon) in low gravity, related to smoke generation and transport conditions, to evaluate spacecraft smoke detectors.

DOI: [10.60555/2np7-jv14](https://doi.org/10.60555/2np7-jv14)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Comparitive Soot Diagnostic Hardware; Refer to final report Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Comparitive Soot Diagnostic Hardware; Refer to final report Glenn Research Center (GRC)” (metadata)
- [[Microgravity]] — “…E: sizes of smoke particles produced by spacecraft materials (Kapton, silicone, lamp wick, Pyrell, Teflon) in low gravity, related to smoke generation and tran” (text)
- [[Smoke]] — “Reflight of SAME: sizes of smoke particles produced by spacecraft materials (Kapton, silicone, lamp wick, Pyrell, Teflon) in low gravity, rela…” (text)
- [[Particle size]] — “Reflight of SAME: sizes of smoke particles produced by spacecraft materials (Kapton, silicone, lamp wick, Pyrell, Teflon) in low gravity, related to smo…” (text)
- [[Smoke detection]] — “…Pyrell, Teflon) in low gravity, related to smoke generation and transport conditions, to evaluate spacecraft smoke detectors.” (text)
- [[Droplet combustion]] — “…igation was to quantify the sizes that the liquid smoke particulate achieves in low gravity and to relate the droplet size distribution to the smoke generation” (text)
- [[Temperature]] — “…by Foamex, was introduced to replace DBP samples, 2) test conditions were broadened including higher heating temperatures and no-flow during sample heating tim” (text)
- [[Buoyancy]] — “In a μg environment, with the absence of the strong buoyancy-induced flows, smoke particle growth from a pyrolyzing/smoldering source, as a result of nucleation” (text)
- [[Smoldering]] — “…g environment, with the absence of the strong buoyancy-induced flows, smoke particle growth from a pyrolyzing/smoldering source, as a result of nucleation, con” (text)
- [[Earth]] — “…es produced in microgravity will exhibit substantially larger droplet sizes than under the same conditions in normal gravity (with a corresponding decrease in” (text)
- [[Suppressant diluent]] — “…the adequacy of these existing technologies using relevant data. The current Fire Prevention, Detection, and Suppression (FPDS) program plan allows for the re-” (text)
- [[Spacecraft fire safety]] — “…es that will allow evaluation of the adequacy of these existing technologies using relevant data. The current Fire Prevention, Detection, and Suppression (FPDS” (text)
- [[Soot]] — “SAME-R Smoke Aerosol Measurement Experiment-Reflight. Spacecraft Fire Safety. Comparitive Soot Diagnostic Hardware; Refer to final report” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SAME]] (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[SAME]] — “SAME-R (07-01-2010) follows SAME (03-02-2001) in the SAME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[Flow velocity]] — 109 values, 0–8.1 cm/s (table)
- [[duration s]] — 68 values, 60–120 s (table)
- [[Heater resistance ratio Rt R0]] — 109 values, 1.22–1.48 - (table)
- [[Net smoke aging time]] — 104 values, 21–1923 s (table)
- [[primary aging time s]] — 67 values, 1–720 s (table)
- [[primary mixing time s]] — 67 values, 8–8 s (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Detectors must be checked against microgravity smoke, not Earth smoke]] — “SAME was designed around the hypothesis that, without buoyant flows, smoke particles from pyrolysing materials grow larger than in 1 g; SAME and SAME-R provide” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SAME]] (inferred)
- [[SLICE]] (inferred)
- [[SPICE]] (inferred)
- [[STDCE-1]] (inferred)
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[CFI]] (inferred)
- [[DAFT DAFT-2]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SAME]] · references
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · depends on
- [[Smoke Aerosol Measurement Experiment-2 Comparison of Flight Experiment Results with Ground Test Results]] · describes
- [[Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection]] · describes
- [[Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2]] · describes
- [[Preliminary Results from the Smoke Aerosol Measurement Experiment - Reflight]] · describes
- [[Detection of Smoke from Microgravity Fires (2)]] · describes
- [[Evaluation of spacecraft smoke detector performance in the low-gravity environment]] · describes
- [[SAFFIRE-III]] · shares concept
