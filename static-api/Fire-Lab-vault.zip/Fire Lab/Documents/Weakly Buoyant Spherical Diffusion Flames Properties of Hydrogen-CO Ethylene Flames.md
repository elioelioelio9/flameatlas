---
id: "pub:307"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Weakly Buoyant Spherical Diffusion Flames: Properties of Hydrogen-CO Ethylene Flames

L Paxton

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “Weakly Buoyant Spherical Diffusion Flames: Properties of Hydrogen-CO Ethylene Flames” (text)
- [[Diffusion flame]] — “Weakly Buoyant Spherical Diffusion Flames: Properties of Hydrogen-CO Ethylene Flames” (text)
