---
id: "pub:262"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.elstat.2005.09.005"
generated: "Fire Lab knowledge engine"
---

# Maximizing ion-driven gas flows

Rickard Matthew, Dunn-Rankin Derek, Weinberg Felix, Carleton Fred

DOI: [10.1016/j.elstat.2005.09.005](https://doi.org/10.1016/j.elstat.2005.09.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)
