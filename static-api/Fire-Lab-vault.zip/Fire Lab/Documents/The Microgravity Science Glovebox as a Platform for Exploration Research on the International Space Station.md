---
id: "pub:1"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2006-941"
generated: "Fire Lab knowledge engine"
---

# The Microgravity Science Glovebox as a Platform for Exploration Research on the International Space Station

Spivey Reggie, Luz Paul

DOI: [10.2514/6.2006-941](https://doi.org/10.2514/6.2006-941)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “The Microgravity Science Glovebox as a Platform for Exploration Research on the International Space Station” (text)
