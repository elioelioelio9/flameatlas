---
id: "pub:101"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.compfluid.2013.02.005"
generated: "Fire Lab knowledge engine"
---

# Influences of support fibers on vaporizing fuel droplets

Shringi D., Dwyer H.A., Shaw B.D.

DOI: [10.1016/j.compfluid.2013.02.005](https://doi.org/10.1016/j.compfluid.2013.02.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Influences of support fibers on vaporizing fuel droplets” (text)
