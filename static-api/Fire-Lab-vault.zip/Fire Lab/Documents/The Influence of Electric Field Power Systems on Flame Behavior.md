---
id: "pub:244"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# The Influence of Electric Field Power Systems on Flame Behavior

K Yamashita, Y-C Chien, S Karnani, D Dunn-Rankin

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “The Influence of Electric Field Power Systems on Flame Behavior” (text)
