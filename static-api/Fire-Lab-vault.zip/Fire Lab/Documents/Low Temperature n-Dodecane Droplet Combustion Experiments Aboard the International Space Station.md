---
id: "pub:171"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s12217-024-10115-x"
generated: "Fire Lab knowledge engine"
---

# Low Temperature n-Dodecane Droplet Combustion Experiments Aboard the International Space Station

Dietrich Daniel, Krause Timmothy, Nayagam Vedha, Farouk Tanvir, Dryer Frederick, Williams Forman

DOI: [10.1007/s12217-024-10115-x](https://doi.org/10.1007/s12217-024-10115-x)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[CFI]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Low Temperature n-Dodecane Droplet Combustion Experiments Aboard the International Space Station” (text)
- [[Temperature]] — “Low Temperature n-Dodecane Droplet Combustion Experiments Aboard the International Space Station” (text)
