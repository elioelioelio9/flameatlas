---
id: "pub:265"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2022.112443"
generated: "Fire Lab knowledge engine"
---

# Electric-field effects on methane coflow flames aboard the international space station (ISS): ACME E-FIELD flames

Chien Yu-Chien, Stocker Dennis P., Hegde Uday G., Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2022.112443](https://doi.org/10.1016/j.combustflame.2022.112443)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “Electric-field effects on methane coflow flames aboard the international space station (ISS): ACME E-FIELD flames” (text)
