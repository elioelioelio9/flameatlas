---
id: "pub:365"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/0094-5765(95)00004-J"
generated: "Fire Lab knowledge engine"
---

# An experimental study of free surface deformation in oscillatory thermocapillary flow

Lin Jianlian, Kamotani Yasuhiro, Ostrach Simon

DOI: [10.1016/0094-5765(95)00004-J](https://doi.org/10.1016/0094-5765(95)00004-J)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
