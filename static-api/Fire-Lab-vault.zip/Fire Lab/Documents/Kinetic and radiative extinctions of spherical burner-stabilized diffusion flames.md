---
id: "pub:193"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2010.12.007"
generated: "Fire Lab knowledge engine"
---

# Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames

Wang Q., Chao B.H.

DOI: [10.1016/j.combustflame.2010.12.007](https://doi.org/10.1016/j.combustflame.2010.12.007)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames” (text)
- [[Diffusion flame]] — “Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames” (text)
- [[Radiative heat loss]] — “Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames” (text)
