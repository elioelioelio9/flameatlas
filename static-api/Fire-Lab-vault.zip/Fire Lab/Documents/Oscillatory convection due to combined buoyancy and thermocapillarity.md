---
id: "pub:363"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/3.759"
generated: "Fire Lab knowledge engine"
---

# Oscillatory convection due to combined buoyancy and thermocapillarity

Kamotani Y., Masud J., Pline A.

DOI: [10.2514/3.759](https://doi.org/10.2514/3.759)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “Oscillatory convection due to combined buoyancy and thermocapillarity” (text)
