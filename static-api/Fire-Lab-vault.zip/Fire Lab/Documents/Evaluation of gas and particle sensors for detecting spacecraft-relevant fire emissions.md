---
id: "pub:40"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2020.102977"
generated: "Fire Lab knowledge engine"
---

# Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions

Wang Xiaoliang, Zhou Hao, Arnott W. Patrick, Meyer Marit E., Taylor Samuel, Firouzkouhi Hatef, Moosmüller Hans, Chow Judith C., Watson John G.

DOI: [10.1016/j.firesaf.2020.102977](https://doi.org/10.1016/j.firesaf.2020.102977)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Particle size]] — “Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions” (text)
- [[Smoke detection]] — “Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions” (text)
