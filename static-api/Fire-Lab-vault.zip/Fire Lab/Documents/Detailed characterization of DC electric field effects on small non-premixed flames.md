---
id: "pub:248"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2015.03.019"
generated: "Fire Lab knowledge engine"
---

# Detailed characterization of DC electric field effects on small non-premixed flames

Karnani Sunny, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2015.03.019](https://doi.org/10.1016/j.combustflame.2015.03.019)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Detailed characterization of DC electric field effects on small non-premixed flames” (text)
- [[Premixed flame]] — “Detailed characterization of DC electric field effects on small non-premixed flames” (text)
- [[Electric field]] — “Detailed characterization of DC electric field effects on small non-premixed flames” (text)
