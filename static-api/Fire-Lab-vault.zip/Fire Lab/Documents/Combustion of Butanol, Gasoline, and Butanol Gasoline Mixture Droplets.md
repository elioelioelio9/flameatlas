---
id: "pub:124"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1021/acs.energyfuels.5b00158"
generated: "Fire Lab knowledge engine"
---

# Combustion of Butanol, Gasoline, and Butanol/Gasoline Mixture Droplets

Xu Yuhao, Avedisian C. Thomas

DOI: [10.1021/acs.energyfuels.5b00158](https://doi.org/10.1021/acs.energyfuels.5b00158)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Combustion of Butanol, Gasoline, and Butanol/Gasoline Mixture Droplets” (text)
