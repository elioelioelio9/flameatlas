---
id: "pub:289"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.fuel.2015.11.025"
generated: "Fire Lab knowledge engine"
---

# Initiation and propagation of laminar premixed cool flames

Zhao Peng, Liang Wenkai, Deng Sili, Law Chung K.

DOI: [10.1016/j.fuel.2015.11.025](https://doi.org/10.1016/j.fuel.2015.11.025)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Premixed flame]] — “Initiation and propagation of laminar premixed cool flames” (text)
- [[Cool flame]] — “Initiation and propagation of laminar premixed cool flames” (text)
