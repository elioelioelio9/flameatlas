---
id: "pub:325"
type: "document"
tags: ["fire-lab/document"]
doi: "10.4271/2005-01-2930"
generated: "Fire Lab knowledge engine"
---

# Detection of Smoke from Microgravity Fires

Urban David, Griffin DeVon, Ruff Gary, Cleary Thomas, Yang Jiann, Mulholland George, Yuan Zeng-guang

DOI: [10.4271/2005-01-2930](https://doi.org/10.4271/2005-01-2930)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[DAFT DAFT-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Detection of Smoke from Microgravity Fires” (text)
- [[Smoke]] — “Detection of Smoke from Microgravity Fires” (text)
- [[Smoke detection]] — “Detection of Smoke from Microgravity Fires” (text)
