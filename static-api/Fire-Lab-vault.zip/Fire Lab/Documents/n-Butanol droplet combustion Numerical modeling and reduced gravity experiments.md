---
id: "pub:118"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments

FE Alam, YC Liu, CT Avedisian, FL Dryer, TI Farouk

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
- [[Droplet combustion]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
- [[Numerical modeling]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
