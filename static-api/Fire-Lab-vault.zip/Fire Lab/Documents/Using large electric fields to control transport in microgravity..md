---
id: "pub:261"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1196/annals.1362.037"
generated: "Fire Lab knowledge engine"
---

# Using large electric fields to control transport in microgravity.

Dunn-Rankin D, Weinberg FJ.

DOI: [10.1196/annals.1362.037](https://doi.org/10.1196/annals.1362.037)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Using large electric fields to control transport in microgravity.” (text)
- [[Electric field]] — “Using large electric fields to control transport in microgravity.” (text)
