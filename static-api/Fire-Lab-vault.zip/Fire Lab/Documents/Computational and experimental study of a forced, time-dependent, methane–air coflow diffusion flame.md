---
id: "pub:240"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2006.08.109"
generated: "Fire Lab knowledge engine"
---

# Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame

Dworkin S.B., Connelly B.C., Schaffer A.M., Bennett B.A.V., Long M.B., Smooke M.D., Puccio M.P., McAndrews B., Miller J.H.

DOI: [10.1016/j.proci.2006.08.109](https://doi.org/10.1016/j.proci.2006.08.109)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame” (text)
- [[Numerical modeling]] — “Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame” (text)
