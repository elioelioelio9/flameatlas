---
id: "doc:PSI-23"
type: "document"
aliases: ["ACME s-Flame"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/k57n-p030"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-23"
generated: "Fire Lab knowledge engine"
---

# ACME s-Flame — Advanced Combustion via Microgravity Experiments-Structure and Response of Spherical Diffusion Flames

Structure and response of spherical diffusion flames, including near-extinction behaviour.

DOI: [10.60555/k57n-p030](https://doi.org/10.60555/k57n-p030)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[Extinction]] — “Structure and response of spherical diffusion flames, including near-extinction behaviour.” (text)
- [[Diffusion flame]] — “Structure and response of spherical diffusion flames, including near-extinction behaviour.” (text)
- [[Soot]] — “A series of experiments is proposed with the following specific objectives, in both soot-free and sooty flames, to compare with detailed computational simulatio” (text)
- [[Numerical modeling]] — “…proposed with the following specific objectives, in both soot-free and sooty flames, to compare with detailed computational simulation to assess transport prop” (text)
- [[Suppressant diluent]] — “…usion flames established at initially non-steady, spherical flame structures for mixtures of different H2/CH4/diluent ratios (soot-free) and different C2H4/dil” (text)
- [[Temperature]] — “Objective A. Measure and characterize the transient structure (such as temperature and species distribution) of diffusion flames established at initially non-st” (text)
- [[Radiative heat loss]] — “…. Determine the quasi-steady convective/chemical-kinetic extinction limits (low system Damköhler numbers) and radiative/chemical-kinetic extinction limits (hig” (text)
- [[Pressure]] — “…tive flux measurements, and system operating conditions (including reactant flow rates, ambient temperatures, pressures and acceleration levels, etc.). These d” (text)
- [[Buoyancy]] — “…ng performance in terms of power, efficiency, pollutant emissions, and reliability. Fundamentally, the unique buoyancy-free environment offered by microgravity” (text)
- [[Microgravity]] — “…iciency, pollutant emissions, and reliability. Fundamentally, the unique buoyancy-free environment offered by microgravity affords simple aerodynamic flow fiel” (text)
- [[Combustion Integrated Rack]] — “…n via Microgravity Experiments-Structure and Response of Spherical Diffusion Flames. Flames of gaseous fuels. Combustion Integrated Rack (CIR), ACME” (text)
- [[Ignition]] — “…ted vorticity; Extended flammability limits of n-heptane/air mixtures with cool flames; Theory of first-stage ignition delay in hydrocarbon NTC chemistry; Dire” (text)
- [[Premixed flame]] — “Opportunities and challenges of combustion in microgravity; On burner-stabilized cylindrical premixed flames in microgravity; On the structure, stabilization, a” (text)
- [[Droplet combustion]] — “…erical premixed flames under rotation; Role of flamefront motion and criterion for global quasi-steadiness in droplet burning; On micro-buoyancy spherical diff” (text)
- [[Cool flame]] — “…vestigation on self-acceleration of cellular spherical flames; Initiation and propagation of laminar premixed cool flames; On colliding spherical flames: Morph” (text)
- [[Burning rate]] — “…droplet and a non-burning droplet of xylene: Outcome regimes and flame dynamics; Stabilization mechanisms and burning rates of cylindrical burner flames; On bu” (text)
- [[Material flammability]] — “…al response of flat-burner flames; Extinction mechanisms of near-limit premixed flames and extended limits of flammability; On the spreading of unsteady cylind” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[ACME Flame Design]] — “ACME s-Flame (02-05-2015) follows ACME/Flame Design (01-14-1999) in the ACME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 18 values, 0.21–0.3 - (table)
- [[Flames ignited]] — 18 values, 7–23 count (table)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[ACME E-FIELD Flames]] · references
- [[ACME CLD Flame]] · extends
- [[Opportunities and challenges of combustion in microgravity]] · describes
- [[On burner-stabilized cylindrical premixed flames in microgravity]] · describes
- [[On the structure, stabilization, and dual response of flat-burner flames]] · describes
- [[Extinction mechanisms of near-limit premixed flames and extended limits of flammability]] · describes
- [[On the spreading of unsteady cylindrical diffusion flames]] · describes
- [[On the response of spherical premixed flames under rotation]] · describes
- [[Role of flamefront motion and criterion for global quasi-steadiness in droplet burning]] · describes
- [[On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen methane flam]] · describes
- [[Structure, aerodynamics, and geometry of premixed flamelets]] · describes
- [[Microgravity burner-generated spherical diffusion flames experiment and computation‡‡Currently at Department o]] · describes
- [[Chemiluminescent OH and CH flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusi]] · describes
- [[Oscillatory extinction of spherical diffusion flames Micro-buoyancy experiment and computation]] · describes
- [[Development of Comprehensive Detailed and Reduced Reaction Mechanisms for Combustion Modeling]] · describes
- [[Response of spherical diffusion flames under rotation with general Lewis numbers]] · describes
- [[Porous spherical burner for combustion experimentation]] · describes
- [[On intrinsic oscillation in radiation-affected diffusion flames]] · describes
- [[Effects of variable density on response of spherical diffusion flames under rotation]] · describes
- [[A mechanistic study of Soret diffusion in hydrogen–air flames]] · describes
- [[Self-similar accelerative propagation of expanding wrinkled flames and explosion triggering]] · describes
- [[Response of spherical diffusion flames subjected to rotation Microgravity experimentation and computational si]] · describes
- [[Fuel Options for Next-Generation Chemical Propulsion]] · describes
- [[A mechanistic evaluation of Soret diffusion in heptane air flames]] · describes
- [[An experimental investigation on self-acceleration of cellular spherical flames]] · describes
- [[Initiation and propagation of laminar premixed cool flames]] · describes
- [[On colliding spherical flames Morphology, corner dynamics, and flame-generated vorticity]] · describes
- [[Extended flammability limits of n-heptane air mixtures with cool flames]] · describes
- [[Theory of first-stage ignition delay in hydrocarbon NTC chemistry]] · describes
- [[Direct Numerical Simulation of turbulent nonpremixed “cool” flames Applicability of flamelet models]] · describes
- [[On Radical-Induced Ignition in Combustion Systems]] · describes
- [[Binary collision of a burning droplet and a non-burning droplet of xylene Outcome regimes and flame dynamics]] · describes
- [[Stabilization mechanisms and burning rates of cylindrical burner flames]] · describes
- [[On burner-supported, spherical diffusion flames under micro-buoyancy conditions]] · describes
- [[Microgravity burner-generated spherical diffusion flames - Experiment and computation]] · describes
- [[Thin-Flame Theory for Droplet Combustion at Low Grashof Numbers]] · describes
- [[Nonlinear Analysis of Pulsating Instabilities in Diffusion Flames]] · describes
- [[An Experimental Study on the Response of Spherical Diffusion Flames Subjected to Rotation and Nonequidiffusion]] · describes
- [[A Mechanistic Study of Soret Diffusion in Hydrogen-Air Flames]] · describes
- [[A comprehensive evaluation of soret diffusion in heptane-air flames]] · describes
- [[Dynamics and morphology of spherical diffusion flames under rotation]] · describes
- [[Dynamics and morphology of colliding spherical flames]] · describes
- [[On the structure and dynamics of stationary and rotating spherical diffusion flames]] · describes
- [[Weakly Buoyant Spherical Diffusion Flames Properties of Hydrogen-CO Ethylene Flames]] · describes
- [[Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity]] · describes
- [[Combustion Science A Researcher& x27;s Guide to International Space Station]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
