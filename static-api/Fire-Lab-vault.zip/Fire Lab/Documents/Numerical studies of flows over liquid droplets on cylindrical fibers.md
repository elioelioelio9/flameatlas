---
id: "pub:102"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.compfluid.2013.02.011"
generated: "Fire Lab knowledge engine"
---

# Numerical studies of flows over liquid droplets on cylindrical fibers

Shringi D., Dwyer H.A., Shaw B.D.

DOI: [10.1016/j.compfluid.2013.02.011](https://doi.org/10.1016/j.compfluid.2013.02.011)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Numerical studies of flows over liquid droplets on cylindrical fibers” (text)
