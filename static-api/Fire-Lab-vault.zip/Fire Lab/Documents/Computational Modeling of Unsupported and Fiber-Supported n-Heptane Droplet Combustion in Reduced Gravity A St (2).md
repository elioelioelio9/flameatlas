---
id: "pub:85"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2014.971950"
generated: "Fire Lab knowledge engine"
---

# Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity: A Study of Fiber Effects

Ghata Narugopal, Shaw Benjamin D.

DOI: [10.1080/00102202.2014.971950](https://doi.org/10.1080/00102202.2014.971950)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity: A Study of Fiber Effects” (text)
- [[Droplet combustion]] — “Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity: A Study of Fiber Effects” (text)
- [[Numerical modeling]] — “Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity: A Study of Fiber Effects” (text)
