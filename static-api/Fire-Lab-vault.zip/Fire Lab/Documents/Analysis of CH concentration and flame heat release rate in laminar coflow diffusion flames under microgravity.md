---
id: "pub:223"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2016.02.012"
generated: "Fire Lab knowledge engine"
---

# Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion flames under microgravity and normal gravity

D Giassi, S Cao, BA Bennett, DP Stocker, F Takahashi, MD Smooke, MB Long

DOI: [10.1016/j.combustflame.2016.02.012](https://doi.org/10.1016/j.combustflame.2016.02.012)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion flames under microgravity and normal gravity” (text)
- [[Diffusion flame]] — “Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion flames under microgravity and normal gravity” (text)
- [[Heat release]] — “Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion flames under microgravity and normal gravity” (text)
