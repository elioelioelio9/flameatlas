---
id: "pub:151"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets

DS Shringi, BD Shaw, HA Dwyer

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets” (text)
