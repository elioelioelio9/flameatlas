---
id: "pub:8"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment

P Ferkul, SL Olson, F Takahashi, M Endo, MC Johnston, JS Tien

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment” (text)
- [[Material flammability]] — “Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment” (text)
- [[Fuel thickness]] — “Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment” (text)
