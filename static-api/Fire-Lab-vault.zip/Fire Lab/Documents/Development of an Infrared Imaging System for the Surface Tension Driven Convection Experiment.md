---
id: "pub:356"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Development of an Infrared Imaging System for the Surface Tension Driven Convection Experiment

AD Pline

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
