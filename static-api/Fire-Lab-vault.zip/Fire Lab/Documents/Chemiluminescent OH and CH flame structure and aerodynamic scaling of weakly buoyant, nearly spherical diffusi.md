---
id: "pub:276"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S1540-7489(02)80204-8"
generated: "Fire Lab knowledge engine"
---

# Chemiluminescent OH* and CH* flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusion flames

Yoo S.W., Law C.K., Tse S.D.

DOI: [10.1016/S1540-7489(02)80204-8](https://doi.org/10.1016/S1540-7489(02)80204-8)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “Chemiluminescent OH* and CH* flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusion flames” (text)
- [[Diffusion flame]] — “Chemiluminescent OH* and CH* flame structure and aerodynamic scaling of weakly buoyant, nearly spherical diffusion flames” (text)
