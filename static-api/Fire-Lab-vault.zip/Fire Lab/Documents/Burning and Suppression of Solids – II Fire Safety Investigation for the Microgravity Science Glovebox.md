---
id: "pub:27"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox

SL Olson, PV Ferkul, S Bhattacharjee, FJ Miller, AC Fernandez-Pello, JS Tien

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox” (text)
- [[Suppressant diluent]] — “Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox” (text)
- [[Spacecraft fire safety]] — “Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox” (text)
