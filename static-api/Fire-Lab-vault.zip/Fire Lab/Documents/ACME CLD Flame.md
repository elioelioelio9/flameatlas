---
id: "doc:PSI-21"
type: "document"
aliases: ["ACME CLD Flame"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/23e1-9950"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-21"
generated: "Fire Lab knowledge engine"
---

# ACME CLD Flame — Advanced Combustion via Microgravity Experiments / Coflow Laminar Diffusion Flame

Coflow laminar diffusion flames of diluted methane/ethylene: structure and soot.

DOI: [10.60555/23e1-9950](https://doi.org/10.60555/23e1-9950)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[Diffusion flame]] — “Coflow laminar diffusion flames of diluted methane/ethylene: structure and soot.” (text)
- [[Soot]] — “Coflow laminar diffusion flames of diluted methane/ethylene: structure and soot.” (text)
- [[Suppressant diluent]] — “…de the experimental data needed to allow rigorous testing of computational models at the extremes of the fuel dilution spectrum, we have the following objectiv” (text)
- [[Numerical modeling]] — “In order to provide the experimental data needed to allow rigorous testing of computational models at the extremes of the fuel dilution spectrum, we have the fo” (text)
- [[Extinction]] — “…unction of velocity and fuel dilution, through measurement of flame shape, lift-off heights, temperatures and extinction limits.” (text)
- [[Temperature]] — “…ethylene, as a function of velocity and fuel dilution, through measurement of flame shape, lift-off heights, temperatures and extinction limits.” (text)
- [[Microgravity]] — “…and sooting flames that vary from low to high soot loading levels. The enhanced time and spatial scales in a microgravity environment will be important for ach” (text)
- [[Buoyancy]] — “…, J., Smooke, M.D., and Long, M.B., Experimental and computational study of temperature, species, and soot in buoyant and non-buoyant coflow laminar diffusion” (text)
- [[Radiative heat loss]] — “…al in the modeling of turbulent reacting flows and in understanding the processes by which soot formation and radiative transfer take place. In addition, an un” (text)
- [[Earth]] — “…inction in diffusion flames is critical in the suppression of fires and in improving engine efficiency. While normal gravity combustion studies can provide imp” (text)
- [[Combustion Integrated Rack]] — “…me Advanced Combustion via Microgravity Experiments / Coflow Laminar Diffusion Flame. Flames of gaseous fuel. Combustion Integrated Rack (CIR), ACME” (text)
- [[Pressure]] — “…and Microgravity Conditions; Constrained-temperature solutions of coflow laminar diffusion flames; Effects of pressure and fuel dilution on coflow laminar meth” (text)
- [[Premixed flame]] — “…on of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames; Soot and thin-filam” (text)
- [[Heat release]] — “Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion flames under microgravity and normal gravity; Signal-to-noise ratio improv” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[ACME s-Flame]] — “ACME CLD Flame (10-01-2006) follows ACME s-Flame (02-05-2015) in the ACME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[Flames ignited]] — 32 values, 2–18 count (table)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[ACME E-FIELD Flames]] · extends
- [[Analysis of CH concentration and flame heat release rate in laminar coflow diffusion flames under microgravity]] · describes
- [[Signal-to-noise ratio improvements in laser flow diagnostics using time-resolved image averaging and high dyna]] · describes
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution]] · describes
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions]] · describes
- [[Constrained-temperature solutions of coflow laminar diffusion flames]] · describes
- [[Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames A computational and exper]] · describes
- [[Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames]] · describes
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (2)]] · describes
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal ]] · describes
- [[Absolute light calibration using S-type thermocouples]] · describes
- [[A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot grow]] · describes
- [[Soot and thin-filament pyrometry using a color digital camera]] · describes
- [[IMAGING FLAMES FROM ADVANCED LASER DIAGNOSTICS TO SNAPSHOTS]] · describes
- [[A paradigm shift in the interaction of experiments and computations in combustion research]] · describes
- [[Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames]] · describes
- [[Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene air coflow diffusion fl]] · describes
- [[Measurements and calculations of formaldehyde concentrations in a methane N2 air, non-premixed flame Implicati]] · describes
- [[Computational and experimental study of a forced, time-dependent, methane–air coflow diffusion flame]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
