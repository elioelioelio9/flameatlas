---
id: "pub:162"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2017.1280182"
generated: "Fire Lab knowledge engine"
---

# A Burke–Schumann analysis of diffusion-flame structures supported by a burning droplet

Nayagam Vedha, Dietrich Daniel L., Williams Forman A.

DOI: [10.1080/13647830.2017.1280182](https://doi.org/10.1080/13647830.2017.1280182)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “A Burke–Schumann analysis of diffusion-flame structures supported by a burning droplet” (text)
