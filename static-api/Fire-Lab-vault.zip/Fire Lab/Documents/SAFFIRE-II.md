---
id: "doc:PSI-99"
type: "document"
aliases: ["SAFFIRE-II"]
tags: ["fire-lab/document", "family/SAFFIRE"]
doi: "10.60555/2chp-m469"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-99"
generated: "Fire Lab knowledge engine"
---

# SAFFIRE-II — Spacecraft Fire Experiment-II

Flammability of several spacecraft materials in microgravity compared side-by-side with 1-g reference burns of the same samples.

DOI: [10.60555/2chp-m469](https://doi.org/10.60555/2chp-m469)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Cygnus cargo vehicle]] — “Cygnus Spacecraft Cygnus Pressurized Cargo Module, SAFFIRE Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “Cygnus Spacecraft Cygnus Pressurized Cargo Module, SAFFIRE Glenn Research Center (GRC)” (metadata)
- [[Microgravity]] — “Flammability of several spacecraft materials in microgravity compared side-by-side with 1-g reference burns of the same samples.” (text)
- [[Material flammability]] — “Flammability of several spacecraft materials in microgravity compared side-by-side with 1-g reference burns of the same sa…” (text)
- [[Earth]] — “Flammability of several spacecraft materials in microgravity compared side-by-side with 1-g reference burns of the same samples.” (text)
- [[International Space Station]] — “…fire-II experiment was performed on the Orbital Science’s Cygnus resupply vehicle after it deberthed from the ISS. As a follow on to the Saffire-I investigatio” (text)
- [[Pressure]] — “…e, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemom” (text)
- [[Forced flow]] — “Depending on the sample material, the Saffire-II was conducted at an air flow velocity of either 20 or 30 cm/s, the flow being either concurrent or opposed. Onc” (text)
- [[Smoke detection]] — “…mocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2” (text)
- [[Radiative heat loss]] — “…eras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measu” (text)
- [[Suppressant diluent]] — “…me temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemometer track” (text)
- [[Temperature]] — “…ited flame images were captured using two cameras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radi” (text)
- [[Spacecraft fire safety]] — “…behavior in normal and reduced gravity, the use of terrestrial fires and fire standards to design spacecraft fire safety systems presents an inherent risk to t” (text)
- [[Flame spread]] — “…ly 2015, Bellevue, Washington; The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status; Flame spread: Effects of microgravity and scale;” (text)
- [[Buoyancy]] — “…e Experiment (Saffire) - Objectives, Development and Status; Flame spread: Effects of microgravity and scale; Buoyancy effects on concurrent flame spread over” (text)
- [[Particle size]] — “…e solid fabric in concurrent low-speed flows in microgravity – Model versus experiment; Evaluation of gas and particle sensors for detecting spacecraft-relevan” (text)

## Extends
_The source continues the target programme (same family, later flight)._

- [[SAFFIRE-III]] — “SAFFIRE-II (09-30-2016) follows SAFFIRE-III (04-18-2017) in the SAFFIRE family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 9 values, 0.215–0.221 - (table)
- [[Flow velocity]] — 9 values, 20–20 cm/s (table)
- [[Fuel thickness (2)]] — 8 values, 0.27–10 mm (table)
- [[Burn time]] — 5 values, 115–900 s (table)
- [[ignition power w]] — 9 values, 80–97 W (table)
- [[ignition time s]] — 9 values, 9.2–30 s (table)
- [[sample length cm]] — 9 values, 5–29 cm (table)
- [[sample width cm]] — 9 values, 5–5 cm (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Microgravity and 1-g rankings of materials can disagree]] — “In SAFFIRE-II, 4 of 4 silicone samples (0.27–1.03 mm) had a burn length of about 0 in microgravity at 20 cm/s, while 2 of the 4 matching 1-g reference burns wer” (computed)

## Linked from
- [[SAFFIRE-I]] · references
- [[SAFFIRE-III]] · references
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire), ]] · describes
- [[The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status (2)]] · describes
- [[Flame spread Effects of microgravity and scale (2)]] · describes
- [[Buoyancy effects on concurrent flame spread over thick PMMA]] · describes
- [[Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity]] · describes
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr (2)]] · describes
- [[Evaluation of gas and particle sensors for detecting spacecraft-relevant fire emissions]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[DAFT DAFT-2]] · shares concept
- [[Computational and Experimental Analysis of SPICE Data Sets]] · shares concept
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · shares concept
- [[FLEX-2]] · shares concept
- [[FLEX]] · shares concept
- [[SAFFIRE-I]] · shares concept
