---
id: "pub:360"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0017-9310(98)00163-X"
generated: "Fire Lab knowledge engine"
---

# Oscillatory thermocapillary flows in open cylindrical containers induced by CO2 laser heating

Kamotani Y., Ostrach S., Masud J.

DOI: [10.1016/S0017-9310(98)00163-X](https://doi.org/10.1016/S0017-9310(98)00163-X)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Suppressant diluent]] — “Oscillatory thermocapillary flows in open cylindrical containers induced by CO2 laser heating” (text)
