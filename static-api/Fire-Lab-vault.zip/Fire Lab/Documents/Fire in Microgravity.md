---
id: "pub:24"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1511/2016.118.44"
generated: "Fire Lab knowledge engine"
---

# Fire in Microgravity

Hariharan Ashwin, Miller Fletcher, Olson Sandra, Wichman Indrek

DOI: [10.1511/2016.118.44](https://doi.org/10.1511/2016.118.44)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Fire in Microgravity” (text)
