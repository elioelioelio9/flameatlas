---
id: "pub:132"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.07.074"
generated: "Fire Lab knowledge engine"
---

# Sub-millimeter sized methyl butanoate droplet combustion: Microgravity experiments and detailed numerical modeling

Farouk T.I., Liu Y.C., Savas A.J., Avedisian C.T., Dryer F.L.

DOI: [10.1016/j.proci.2012.07.074](https://doi.org/10.1016/j.proci.2012.07.074)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Sub-millimeter sized methyl butanoate droplet combustion: Microgravity experiments and detailed numerical modeling” (text)
- [[Droplet combustion]] — “Sub-millimeter sized methyl butanoate droplet combustion: Microgravity experiments and detailed numerical modeling” (text)
- [[Numerical modeling]] — “Sub-millimeter sized methyl butanoate droplet combustion: Microgravity experiments and detailed numerical modeling” (text)
