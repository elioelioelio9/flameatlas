---
id: "pub:334"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.05.151"
generated: "Fire Lab knowledge engine"
---

# Oscillatory cool flame combustion behavior of submillimeter sized n-alkane droplet under near limit conditions (2019)

Alam Fahd E., Aghdam Ali Charchi, Dryer Frederick L., Farouk Tanvir I.

DOI: [10.1016/j.proci.2018.05.151](https://doi.org/10.1016/j.proci.2018.05.151)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Oscillatory cool flame combustion behavior of submillimeter sized n-alkane droplet under near limit conditions (2019)” (text)
- [[Cool flame]] — “Oscillatory cool flame combustion behavior of submillimeter sized n-alkane droplet under near limit conditions (2019)” (text)
