---
id: "pub:190"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.06.043"
generated: "Fire Lab knowledge engine"
---

# Numerical study of flame structure and soot inception interpreted in carbon-to-oxygen atom ratio space

Xia Fei, Yablonsky Gregory S., Axelbaum Richard L.

DOI: [10.1016/j.proci.2012.06.043](https://doi.org/10.1016/j.proci.2012.06.043)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Soot]] — “Numerical study of flame structure and soot inception interpreted in carbon-to-oxygen atom ratio space” (text)
