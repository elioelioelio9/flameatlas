---
id: "doc:PSI-39"
type: "document"
aliases: ["CFI"]
tags: ["fire-lab/document", "family/FLEX"]
doi: "10.60555/m6pj-a914"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-39"
generated: "Fire Lab knowledge engine"
---

# CFI — Cool Flames Investigation

Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.

DOI: [10.60555/m6pj-a914](https://doi.org/10.60555/m6pj-a914)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Multi-User Droplet Combustion Apparatus (MDCA), Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Multi-User Droplet Combustion Apparatus (MDCA), Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)
- [[Extinction]] — “Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.” (text)
- [[Pressure]] — “Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.” (text)
- [[Droplet combustion]] — “Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.” (text)
- [[Cool flame]] — “Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.” (text)
- [[Suppressant diluent]] — “Cool-flame behaviour of dodecane droplets versus pressure and helium dilution, including extinction diameters.” (text)
- [[Soot]] — “…the relationship between droplet size, pressure, and flame extinction, and (5) understand the consequence of soot formation during cool flame combustion.” (text)
- [[Ignition]] — “…ermic needles or tethered using silicon-carbide fibers. A hot-wire igniter is positioned near the droplet for ignition. After ignition the wire is retracted. F” (text)
- [[Combustion Integrated Rack]] — “The Combustion Integrated Rack (CIR) contains the Multi-User Droplet Combustion Apparatus (MDCA) which facilitates the controlled combustion…” (text)
- [[Multi-user Droplet Combustion Apparatus]] — “The Combustion Integrated Rack (CIR) contains the Multi-User Droplet Combustion Apparatus (MDCA) which facilitates the controlled combustion of fuel droplets. A” (text)
- [[Radiative heat loss]] — “…cameras were used for monitoring and documentation. Narrow-band and wide-band radiometers for analyzed flame radiation.” (text)
- [[Microgravity]] — “…combustion of liquid hydrocarbon fuels such as n-dodecane, n-dodecane/iso-dodecane mixtures, and faresane in microgravity can provide insights into low-tempera” (text)
- [[Temperature]] — “…h as n-dodecane, n-dodecane/iso-dodecane mixtures, and faresane in microgravity can provide insights into low-temperature chemical kinetics, revealing critical” (text)
- [[Earth]] — “…revealing critical parameters like droplet extinction diameters and flame dynamics that are not observable on Earth.” (text)
- [[Numerical modeling]] — “…us Charge Compression Ignition (HCCI) engines. The research will also help combustion chemists to develop new computational models to compute combustion perfor” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Multi-User Droplet Combustion Apparatus (MDCA), Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)
- [[Multi-user Droplet Combustion Apparatus]] — “International Space Station (ISS) Multi-User Droplet Combustion Apparatus (MDCA), Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[FLEX]] (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[FLEX-2]] — “CFI (10-01-2020) follows FLEX-2 (08-12-2016) in the FLEX family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 87 values, 0.17–0.21 - (table)
- [[Pressure (2)]] — 87 values, 50.663–506.625 kPa (table)
- [[Helium mole fraction]] — 87 values, 0–0.59 - (table)
- [[n2 mole frac]] — 87 values, 0.2–0.83 mole fraction (table)

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Atmosphere — ISS Earth-normal cabin]] (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Cool flames combustion at 500–1000 K]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Can cool flames support quasi-steady alkane droplet burning (2)]] · describes
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (2)]] · describes
- [[Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames]] · describes
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (2)]] · describes
- [[Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry]] · describes
- [[Science in Short Cool Flames]] · describes
- [[Low Temperature n-Dodecane Droplet Combustion Experiments Aboard the International Space Station]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
