---
id: "pub:93"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.fuel.2013.02.025"
generated: "Fire Lab knowledge engine"
---

# The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tallow

Liu Yu Cheng, Savas Anthony J., Avedisian C. Thomas

DOI: [10.1016/j.fuel.2013.02.025](https://doi.org/10.1016/j.fuel.2013.02.025)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tallow” (text)
