---
id: "pub:212"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1002/fam.2896"
generated: "Fire Lab knowledge engine"
---

# Emulation of condensed fuel flames with gaseous fuels supplied through a porous copper calorimeter

Auth Eric, Quintiere James G., Sunderland Peter B.

DOI: [10.1002/fam.2896](https://doi.org/10.1002/fam.2896)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)
