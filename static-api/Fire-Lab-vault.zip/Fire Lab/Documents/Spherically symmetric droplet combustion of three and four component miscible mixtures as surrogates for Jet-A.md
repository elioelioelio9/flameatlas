---
id: "pub:135"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A

YC Liu, AJ Savas, CT Avedisian

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A” (text)
