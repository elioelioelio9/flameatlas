---
id: "pub:189"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.camwa.2013.01.008"
generated: "Fire Lab knowledge engine"
---

# Simplifying the complexity of diffusion flames through interpretation in C/O ratio space

Xia Fei, Axelbaum Richard L.

DOI: [10.1016/j.camwa.2013.01.008](https://doi.org/10.1016/j.camwa.2013.01.008)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Simplifying the complexity of diffusion flames through interpretation in C/O ratio space” (text)
