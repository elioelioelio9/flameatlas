---
id: "doc:PSI-117"
type: "document"
tags: ["fire-lab/document", "family/Ground-study"]
doi: "10.60555/gz0q-b577"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-117"
generated: "Fire Lab knowledge engine"
---

# Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics: A Multidimensional Multi-Physics CFD Analysis

CFD of how external thermal/convective perturbations affect cool-flame droplet combustion (FLEX data).

DOI: [10.60555/gz0q-b577](https://doi.org/10.60555/gz0q-b577)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[NASA Glenn Research Center]] — “Glenn Research Center (GRC)” (metadata)
- [[Droplet combustion]] — “CFD of how external thermal/convective perturbations affect cool-flame droplet combustion (FLEX data).” (text)
- [[Cool flame]] — “CFD of how external thermal/convective perturbations affect cool-flame droplet combustion (FLEX data).” (text)
- [[Numerical modeling]] — “CFD of how external thermal/convective perturbations affect cool-flame droplet combustion (FLEX data).” (text)
- [[Extinction]] — “…ability windows for ignition, sustained oscillation, transitions to hot ignition and warm-flame behavior, and extinction under microgravity.” (text)
- [[Ignition]] — “…al drift-induced convection. Focusing on both small and large droplets, the work mapped stability windows for ignition, sustained oscillation, transitions to h” (text)
- [[Microgravity]] — “…or ignition, sustained oscillation, transitions to hot ignition and warm-flame behavior, and extinction under microgravity.” (text)
- [[Radiative heat loss]] — “…y produced reusable models and sensitivity analyses that coupled low-temperature chemistry with transport and radiative effects.” (text)
- [[Temperature]] — “…nding the FLEX data in the PSI, this study produced reusable models and sensitivity analyses that coupled low-temperature chemistry with transport and radiativ” (text)
- [[International Space Station]] — “…e combustion chemistry, coupled heat and mass transfer, and radiation. Model fidelity was established against ISS FLEX measurements, after which controlled sim” (text)
- [[Pressure]] — “…ameter sweeps over forcing amplitude and frequency, ambient composition (including ozone-assisted cases), and pressure. From each case, predictive observables” (text)
- [[Buoyancy]] — “…ion to hot ignition, and extinction by shifting residence time and scalar dissipation. In microgravity, where buoyancy was suppressed, this forcing was anticip” (text)
- [[Spacecraft fire safety]] — “Space Benefits: Potential to improve spacecraft fire-safety modeling by resolving cool-flame/extinction behavior in microgravity; leverages FLEX to define safer” (text)
- [[Earth]] — “Earth Benefits: Advances low-temperature combustion understanding relevant to engine knock, efficiency, and emissio…” (text)
- [[Diffusion flame]] — “…019); Cool Flame Combustion of Sub-Millimeter Sized Higher n-Alkane Droplets at Atmospheric Condition (2017); Non-Premixed - Partially Premixed to Diffusive Bu” (text)
- [[Premixed flame]] — “…; Cool Flame Combustion of Sub-Millimeter Sized Higher n-Alkane Droplets at Atmospheric Condition (2017); Non-Premixed - Partially Premixed to Diffusive Burnin” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[FLEX]] (metadata)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[FLEX]] (metadata)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Supports
_The source is cited as evidence for the target finding._

- [[Cool flames combustion at 500–1000 K]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (inferred)
- [[ACME CFI-G]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air]] · describes
- [[Sub-millimeter sized multi-component jet fuel surrogate droplet combustion Physicochemical preferential vapori]] · describes
- [[Initial diameter effects on combustion of unsupported equi-volume n-heptane iso-octane mixture droplets and th]] · describes
- [[Oscillatory cool flame combustion behavior of submillimeter sized n-alkane droplet under near limit conditions]] · describes
- [[Investigating the role of preferential vaporization during submillimeter sized multicomponent jet fuel surroga]] · describes
- [[Multi-component jet fuel surrogate droplet combustion Preferential vaporization behaviors under spray relevant]] · describes
- [[Cool Flame Combustion of Sub-Millimeter Sized Higher n-Alkane Droplets at Atmospheric Condition (2017)]] · describes
- [[Non-Premixed - Partially Premixed to Diffusive Burning Initial Transient of Direct Cool Flame Burn (2017)]] · describes
- [[Oscillatory Cool Flame Combustion Behavior of Submillimeter Sized n-Alkane Droplet under Near Limit Conditions (2)]] · describes
- [[Dynamics of cool flames (2019)]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
