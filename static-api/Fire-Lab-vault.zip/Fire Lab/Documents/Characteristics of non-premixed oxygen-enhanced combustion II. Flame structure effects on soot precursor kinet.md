---
id: "pub:195"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2010.04.013"
generated: "Fire Lab knowledge engine"
---

# Characteristics of non-premixed oxygen-enhanced combustion: II. Flame structure effects on soot precursor kinetics resulting in soot-free flames

Skeen S.A., Yablonsky G., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2010.04.013](https://doi.org/10.1016/j.combustflame.2010.04.013)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Characteristics of non-premixed oxygen-enhanced combustion: II. Flame structure effects on soot precursor kinetics resulting in soot-free flames” (text)
- [[Premixed flame]] — “Characteristics of non-premixed oxygen-enhanced combustion: II. Flame structure effects on soot precursor kinetics resulting in soot-free flames” (text)
- [[Soot]] — “Characteristics of non-premixed oxygen-enhanced combustion: II. Flame structure effects on soot precursor kinetics resulting in soot-free flames” (text)
