---
id: "pub:109"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s12217-008-9096-2"
generated: "Fire Lab knowledge engine"
---

# Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle Retraction

Yan Jin, Shaw Benjamin D.

DOI: [10.1007/s12217-008-9096-2](https://doi.org/10.1007/s12217-008-9096-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle Retraction” (text)
- [[Numerical modeling]] — “Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle Retraction” (text)
