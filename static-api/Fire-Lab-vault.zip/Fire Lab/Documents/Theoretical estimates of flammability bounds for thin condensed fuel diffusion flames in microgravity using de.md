---
id: "pub:328"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2023.112910"
generated: "Fire Lab knowledge engine"
---

# Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023)

Budzinski Kenneth, DesJardin Paul E.

DOI: [10.1016/j.combustflame.2023.112910](https://doi.org/10.1016/j.combustflame.2023.112910)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023)” (text)
- [[Diffusion flame]] — “Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023)” (text)
- [[Radiative heat loss]] — “Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023)” (text)
- [[Material flammability]] — “Theoretical estimates of flammability bounds for thin condensed fuel diffusion flames in microgravity using detailed models of chemistry and radiation (2023)” (text)
