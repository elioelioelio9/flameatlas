---
id: "doc:PSI-10"
type: "document"
aliases: ["ACME/Flame Design"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/w4zy-bt45"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-10"
generated: "Fire Lab knowledge engine"
---

# ACME/Flame Design — Advanced Combustion via Microgravity Experiments / Flame Design

Soot-inception and flame-design limits of spherical diffusion flames versus flow rate, Zst, dilution and pressure.

DOI: [10.60555/w4zy-bt45](https://doi.org/10.60555/w4zy-bt45)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Advanced Combustion via Microgravity Experiments (ACME), Combustion Integrated Rack (CIR), Reconfiguration of Combustion Integ” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Advanced Combustion via Microgravity Experiments (ACME), Combustion Integrated Rack (CIR), Reconfiguration of Combustion Integ” (metadata)
- [[Pressure]] — “Soot-inception and flame-design limits of spherical diffusion flames versus flow rate, Zst, dilution and pressure.” (text)
- [[Diffusion flame]] — “Soot-inception and flame-design limits of spherical diffusion flames versus flow rate, Zst, dilution and pressure.” (text)
- [[Soot]] — “Soot-inception and flame-design limits of spherical diffusion flames versus flow rate, Zst, dilution and pressure.” (text)
- [[Suppressant diluent]] — “Soot-inception and flame-design limits of spherical diffusion flames versus flow rate, Zst, dilution and pressure.” (text)
- [[Temperature]] — “…flow rate, Zst, amount of inert (N2 or CO2), and pressure for C2H4 and CH4 flames. Identify the corresponding temperatures in hot regions. Obtain similar limit” (text)
- [[Extinction]] — “C. Obtain extinction limits as functions of Zst, amount of N2, and pressure for normal and inverse spherical C2H4 and CH4 flames.…” (text)
- [[Radiative heat loss]] — “…herical C2H4 and CH4 flames. Identify the corresponding temperatures in hot regions. Identify the presence of radiative or kinetic extinction. Evaluate whether” (text)
- [[Material flammability]] — “…emperatures in hot regions. Identify the presence of radiative or kinetic extinction. Evaluate whether pseudo-flammability limits can be obtained for these fla” (text)
- [[Drop tower]] — “Perform spherical diffusion flame tests in drop towers and aboard the International Space Station. Consider a broad range of reactant dilutions, flow rates and” (text)
- [[Microgravity]] — “2. Microgravity spherical diffusion flames extinguish when the peak temperature first decreases below 1130 K.” (text)
- [[Earth]] — “This project has the potential for improving efficiency and reducing pollutant emissions in terrestrial combustors. For example, it is contributing to novel des” (text)
- [[Combustion Integrated Rack]] — “…Experiments / Flame Design. Flames of Gaseous Fuels. Advanced Combustion via Microgravity Experiments (ACME), Combustion Integrated Rack (CIR), Reconfiguration” (text)
- [[Oxygen concentration]] — “…nterpreted in carbon-to-oxygen atom ratio space; Stability of spray combustion for water/alcohols mixtures in oxygen-enriched air; Numerical investigation of s” (text)
- [[Premixed flame]] — “…tions of spherical burner-stabilized diffusion flames; Extremely weak hydrogen flames; Characteristics of non-premixed oxygen-enhanced combustion: II. Flame st” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Advanced Combustion via Microgravity Experiments (ACME), Combustion Integrated Rack (CIR), Reconfiguration of Combustion Integ” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[ACME BRE]] — “ACME/Flame Design (01-14-1999) follows ACME BRE (01-01-2010) in the ACME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 316 values, 0.198–0.85 - (table)
- [[Pressure (2)]] — 307 values, 43.161–305.817 kPa (table)
- [[Adiabatic flame temperature]] — 256 values, 1682.72–2974.46 K (table)
- [[Fuel flow]] — 147 values, 0.312674–2.52131 mg/s (table)
- [[o2 flow mg s]] — 112 values, 1.52365–9.79934 mg/s (table)
- [[Zst]] — 256 values, 0.0609175–0.75848 - (table)

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Atmosphere — ISS Earth-normal cabin]] (table)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SAFFIRE-III]] (inferred)
- [[SLICE]] (inferred)
- [[SPICE]] (inferred)
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (inferred)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (inferred)
- [[ACME CFI-G]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[ACME s-Flame]] · extends
- [[The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames]] · describes
- [[Soot Formation in Spherical Diffusion Flames]] · describes
- [[On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation ]] · describes
- [[Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffus]] · describes
- [[An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen]] · describes
- [[SPHERICAL DIFFUSION FLAME IN MICROGRAVITY CONDITIONS FIRST RESULTS OF JOINT RUSSIAN-AMERICAN SPACE EXPERIMENT ]] · describes
- [[Observations of long duration microgravity spherical diffusion flames aboard the International Space Station]] · describes
- [[Double blue zones in inverse and normal laminar jet diffusion flames]] · describes
- [[Dilution effects on laminar jet diffusion flame lengths]] · describes
- [[A new method of flame temperature measurement utilizing the acoustic emissions from laser-induced plasmas]] · describes
- [[Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surfa]] · describes
- [[Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames]] · describes
- [[Observation of water–gas shift equilibrium in diffusion flames]] · describes
- [[An Approach to Thermocouple Measurements That Reduces Uncertainties in High-Temperature Environments]] · describes
- [[Modeled quenching limits of spherical hydrogen diffusion flames]] · describes
- [[Simplifying the complexity of diffusion flames through interpretation in C O ratio space]] · describes
- [[Numerical study of flame structure and soot inception interpreted in carbon-to-oxygen atom ratio space]] · describes
- [[Stability of spray combustion for water alcohols mixtures in oxygen-enriched air]] · describes
- [[Numerical investigation of spherical diffusion flames at their sooting limits]] · describes
- [[Kinetic and radiative extinctions of spherical burner-stabilized diffusion flames]] · describes
- [[Extremely weak hydrogen flames]] · describes
- [[Characteristics of non-premixed oxygen-enhanced combustion II. Flame structure effects on soot precursor kinet]] · describes
- [[Characteristics of non-premixed oxygen-enhanced combustion I. The presence of appreciable oxygen at the locati]] · describes
- [[Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion]] · describes
- [[Radiative extinction of gaseous spherical diffusion flames in microgravity]] · describes
- [[Numerical and experimental observations of spherical diffusion flames]] · describes
- [[The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spheri]] · describes
- [[On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure]] · describes
- [[Measurement and analysis of soot inception limits of oxygen-enriched coflow flames]] · describes
- [[Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion]] · describes
- [[A theoretical study on soot inception in spherical burner-stabilized diffusion flames]] · describes
- [[SOOTING LIMITS OF MICROGRAVITY SPHERICAL DIFFUSION FLAMES IN OXYGEN-ENRICHED AIR AND DILUTED FUEL]] · describes
- [[Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames]] · describes
