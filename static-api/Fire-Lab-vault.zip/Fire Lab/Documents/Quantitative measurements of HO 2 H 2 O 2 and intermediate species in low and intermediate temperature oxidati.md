---
id: "pub:349"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.05.120"
generated: "Fire Lab knowledge engine"
---

# Quantitative measurements of HO 2 /H 2 O 2 and intermediate species in low and intermediate temperature oxidation of dimethyl ether

Kurimoto Naoki, Brumfield Brian, Yang Xueliang, Wada Tomoya, Diévart Pascal, Wysocki Gerard, Ju Yiguang

DOI: [10.1016/j.proci.2014.05.120](https://doi.org/10.1016/j.proci.2014.05.120)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Temperature]] — “Quantitative measurements of HO 2 /H 2 O 2 and intermediate species in low and intermediate temperature oxidation of dimethyl ether” (text)
