---
id: "pub:106"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2010.498798"
generated: "Fire Lab knowledge engine"
---

# Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets in Air-Diluent Environments

Shaw B. D., Wei J. B.

DOI: [10.1080/00102202.2010.498798](https://doi.org/10.1080/00102202.2010.498798)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets in Air-Diluent Environments” (text)
- [[Droplet combustion]] — “Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets in Air-Diluent Environments” (text)
- [[Material flammability]] — “Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets in Air-Diluent Environments” (text)
- [[Suppressant diluent]] — “Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets in Air-Diluent Environments” (text)
