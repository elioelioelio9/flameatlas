---
id: "pub:204"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2004.08.016"
generated: "Fire Lab knowledge engine"
---

# A theoretical study on soot inception in spherical burner-stabilized diffusion flames

Liu S., Chao B.H., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2004.08.016](https://doi.org/10.1016/j.combustflame.2004.08.016)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “A theoretical study on soot inception in spherical burner-stabilized diffusion flames” (text)
- [[Soot]] — “A theoretical study on soot inception in spherical burner-stabilized diffusion flames” (text)
