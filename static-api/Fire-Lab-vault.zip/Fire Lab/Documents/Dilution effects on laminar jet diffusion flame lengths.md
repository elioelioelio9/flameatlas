---
id: "pub:182"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.06.085"
generated: "Fire Lab knowledge engine"
---

# Dilution effects on laminar jet diffusion flame lengths

Wang Zhengyang, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.proci.2018.06.085](https://doi.org/10.1016/j.proci.2018.06.085)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Dilution effects on laminar jet diffusion flame lengths” (text)
- [[Suppressant diluent]] — “Dilution effects on laminar jet diffusion flame lengths” (text)
