---
id: "pub:241"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Ion Current and Flame Changes with Electric Fields in Microgravity

YC Chien, J Tinajero, D Stocker, U Hegde, D Dunn-Rankin

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Ion Current and Flame Changes with Electric Fields in Microgravity” (text)
- [[Electric field]] — “Ion Current and Flame Changes with Electric Fields in Microgravity” (text)
