---
id: "pub:232"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.05.030"
generated: "Fire Lab knowledge engine"
---

# Absolute light calibration using S-type thermocouples

Ma Bin, Long Marshall B.

DOI: [10.1016/j.proci.2012.05.030](https://doi.org/10.1016/j.proci.2012.05.030)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Temperature]] — “Absolute light calibration using S-type thermocouples” (text)
