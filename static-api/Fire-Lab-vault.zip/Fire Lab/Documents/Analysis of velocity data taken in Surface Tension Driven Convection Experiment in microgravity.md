---
id: "pub:366"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1063/1.868432"
generated: "Fire Lab knowledge engine"
---

# Analysis of velocity data taken in Surface Tension Driven Convection Experiment in microgravity

Kamotani Y., Ostrach S., Pline A.

DOI: [10.1063/1.868432](https://doi.org/10.1063/1.868432)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Analysis of velocity data taken in Surface Tension Driven Convection Experiment in microgravity” (text)
