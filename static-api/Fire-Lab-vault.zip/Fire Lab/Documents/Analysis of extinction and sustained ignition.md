---
id: "pub:216"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2019.02.003"
generated: "Fire Lab knowledge engine"
---

# Analysis of extinction and sustained ignition

Vermina Plathner Frida, Quintiere James G., van Hees Patrick

DOI: [10.1016/j.firesaf.2019.02.003](https://doi.org/10.1016/j.firesaf.2019.02.003)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Analysis of extinction and sustained ignition” (text)
- [[Ignition]] — “Analysis of extinction and sustained ignition” (text)
