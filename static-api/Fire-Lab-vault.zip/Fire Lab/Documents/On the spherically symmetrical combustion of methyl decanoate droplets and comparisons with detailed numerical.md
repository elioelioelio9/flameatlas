---
id: "pub:133"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling

YC Liu, T Farouk, AJ Savas, FL Dryer, CT Avedisian

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling” (text)
- [[Numerical modeling]] — “On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling” (text)
