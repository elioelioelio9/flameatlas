---
id: "pub:285"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2011.07.013"
generated: "Fire Lab knowledge engine"
---

# Response of spherical diffusion flames subjected to rotation: Microgravity experimentation and computational simulation

Yoo Sean W., Chaudhuri Swetaprovo, Sacksteder Kurt R., Zhang Peng, Zhu Delin, Law Chung K.

DOI: [10.1016/j.combustflame.2011.07.013](https://doi.org/10.1016/j.combustflame.2011.07.013)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Response of spherical diffusion flames subjected to rotation: Microgravity experimentation and computational simulation” (text)
- [[Diffusion flame]] — “Response of spherical diffusion flames subjected to rotation: Microgravity experimentation and computational simulation” (text)
- [[Numerical modeling]] — “Response of spherical diffusion flames subjected to rotation: Microgravity experimentation and computational simulation” (text)
