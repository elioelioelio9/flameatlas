---
id: "pub:117"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2014-1019"
generated: "Fire Lab knowledge engine"
---

# Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmosphere for n-Heptane, n-Octane, and n-Decane: International Space Station and Ground-based Experiments

YC Liu, CT Avedisian, KN Trenou, JK Rah, MC Hicks

DOI: [10.2514/6.2014-1019](https://doi.org/10.2514/6.2014-1019)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmosphere for n-Heptane, n-Octane, and n-Decane: Internati” (text)
