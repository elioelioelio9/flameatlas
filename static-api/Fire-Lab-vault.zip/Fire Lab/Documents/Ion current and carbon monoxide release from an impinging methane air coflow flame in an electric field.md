---
id: "pub:251"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2019.03.022"
generated: "Fire Lab knowledge engine"
---

# Ion current and carbon monoxide release from an impinging methane/air coflow flame in an electric field

Chien Yu-Chien, Escofet-Martin David, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2019.03.022](https://doi.org/10.1016/j.combustflame.2019.03.022)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “Ion current and carbon monoxide release from an impinging methane/air coflow flame in an electric field” (text)
- [[Carbon monoxide]] — “Ion current and carbon monoxide release from an impinging methane/air coflow flame in an electric field” (text)
