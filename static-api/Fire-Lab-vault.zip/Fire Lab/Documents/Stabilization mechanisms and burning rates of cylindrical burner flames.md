---
id: "pub:296"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.1994-571"
generated: "Fire Lab knowledge engine"
---

# Stabilization mechanisms and burning rates of cylindrical burner flames

Eng J., Law C., Zhu D.

DOI: [10.2514/6.1994-571](https://doi.org/10.2514/6.1994-571)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Burning rate]] — “Stabilization mechanisms and burning rates of cylindrical burner flames” (text)
