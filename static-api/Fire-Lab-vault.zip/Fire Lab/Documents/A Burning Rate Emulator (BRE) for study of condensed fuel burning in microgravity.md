---
id: "pub:217"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.01.044"
generated: "Fire Lab knowledge engine"
---

# A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity

Markan Akshit, Sunderland Peter B., Quintiere James G., de Ris John L., Stocker Dennis P., Baum Howard R.

DOI: [10.1016/j.combustflame.2018.01.044](https://doi.org/10.1016/j.combustflame.2018.01.044)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity” (text)
- [[Burning rate]] — “A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity” (text)
