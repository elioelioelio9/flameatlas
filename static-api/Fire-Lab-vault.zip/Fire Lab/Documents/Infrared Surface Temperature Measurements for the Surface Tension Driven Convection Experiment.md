---
id: "pub:355"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Infrared Surface Temperature Measurements for the Surface Tension Driven Convection Experiment

AD Pline

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Temperature]] — “Infrared Surface Temperature Measurements for the Surface Tension Driven Convection Experiment” (text)
