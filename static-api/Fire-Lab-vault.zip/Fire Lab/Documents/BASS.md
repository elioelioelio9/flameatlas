---
id: "doc:PSI-26"
type: "document"
aliases: ["BASS"]
tags: ["fire-lab/document", "family/BASS"]
doi: "10.60555/58h4-dy80"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-26"
generated: "Fire Lab knowledge engine"
---

# BASS — Burning and Suppression of Solids

Flame spread and extinction over realistic solid fuels (cotton-fiberglass fabric, PMMA in several geometries, Nomex) in low-speed forced flow aboard the ISS. Built to bridge the gap between the 1-g NASA-STD-6001 Test 1 screening method and real microgravity flammability, and to test an inert gaseous extinguishing agent.

DOI: [10.60555/58h4-dy80](https://doi.org/10.60555/58h4-dy80)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Microgravity Science Glovebox Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Microgravity Science Glovebox Glenn Research Center (GRC)” (metadata)
- [[Flame spread]] — “Flame spread and extinction over realistic solid fuels (cotton-fiberglass fabric, PMMA in several geometries, Nomex) in lo…” (text)
- [[Extinction]] — “Flame spread and extinction over realistic solid fuels (cotton-fiberglass fabric, PMMA in several geometries, Nomex) in low-speed forced…” (text)
- [[Forced flow]] — “…inction over realistic solid fuels (cotton-fiberglass fabric, PMMA in several geometries, Nomex) in low-speed forced flow aboard the ISS. Built to bridge the g” (text)
- [[Microgravity]] — “…d flow aboard the ISS. Built to bridge the gap between the 1-g NASA-STD-6001 Test 1 screening method and real microgravity flammability, and to test an inert g” (text)
- [[Material flammability]] — “…the ISS. Built to bridge the gap between the 1-g NASA-STD-6001 Test 1 screening method and real microgravity flammability, and to test an inert gaseous extingu” (text)
- [[Suppressant diluent]] — “…gap between the 1-g NASA-STD-6001 Test 1 screening method and real microgravity flammability, and to test an inert gaseous extinguishing agent.” (text)
- [[Earth]] — “…MA in several geometries, Nomex) in low-speed forced flow aboard the ISS. Built to bridge the gap between the 1-g NASA-STD-6001 Test 1 screening method and rea” (text)
- [[Ignition]] — “…ass (by mass) measuring were used as a fuel source as well as Nomex fabric and Ultem. A Kanthal wire (29-gage)igniter was used to initiate combustion at one en” (text)
- [[Microgravity Science Glovebox]] — “The experiment was conducted aboard the International Space Station (ISS) inside the Microgravity Glove Box (MSG). Custom-made fabric samples consisting of 75%” (text)
- [[Oxygen concentration]] — “…well if not better than the same material in normal gravity with other conditions being identical (pressure, oxygen concentration, temperature, etc.) To test t” (text)
- [[Pressure]] — “…n, burn as well if not better than the same material in normal gravity with other conditions being identical (pressure, oxygen concentration, temperature, etc.” (text)
- [[Temperature]] — “…an the same material in normal gravity with other conditions being identical (pressure, oxygen concentration, temperature, etc.) To test this hypothesis with a” (text)
- [[Drop tower]] — “…hypothesis with any but the thinnest materials requires extended microgravity time – longer than available in drop towers or parabolic aircraft.” (text)
- [[Radiative heat loss]] — “…on 1-g behavior without consideration of low gravity effects. A critical element of this understanding is the radiative heat emission from the flame. These res” (text)
- [[Heat release]] — “…s the radiative heat emission from the flame. These results are used in first order models and predictions of heat release in spacecraft fires and as a means t” (text)
- [[Spacecraft fire safety]] — “BASS Burning and Suppression of Solids. Spacecraft Fire Safety. Microgravity Science Glovebox” (text)
- [[Fuel thickness]] — “…DYNAMICS); Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment; Thickness and Fuel Preheating Effects on Material” (text)
- [[Numerical modeling]] — “…low-Off Extinction in Opposed-Flow Flame Spread: Results of Experiments and Simplified Analysis(invited,Scale modeling on solid combustion,OS24 Scale modeling,” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Microgravity Science Glovebox]] — “International Space Station (ISS) Microgravity Science Glovebox Glenn Research Center (GRC)” (metadata)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SPICE]] (metadata)
- [[BASS-II]] (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[BASS-II]] — “BASS (10-01-2009) follows BASS-II (01-01-2010) in the BASS family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[sample diameter mm]] — 47 values, 10–20 mm (table)
- [[sample width cm]] — 36 values, 1–2 cm (table)

## Supports
_The source is cited as evidence for the target finding._

- [[1-g material screening is not automatically conservative]] — “Spacecraft material selection relies on NASA-STD-6001 Test 1, which ranks materials by 1-g behaviour. BASS and BASS-II were built on the hypothesis that, with a” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[BASS-II]] · references
- [[SAFFIRE-I]] · references
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · references
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · depends on
- [[The Microgravity Science Glovebox as a Platform for Exploration Research on the International Space Station]] · describes
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal (2)]] · describes
- [[Simplified model for predicting difference between flammability limits of a thin material in normal gravity an]] · describes
- [[A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spr]] · describes
- [[Radiation signature in opposed-flow flame spread]] · describes
- [[OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread Results of Experiments]] · describes
- [[Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment]] · describes
- [[Thickness and Fuel Preheating Effects on Material Flammability in Microgravity from the BASS Experiment]] · describes
- [[A novel apparatus for flame spread study]] · describes
- [[Opposed-Flow Flame Spread in a Narrow Channel Apparatus over Thin PMMA Sheets]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
