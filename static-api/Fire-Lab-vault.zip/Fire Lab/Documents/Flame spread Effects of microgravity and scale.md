---
id: "pub:30"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.10.012"
generated: "Fire Lab knowledge engine"
---

# Flame spread: Effects of microgravity and scale

Urban David L., Ferkul Paul, Olson Sandra, Ruff Gary A., Easton John, T'ien James S., Liao Ya-Ting T., Li Chengyao, Fernandez-Pello Carlos, Torero Jose L., Legros Guillaume, Eigenbrod Christian, Smirnov Nickolay, Fujita Osamu, Rouvreau Sébastien, Toth Balazs, Jomaas Grunde

DOI: [10.1016/j.combustflame.2018.10.012](https://doi.org/10.1016/j.combustflame.2018.10.012)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-I]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Flame spread: Effects of microgravity and scale” (text)
- [[Microgravity]] — “Flame spread: Effects of microgravity and scale” (text)
