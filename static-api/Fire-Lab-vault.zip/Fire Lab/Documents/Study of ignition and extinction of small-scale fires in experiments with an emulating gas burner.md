---
id: "pub:218"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2016.11.003"
generated: "Fire Lab knowledge engine"
---

# Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner

Lundström Frida Vermina, Sunderland Peter B., Quintiere James G., van Hees Patrick, de Ris John L.

DOI: [10.1016/j.firesaf.2016.11.003](https://doi.org/10.1016/j.firesaf.2016.11.003)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner” (text)
- [[Ignition]] — “Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner” (text)
