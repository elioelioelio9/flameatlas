---
id: "doc:PSI-142"
type: "document"
tags: ["fire-lab/document", "family/Ground-study"]
doi: "10.60555/80qf-vj95"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-142"
generated: "Fire Lab knowledge engine"
---

# Quantitative Studies of Cool Flame Transitions at Radiation / Stretch Extinction Using Counterflow Flames

Cool-flame extinction limits (radiation and stretch) compared with FLEX conditions; PSI lists the published datasets.

DOI: [10.60555/80qf-vj95](https://doi.org/10.60555/80qf-vj95)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[NASA Glenn Research Center]] — “Not Applicable Principal Investigator Laboratory Hardware Glenn Research Center (GRC)” (metadata)
- [[Extinction]] — “Cool-flame extinction limits (radiation and stretch) compared with FLEX conditions; PSI lists the published datasets.” (text)
- [[Cool flame]] — “Cool-flame extinction limits (radiation and stretch) compared with FLEX conditions; PSI lists the published datasets.” (text)
- [[Radiative heat loss]] — “Cool-flame extinction limits (radiation and stretch) compared with FLEX conditions; PSI lists the published datasets.” (text)
- [[Material flammability]] — “1) Develop a new diagram of the flammability limits of diffusional cool flames affected by radiation, diffusion, and convection.” (text)
- [[International Space Station]] — “3) Verify the phenomena observed on the ISS flame extinguishment experiments.” (text)
- [[Temperature]] — “4) Obtain new, quantitative data of extinction limit, flame temperature, and species distribution for the validation of kinetic and radiation models involving c” (text)
- [[Droplet combustion]] — “5) Extend the cool flame experiments from the original ISS droplet experiments to a more general ground-based combustion system involving radiation, diffusion,” (text)
- [[Flame spread]] — “…tion limits of cool flames was conducted using three different numerical modeling schemes, (a) spark-assisted flame propagation of a n-heptane/air mixture, (b)” (text)
- [[Oxygen concentration]] — “Using the experimental conditions of FLEX flight, a comparative studies of the oxygen concentration effects on the extinction limits of cool flames was conducte” (text)
- [[Pressure]] — “…s using an arc-length continuation method and (c) simulated cool flame regimes and burning limits at elevated pressure (up to 20 atm) using DME/air mixtures.” (text)
- [[Numerical modeling]] — “…n concentration effects on the extinction limits of cool flames was conducted using three different numerical modeling schemes, (a) spark-assisted flame propag” (text)
- [[Diffusion flame]] — “…rg/10.1016/j.proci.2020.09.019] and ''Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction'', [https://doi.org/10” (text)
- [[Suppressant diluent]] — “…ability limit and extinction limit. The investigation hypothesizes that factors such as oxygen concentration, dilution, pressure, diffusion, and convection tra” (text)
- [[Microgravity]] — “…ing of the warm diffusion flame is particularly relevant to combustion in highly turbulent flow fields and in microgravity environments, owing to the possibili” (text)
- [[Spacecraft fire safety]] — “…tive Studies of Cool Flame Transitions at Radiation / Stretch Extinction Using Counterflow Flames. Spacecraft Fire Safety. Principal Investigator Laboratory Ha” (text)
- [[Premixed flame]] — “Dynamics of cool flames; The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes; On the propagation l” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[FLEX]] (metadata)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[FLEX]] (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME CFI-G]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · references
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · depends on
- [[Dynamics of cool flames]] · describes
- [[The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alka]] · describes
- [[On the propagation limits and speeds of premixed cool flames at elevated pressures]] · describes
- [[Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction]] · describes
- [[Counterflow flame experiments and chemical kinetic modeling of dimethyl ether methane mixtures]] · describes
- [[Low-temperature multistage warm diffusion flames]] · describes
- [[Dynamics and burning limits of near-limit hot, warm, and cool diffusion flames of dimethyl ether at elevated p]] · describes
- [[On the chemical characteristics and dynamics of n-alkane low-temperature multistage diffusion flames]] · describes
- [[Quantitative measurements of HO 2 H 2 O 2 and intermediate species in low and intermediate temperature oxidati]] · describes
- [[SUPPLEMENTARY MATERIAL The radical index and the effect of oxygen concentration on non-premixed cool flame ext]] · describes
- [[Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames]] · describes
- [[Transient interactions between a premixed double flame and a vortex]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
