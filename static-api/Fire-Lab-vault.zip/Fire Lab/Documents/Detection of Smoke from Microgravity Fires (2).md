---
id: "pub:48"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Detection of Smoke from Microgravity Fires

DL Urban, D Griffin, G Ruff, T Cleary, J Yang, G Mulholland, ZG Yuan

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME-R]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Detection of Smoke from Microgravity Fires” (text)
- [[Smoke]] — “Detection of Smoke from Microgravity Fires” (text)
- [[Smoke detection]] — “Detection of Smoke from Microgravity Fires” (text)
