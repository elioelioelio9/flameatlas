---
id: "pub:222"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2021.111572"
generated: "Fire Lab knowledge engine"
---

# Theoretical analysis and predictions of burning in microgravity using a burning emulator

Dehghani Parham, Quintiere James G.

DOI: [10.1016/j.combustflame.2021.111572](https://doi.org/10.1016/j.combustflame.2021.111572)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Theoretical analysis and predictions of burning in microgravity using a burning emulator” (text)
