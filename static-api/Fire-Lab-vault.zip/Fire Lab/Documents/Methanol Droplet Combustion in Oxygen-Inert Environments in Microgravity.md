---
id: "pub:66"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity

V Nayagam, DL Dietrich, MC Hicks, FA Williams

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity” (text)
- [[Droplet combustion]] — “Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity” (text)
- [[Suppressant diluent]] — “Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity” (text)
