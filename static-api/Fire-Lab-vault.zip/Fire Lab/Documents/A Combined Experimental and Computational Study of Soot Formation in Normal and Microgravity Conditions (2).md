---
id: "pub:311"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2022.2041621"
generated: "Fire Lab knowledge engine"
---

# A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions

Dobbins Richard R., Tinjero Jesse, Squeo Joseph, Zhao Xinyu, Hall Robert J., Colket Meredith B., Long Marshall B., Smooke Mitchell D.

DOI: [10.1080/00102202.2022.2041621](https://doi.org/10.1080/00102202.2022.2041621)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SLICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions” (text)
- [[Soot]] — “A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions” (text)
- [[Numerical modeling]] — “A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions” (text)
