---
id: "doc:PSI-159"
type: "document"
aliases: ["ACME CFI-G"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/cyt1-kh64"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-159"
generated: "Fire Lab knowledge engine"
---

# ACME CFI-G — Advanced Combustion via Microgravity Experiments / Cool Flames Investigation with Gases

Conditions under which cool diffusion flames occur for propane, butane and others. Contains the highest-oxygen microgravity combustion tests in PSI (oxidizer streams up to 85 % O2).

DOI: [10.60555/cyt1-kh64](https://doi.org/10.60555/cyt1-kh64)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) ACME, Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) ACME, Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)
- [[Oxygen concentration]] — “…utane and others. Contains the highest-oxygen microgravity combustion tests in PSI (oxidizer streams up to 85 % O2).” (text)
- [[Microgravity]] — “…onditions under which cool diffusion flames occur for propane, butane and others. Contains the highest-oxygen microgravity combustion tests in PSI (oxidizer st” (text)
- [[Diffusion flame]] — “Conditions under which cool diffusion flames occur for propane, butane and others. Contains the highest-oxygen microgravity combustion tests in PSI (oxidi…” (text)
- [[Numerical modeling]] — “3. Support the flight tests with advanced CFD simulations.” (text)
- [[Pressure]] — “…oard the International Space Station. Consider multiple fuels, a range of reactant dilutions, flow rates, and pressures for normal and inverse convection direc” (text)
- [[Suppressant diluent]] — “…al diffusion flame tests aboard the International Space Station. Consider multiple fuels, a range of reactant dilutions, flow rates, and pressures for normal a” (text)
- [[Temperature]] — “…vection directions. Observe the flames with a broad suite of cameras, radiometers, photomultiplier tubes, and thermocouples.” (text)
- [[Cool flame]] — “…aboard the ISS can demonstrate the following for the first time, contributing to an improved understanding of cool flame kinetics.” (text)
- [[Extinction]] — “5. Cool diffusion flames for which a decrease in fluent flow rate will cause extinction, whereas an increase will cause a transition to a hot diffusion flame, w” (text)
- [[Combustion Integrated Rack]] — “…ombustion via Microgravity Experiments / Cool Flames Investigation with Gases. Flames of Gaseous Fuels. ACME, Combustion Integrated Rack (CIR)” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) ACME, Combustion Integrated Rack (CIR) Glenn Research Center (GRC)” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 333 values, 0.12–0.85 - (table)
- [[Pressure (2)]] — 333 values, 49.538–330.99 kPa (table)
- [[Adiabatic flame temperature]] — 331 values, 1397.03–2978.37 K (table)
- [[Burn time]] — 329 values, 0–304 s (table)
- [[Fuel flow]] — 333 values, 0–3.215 mg/s (table)
- [[o2 flow mg s]] — 154 values, 0.931126–9.08406 mg/s (table)
- [[peak burner temperature c]] — 284 values, 25.6–651.5 °C (table)
- [[Zst]] — 331 values, 0.0587633–0.783918 - (table)

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Atmosphere — ISS Earth-normal cabin]] (table)
- [[Atmosphere — Moon base pressurized rover]] (table)
- [[Atmosphere — Mars surface habitat]] (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Cool flames combustion at 500–1000 K]] — “Cool diffusion flames have peak temperatures of about 500–1000 K. FLEX, CFI and CFI-G studied them on droplets and burners in microgravity.” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)

## Linked from
- [[ACME BRE]] · extends
- [[Spherical gas-fueled cool diffusion flames]] · describes
- [[Cool diffusion flames in a stably stratified stagnation flow]] · describes
- [[ACME Flame Design]] · shares concept
- [[SLICE]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
