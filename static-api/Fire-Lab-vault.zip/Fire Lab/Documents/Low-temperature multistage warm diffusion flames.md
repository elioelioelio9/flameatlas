---
id: "pub:346"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.03.013"
generated: "Fire Lab knowledge engine"
---

# Low-temperature multistage warm diffusion flames

Yehia Omar R., Reuter Christopher B., Ju Yiguang

DOI: [10.1016/j.combustflame.2018.03.013](https://doi.org/10.1016/j.combustflame.2018.03.013)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Low-temperature multistage warm diffusion flames” (text)
- [[Temperature]] — “Low-temperature multistage warm diffusion flames” (text)
