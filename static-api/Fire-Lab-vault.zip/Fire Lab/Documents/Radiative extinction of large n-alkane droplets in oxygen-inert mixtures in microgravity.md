---
id: "pub:160"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.04.023"
generated: "Fire Lab knowledge engine"
---

# Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity

Nayagam Vedha, Dietrich Daniel L., Hicks Michael C., Williams Forman A.

DOI: [10.1016/j.combustflame.2018.04.023](https://doi.org/10.1016/j.combustflame.2018.04.023)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity” (text)
- [[Microgravity]] — “Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity” (text)
- [[Droplet combustion]] — “Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity” (text)
- [[Radiative heat loss]] — “Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity” (text)
- [[Suppressant diluent]] — “Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity” (text)
