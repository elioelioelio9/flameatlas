---
id: "pub:367"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1038/s41526-022-00189-5"
generated: "Fire Lab knowledge engine"
---

# Revisiting the NASA surface tension driven convection experiments

Sequeira Yohan, Maitra Abhradeep, Pandey Anupam, Jung Sunghwan

DOI: [10.1038/s41526-022-00189-5](https://doi.org/10.1038/s41526-022-00189-5)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
