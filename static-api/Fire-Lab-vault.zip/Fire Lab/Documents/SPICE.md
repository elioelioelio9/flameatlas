---
id: "doc:PSI-107"
type: "document"
aliases: ["SPICE"]
tags: ["fire-lab/document", "family/MSG-duct"]
doi: "10.60555/9kbh-e962"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-107"
generated: "Fire Lab knowledge engine"
---

# SPICE — Smoke Point In Co-flow Experiment

Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).

DOI: [10.60555/9kbh-e962](https://doi.org/10.60555/9kbh-e962)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)
- [[Forced flow]] — “Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).” (text)
- [[Buoyancy]] — “Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).” (text)
- [[Diffusion flame]] — “Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).” (text)
- [[Soot]] — “Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).” (text)
- [[Smoke]] — “Laminar smoke points and soot propensity of non-buoyant jet flames versus burner size and co-flow velocity (469 runs).” (text)
- [[Microgravity]] — “The objective of SPICE is to better understand the complex process of combustion by observing flames in a microgravity environment aboard the International Spac” (text)
- [[Radiative heat loss]] — “…. Data such as flame lengths were recorded using still and video cameras. Measurements included flame height, radiative heat losses, and co-flow air velocity d” (text)
- [[Microgravity Science Glovebox]] — “The experimental setup in the microgravity science glovebox consisted of an apparatus with a flow duct with integrated nozzles, cameras, and fuel delivery syste” (text)
- [[Earth]] — “…buoyant jet diffusion flames. Flame properties are expected to differ significantly from those observed under normal gravity.” (text)
- [[Numerical modeling]] — “(2) Will contribute to refining our computational models for predicting flame behaviors under non-buoyant conditions.” (text)
- [[Spacecraft fire safety]] — “SPICE Smoke Point In Co-flow Experiment. Fire Safety. Microgravity Science Glovebox (MSG)” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Microgravity Science Glovebox]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[SLICE]] — “SPICE (?) follows SLICE (?) in the MSG duct family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[Flow velocity]] — 436 values, 0.66–85.28 cm/s (table)
- [[Fuel flow]] — 457 values, 0–4.397 mg/s (table)
- [[fuel flow sccm]] — 457 values, 0–231.6 sccm (table)
- [[Nozzle diameter]] — 469 values, 0.4064–1.6002 mm (table)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] (inferred)
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (inferred)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[BASS]] · references
- [[SLICE]] · references
- [[Computational and Experimental Analysis of SPICE Data Sets]] · references
- [[Computational and Experimental Analysis of SPICE Data Sets]] · depends on
- [[Laminar Smoke Points in Coflow Measured Aboard the International Space Station]] · describes
- [[Scaling of Gas-Jet Flame Lengths in Elevated Gravity]] · describes
- [[The Microgravity Science Glovebox (MSG), a Resource for Gravity-Dependent Phenomena Research on the Internatio]] · describes
- [[The Microgravity Science Glovebox as a Platform for Exploration Research on the International Space Station (2)]] · describes
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (3)]] · describes
- [[Shapes of nonbuoyant round hydrocarbon-fueled laminar-jet diffusion flames in still air]] · describes
- [[Shapes of nonbuoyant round luminous hydrocarbon air laminar jet diffusion flames]] · describes
- [[Smoke Points of Microgravity and Normal Gravity Coflow Diffusion]] · describes
- [[Laminar smoke points of coflowing flames in microgravity]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
