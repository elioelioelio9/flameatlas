---
id: "pub:298"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Microgravity burner-generated spherical diffusion flames - Experiment and computation

SD Tse, DL Zhu, CJ Sung, CK Law

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Microgravity burner-generated spherical diffusion flames - Experiment and computation” (text)
- [[Diffusion flame]] — “Microgravity burner-generated spherical diffusion flames - Experiment and computation” (text)
