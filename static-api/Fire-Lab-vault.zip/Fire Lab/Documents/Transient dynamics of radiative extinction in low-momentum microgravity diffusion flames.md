---
id: "pub:211"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2020.06.110"
generated: "Fire Lab knowledge engine"
---

# Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames

Snegirev Alexander, Kuznetsov Egor, Markus Ekaterina, Dehghani Parham, Sunderland Peter

DOI: [10.1016/j.proci.2020.06.110](https://doi.org/10.1016/j.proci.2020.06.110)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames” (text)
- [[Microgravity]] — “Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames” (text)
- [[Diffusion flame]] — “Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames” (text)
- [[Radiative heat loss]] — “Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames” (text)
