---
id: "pub:323"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2011.08.002"
generated: "Fire Lab knowledge engine"
---

# Laminar smoke points of coflowing flames in microgravity

Dotson K.T., Sunderland P.B., Yuan Z.-G., Urban D.L.

DOI: [10.1016/j.firesaf.2011.08.002](https://doi.org/10.1016/j.firesaf.2011.08.002)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Laminar smoke points of coflowing flames in microgravity” (text)
- [[Smoke]] — “Laminar smoke points of coflowing flames in microgravity” (text)
