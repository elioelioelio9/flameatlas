---
id: "pub:75"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2010.08.015"
generated: "Fire Lab knowledge engine"
---

# Theory of the propagation dynamics of spiral edges of diffusion flames in von Kármán swirling flows

Urzay Javier, Nayagam Vedha, Williams Forman A.

DOI: [10.1016/j.combustflame.2010.08.015](https://doi.org/10.1016/j.combustflame.2010.08.015)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Theory of the propagation dynamics of spiral edges of diffusion flames in von Kármán swirling flows” (text)
