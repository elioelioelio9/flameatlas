---
id: "pub:332"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2020.06.200"
generated: "Fire Lab knowledge engine"
---

# Sub-millimeter sized multi-component jet fuel surrogate droplet combustion: Physicochemical preferential vaporization effects (2021)

Farouk Tanvir I., Won Sang Hee, Dryer Frederick L.

DOI: [10.1016/j.proci.2020.06.200](https://doi.org/10.1016/j.proci.2020.06.200)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Sub-millimeter sized multi-component jet fuel surrogate droplet combustion: Physicochemical preferential vaporization effects (2021)” (text)
