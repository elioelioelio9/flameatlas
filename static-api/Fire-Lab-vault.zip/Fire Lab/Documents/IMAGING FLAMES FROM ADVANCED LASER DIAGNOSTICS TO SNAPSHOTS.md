---
id: "pub:235"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1142/9789814295789_0004"
generated: "Fire Lab knowledge engine"
---

# IMAGING FLAMES: FROM ADVANCED LASER DIAGNOSTICS TO SNAPSHOTS

LONG MARSHALL

DOI: [10.1142/9789814295789_0004](https://doi.org/10.1142/9789814295789_0004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)
