---
id: "pub:357"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Particle Image Velocimetry for the Surface Tensions Driven Convection Experiment Using a Particle Displacement Tracking

MP Wernet, AD Pline

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Particle size]] — “Particle Image Velocimetry for the Surface Tensions Driven Convection Experiment Using a Particle Displacement Tracking” (text)
