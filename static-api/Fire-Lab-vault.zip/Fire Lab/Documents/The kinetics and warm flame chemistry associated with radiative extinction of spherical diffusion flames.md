---
id: "pub:174"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2024.2326830"
generated: "Fire Lab knowledge engine"
---

# The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames

Waddell Kendyl A., Irace Phillip H., Yablonsky Gregory, Constales Denis, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1080/13647830.2024.2326830](https://doi.org/10.1080/13647830.2024.2326830)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames” (text)
- [[Diffusion flame]] — “The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames” (text)
- [[Radiative heat loss]] — “The kinetics and warm flame chemistry associated with radiative extinction of spherical diffusion flames” (text)
