---
id: "pub:130"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1155/2013/154202"
generated: "Fire Lab knowledge engine"
---

# Combustion of Submillimeter Heptane/Methanol and Heptane/Ethanol Droplets in Reduced Gravity

Aharon I., Tam V. K., Shaw B. D.

DOI: [10.1155/2013/154202](https://doi.org/10.1155/2013/154202)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Combustion of Submillimeter Heptane/Methanol and Heptane/Ethanol Droplets in Reduced Gravity” (text)
- [[Droplet combustion]] — “Combustion of Submillimeter Heptane/Methanol and Heptane/Ethanol Droplets in Reduced Gravity” (text)
