---
id: "pub:140"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2012.07.012"
generated: "Fire Lab knowledge engine"
---

# Can cool flames support quasi-steady alkane droplet burning?

V Nayagam, DL Dietrich, PV Ferkul, MC Hicks, FA Williams

DOI: [10.1016/j.combustflame.2012.07.012](https://doi.org/10.1016/j.combustflame.2012.07.012)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Can cool flames support quasi-steady alkane droplet burning?” (text)
- [[Cool flame]] — “Can cool flames support quasi-steady alkane droplet burning?” (text)
