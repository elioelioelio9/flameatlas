---
id: "doc:PSI-68"
type: "document"
aliases: ["FLEX-2"]
tags: ["fire-lab/document", "family/FLEX"]
doi: "10.60555/byp8-h018"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-68"
generated: "Fire Lab knowledge engine"
---

# FLEX-2 — Flame Extinguishment Experiment - 2

Extends FLEX to practical and bi-component fuels over 0.5–3 atm and 17–30 % O2, including extinction mechanisms; the PSI table is a test matrix rather than a run list.

DOI: [10.60555/byp8-h018](https://doi.org/10.60555/byp8-h018)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA) Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA) Glenn Research Center (GRC)” (metadata)
- [[Extinction]] — “Extends FLEX to practical and bi-component fuels over 0.5–3 atm and 17–30 % O2, including extinction mechanisms; the PSI table is a test matrix rather than a ru” (text)
- [[Oxygen concentration]] — “Extends FLEX to practical and bi-component fuels over 0.5–3 atm and 17–30 % O2, including extinction mechanisms; the PSI table is a test matrix rather than a ru” (text)
- [[Droplet combustion]] — “…ditions that mimic real combustor conditions, as well as, provide benchmark experimental data on bi-component droplet combustion over a wide range of initial c” (text)
- [[Numerical modeling]] — “…rimental data on bi-component droplet combustion over a wide range of initial conditions in order to validate numerical simulations and to develop new theoreti” (text)
- [[Soot]] — “4. Analyze the soot formation process, including soot volume fraction soot-shell dynamics.” (text)
- [[Material flammability]] — “5. Determine the influence of droplet interactions on the flammability limits and extinction behavior of droplet arrays.” (text)
- [[Microgravity]] — “6. Validate theoretical models of droplet combustion through comprehensive experimental data collection in microgravity environments.” (text)
- [[Pressure]] — “The chamber was filled with the appropriate atmosphere, which was varied in pressure between 0.5 atm to 3.0 atm and O2 concentration between 0.1 to 0.4 mole fra” (text)
- [[Suppressant diluent]] — “…varied in pressure between 0.5 atm to 3.0 atm and O2 concentration between 0.1 to 0.4 mole fraction with the diluent gas making up the balance. A settling time” (text)
- [[Temperature]] — “…. A settling time of approximately 2 minutes elapsed prior to initiating the test in order to ensure that the temperature and pressure of the chamber gases hav” (text)
- [[Ignition]] — “…r real-time download of the color camera video was employed in order to verify successful droplet deployment, ignition, and overall progress of the experiment.” (text)
- [[Radiative heat loss]] — “…herent complexity of the problem, varying degrees of approximations have been made in treating the chemistry, radiation, and the coupling between the gas and l” (text)
- [[Buoyancy]] — “By conducting these experiments in a microgravity environment, the effects of buoyancy are minimized, and the droplet can be characterized only as a function of” (text)
- [[Spacecraft fire safety]] — “FLEX-2 Flame Extinguishment Experiment - 2. Spacecraft Fire Safety. Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA)” (text)
- [[Combustion Integrated Rack]] — “FLEX-2 Flame Extinguishment Experiment - 2. Spacecraft Fire Safety. Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA)” (text)
- [[Multi-user Droplet Combustion Apparatus]] — “FLEX-2 Flame Extinguishment Experiment - 2. Spacecraft Fire Safety. Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA)” (text)
- [[Diffusion flame]] — “…pported by Cool-Flame chemistry near diffusive extinction; Radiative extinction of burner-supported spherical diffusion flames: A scaling analysis; Unsteady dr” (text)
- [[Cool flame]] — “…y experiments; Droplet Combustion Experiments Aboard the International Space Station; Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet” (text)
- [[Burning rate]] — “…ion of Methanol and Heptane Droplets; ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates; Combustion of Butanol, Gasoline, a” (text)
- [[Earth]] — “…ers on vaporizing fuel droplets; Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity; Microgravity droplet combustion:” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA) Glenn Research Center (GRC)” (metadata)
- [[Multi-user Droplet Combustion Apparatus]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), Multi-user Droplet Combustion Appartatus (MDCA) Glenn Research Center (GRC)” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[FLEX]] — “FLEX-2 (08-12-2016) follows FLEX (08-01-2007) in the FLEX family” (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[CFI]] · extends
- [[Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmospher]] · describes
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments]] · describes
- [[Droplet Combustion Experiments Aboard the International Space Station]] · describes
- [[Multistage oscillatory “Cool Flame” behavior for isolated alkane droplet combustion in elevated pressure micro]] · describes
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced ]] · describes
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and Heptane Droplets]] · describes
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates]] · describes
- [[Combustion of Butanol, Gasoline, and Butanol Gasoline Mixture Droplets]] · describes
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St]] · describes
- [[The effect of support fibers on micro-convection in droplet combustion experiments]] · describes
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity]] · describes
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures]] · describes
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets]] · describes
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity]] · describes
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion]] · describes
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model]] · describes
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical]] · describes
- [[The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tall]] · describes
- [[Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A]] · describes
- [[AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS]] · describes
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st]] · describes
- [[A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane]] · describes
- [[Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convectio]] · describes
- [[Can cool flames support quasi-steady alkane droplet burning]] · describes
- [[Experiments on Submillimeter Free Droplet Flame Extinction (2)]] · describes
- [[Influences of support fibers on vaporizing fuel droplets (2)]] · describes
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity (2)]] · describes
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure (2)]] · describes
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets  (2)]] · describes
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments (2)]] · describes
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity (2)]] · describes
- [[Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle  (2)]] · describes
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in  (2)]] · describes
- [[Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets (2)]] · describes
- [[Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets (2)]] · describes
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments (2)]] · describes
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY (2)]] · describes
- [[Developing Surrogates for Liquid Transportation Fuels The Role of Spherically Symmetric Droplet Combustion (2)]] · describes
- [[Experimental Observations of the Low-Temperature Burning of Decane Hexanol Droplets in Microgravity]] · describes
- [[Cool-flame dodecane-droplet extinction diameters]] · describes
- [[Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction]] · describes
- [[Radiative extinction of burner-supported spherical diffusion flames A scaling analysis]] · describes
- [[Unsteady droplet combustion with fuel thermal expansion]] · describes
- [[Radiative extinction of large n-alkane droplets in oxygen-inert mixtures in microgravity]] · describes
- [[A Burke-Schumann analysis of dual-flame structure supported by a burning droplet]] · describes
- [[A Burke–Schumann analysis of diffusion-flame structures supported by a burning droplet]] · describes
- [[Dynamic Differential Image Circle Diameter Measurement Precision Assessment Application to Burning Droplets]] · describes
- [[Interpretation of Backlit Droplet Images from ISS Droplet Combustion Experiments (2)]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[Computational and Experimental Analysis of SPICE Data Sets]] · shares concept
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · shares concept
