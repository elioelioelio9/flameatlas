---
id: "pub:199"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830601161567"
generated: "Fire Lab knowledge engine"
---

# Numerical and experimental observations of spherical diffusion flames

Santa K. J., Sun Z., Chao B. H., Sunderland P. B., Axelbaum R. L., Urban D. L., Stocker D. P.

DOI: [10.1080/13647830601161567](https://doi.org/10.1080/13647830601161567)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Numerical and experimental observations of spherical diffusion flames” (text)
