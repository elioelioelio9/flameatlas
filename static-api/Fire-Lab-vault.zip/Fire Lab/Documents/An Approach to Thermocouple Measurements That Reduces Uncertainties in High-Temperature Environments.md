---
id: "pub:187"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1021/acs.energyfuels.5b00071"
generated: "Fire Lab knowledge engine"
---

# An Approach to Thermocouple Measurements That Reduces Uncertainties in High-Temperature Environments

Krishnan Siddharth, Kumfer Benjamin M., Wu Wendong, Li Jichuan, Nehorai Arye, Axelbaum Richard L.

DOI: [10.1021/acs.energyfuels.5b00071](https://doi.org/10.1021/acs.energyfuels.5b00071)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Temperature]] — “An Approach to Thermocouple Measurements That Reduces Uncertainties in High-Temperature Environments” (text)
