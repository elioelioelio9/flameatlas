---
id: "pub:342"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2021.111471"
generated: "Fire Lab knowledge engine"
---

# The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes

Zhou Mengni, Yehia Omar R., Xu Wenbin, Reuter Christopher B., Wang Ziyu, Yan Chao, Jiang Bo, Ju Yiguang

DOI: [10.1016/j.combustflame.2021.111471](https://doi.org/10.1016/j.combustflame.2021.111471)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Oxygen concentration]] — “The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Diffusion flame]] — “The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Premixed flame]] — “The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Cool flame]] — “The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
