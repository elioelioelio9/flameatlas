---
id: "pub:271"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0010-2180(97)00051-5"
generated: "Fire Lab knowledge engine"
---

# On the response of spherical premixed flames under rotation

Qian J., Bechtold J.K., Law C.K.

DOI: [10.1016/S0010-2180(97)00051-5](https://doi.org/10.1016/S0010-2180(97)00051-5)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Premixed flame]] — “On the response of spherical premixed flames under rotation” (text)
