---
id: "pub:258"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2009.02.002"
generated: "Fire Lab knowledge engine"
---

# Numerical prediction of ion current from a small methane jet flame

Yamashita Kiyotaka, Karnani Sunny, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2009.02.002](https://doi.org/10.1016/j.combustflame.2009.02.002)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Numerical prediction of ion current from a small methane jet flame” (text)
