---
id: "pub:113"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102200903190851"
generated: "Fire Lab knowledge engine"
---

# Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments

Wei J. B., Shaw B. D.

DOI: [10.1080/00102200903190851](https://doi.org/10.1080/00102200903190851)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments” (text)
- [[Droplet combustion]] — “Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments” (text)
- [[Suppressant diluent]] — “Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments” (text)
