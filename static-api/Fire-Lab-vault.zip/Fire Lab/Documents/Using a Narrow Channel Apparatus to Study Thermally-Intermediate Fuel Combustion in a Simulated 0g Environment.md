---
id: "pub:26"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Using a Narrow Channel Apparatus to Study Thermally-Intermediate Fuel Combustion in a Simulated 0g Environment

G Bornand, G Sullivan, T Shah, F Miller

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)
