---
id: "pub:38"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s10694-019-00863-3"
generated: "Fire Lab knowledge engine"
---

# Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity

Olson Sandra L., Urban David L., Ruff Gary A., Ferkul Paul V., Toth Balazs, Eigenbrod Christian, Meyer Florian, Jomaas Grunde

DOI: [10.1007/s10694-019-00863-3](https://doi.org/10.1007/s10694-019-00863-3)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity” (text)
- [[Microgravity]] — “Concurrent Flame Spread Over Two-Sided Thick PMMA Slabs in Microgravity” (text)
