---
id: "pub:74"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2013.09.011"
generated: "Fire Lab knowledge engine"
---

# Isolated n-heptane droplet combustion in microgravity: “Cool Flames” – Two-stage combustion

Farouk Tanvir I., Dryer Frederick L.

DOI: [10.1016/j.combustflame.2013.09.011](https://doi.org/10.1016/j.combustflame.2013.09.011)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Isolated n-heptane droplet combustion in microgravity: “Cool Flames” – Two-stage combustion” (text)
- [[Droplet combustion]] — “Isolated n-heptane droplet combustion in microgravity: “Cool Flames” – Two-stage combustion” (text)
- [[Cool flame]] — “Isolated n-heptane droplet combustion in microgravity: “Cool Flames” – Two-stage combustion” (text)
