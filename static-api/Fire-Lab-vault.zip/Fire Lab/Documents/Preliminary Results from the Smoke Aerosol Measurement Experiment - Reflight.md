---
id: "pub:47"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Preliminary Results from the Smoke Aerosol Measurement Experiment - Reflight

D Urban, G Ruff, M Meyer, T Cleary, J Yang, G Mulholland, ZG Yuan, V Bryg

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME-R]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Preliminary Results from the Smoke Aerosol Measurement Experiment - Reflight” (text)
