---
id: "pub:269"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0082-0784(96)80296-7"
generated: "Fire Lab knowledge engine"
---

# Extinction mechanisms of near-limit premixed flames and extended limits of flammability

Sung C.J., Law C.K.

DOI: [10.1016/S0082-0784(96)80296-7](https://doi.org/10.1016/S0082-0784(96)80296-7)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Extinction mechanisms of near-limit premixed flames and extended limits of flammability” (text)
- [[Premixed flame]] — “Extinction mechanisms of near-limit premixed flames and extended limits of flammability” (text)
- [[Material flammability]] — “Extinction mechanisms of near-limit premixed flames and extended limits of flammability” (text)
