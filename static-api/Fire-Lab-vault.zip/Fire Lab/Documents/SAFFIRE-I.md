---
id: "doc:PSI-98"
type: "document"
aliases: ["SAFFIRE-I"]
tags: ["fire-lab/document", "family/SAFFIRE"]
doi: "10.60555/0t15-1z43"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-98"
generated: "Fire Lab knowledge engine"
---

# SAFFIRE-I — Spacecraft Fire Safety Experiment-I

First large-scale spacecraft fire experiment, run in a Cygnus cargo vehicle after it left the ISS: how fast a large fire grows in low gravity, and how low-g flammability compares with NASA's 1-g screening test.

DOI: [10.60555/0t15-1z43](https://doi.org/10.60555/0t15-1z43)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Saffire 1 enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[Cygnus cargo vehicle]] — “International Space Station (ISS) Saffire 1 enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Saffire 1 enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[Microgravity]] — “…acecraft fire experiment, run in a Cygnus cargo vehicle after it left the ISS: how fast a large fire grows in low gravity, and how low-g flammability compares” (text)
- [[Material flammability]] — “…un in a Cygnus cargo vehicle after it left the ISS: how fast a large fire grows in low gravity, and how low-g flammability compares with NASA's 1-g screening t” (text)
- [[Earth]] — “…it left the ISS: how fast a large fire grows in low gravity, and how low-g flammability compares with NASA's 1-g screening test.” (text)
- [[Pressure]] — “…e, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemom” (text)
- [[Forced flow]] — “…of the duct with flow straighteners at the bottom of the experiment module. Saffire-I was conducted at an air flow velocity of 20 cm/s. Once the sample was ign” (text)
- [[Smoke detection]] — “…mocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2” (text)
- [[Radiative heat loss]] — “…eras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measu” (text)
- [[Suppressant diluent]] — “…me temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemometer track” (text)
- [[Temperature]] — “…ited flame images were captured using two cameras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radi” (text)
- [[Spacecraft fire safety]] — “…behavior in normal and reduced gravity, the use of terrestrial fires and fire standards to design spacecraft fire safety systems presents an inherent risk to t” (text)
- [[Smoke]] — “SAFFIRE-I Spacecraft Fire Safety Experiment-I. Spacecraft Fire, Smoke Distribution. Saffire 1 enclosure in Cygnus” (text)
- [[Flame spread]] — “…Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire); Flame spread: Effects of microgravity and scale;” (text)
- [[Buoyancy]] — “The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status; Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraf” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SAFFIRE-II]] (metadata)
- [[SAFFIRE-III]] (metadata)
- [[BASS]] (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 2 values, 0.215–0.216 - (table)
- [[Flow velocity]] — 2 values, 20–20 cm/s (table)
- [[Fuel thickness (2)]] — 2 values, 3.7–3.7 mm (table)
- [[Burn time]] — 2 values, 70–420 s (table)
- [[ignition power w]] — 2 values, 182–182 W (table)
- [[ignition time s]] — 2 values, 8–8 s (table)
- [[sample length cm]] — 2 values, 40.6–40.6 cm (table)
- [[sample width cm]] — 2 values, 94–94 cm (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Scale matters only SAFFIRE burned spacecraft-size samples]] — “SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the onl” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SAFFIRE-III]] · references
- [[SAFFIRE-III]] · extends
- [[The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status]] · describes
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)]] · describes
- [[Flame spread Effects of microgravity and scale]] · describes
- [[Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgr]] · describes
- [[Fire safety in space – beyond flammability testing of small samples]] · describes
- [[Operation and Development Status of the Spacecraft Fire Experiments (Saffire)]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[DAFT DAFT-2]] · shares concept
- [[Computational and Experimental Analysis of SPICE Data Sets]] · shares concept
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · shares concept
- [[FLEX-2]] · shares concept
- [[FLEX]] · shares concept
