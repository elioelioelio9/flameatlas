---
id: "pub:301"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2005-1141"
generated: "Fire Lab knowledge engine"
---

# An Experimental Study on the Response of Spherical Diffusion Flames Subjected to Rotation and Nonequidiffusion

Zhu Delin, Yoo Sean, Law C, Sacksteder Kurt

DOI: [10.2514/6.2005-1141](https://doi.org/10.2514/6.2005-1141)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “An Experimental Study on the Response of Spherical Diffusion Flames Subjected to Rotation and Nonequidiffusion” (text)
