---
id: "pub:196"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2009.07.009"
generated: "Fire Lab knowledge engine"
---

# Characteristics of non-premixed oxygen-enhanced combustion: I. The presence of appreciable oxygen at the location of maximum temperature

Skeen S.A., Yablonsky G., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2009.07.009](https://doi.org/10.1016/j.combustflame.2009.07.009)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Characteristics of non-premixed oxygen-enhanced combustion: I. The presence of appreciable oxygen at the location of maximum temperature” (text)
- [[Premixed flame]] — “Characteristics of non-premixed oxygen-enhanced combustion: I. The presence of appreciable oxygen at the location of maximum temperature” (text)
- [[Temperature]] — “Characteristics of non-premixed oxygen-enhanced combustion: I. The presence of appreciable oxygen at the location of maximum temperature” (text)
