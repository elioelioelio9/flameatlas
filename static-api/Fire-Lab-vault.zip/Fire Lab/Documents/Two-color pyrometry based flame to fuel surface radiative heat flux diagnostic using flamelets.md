---
id: "pub:329"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2021.111395"
generated: "Fire Lab knowledge engine"
---

# Two-color pyrometry based flame to fuel surface radiative heat flux diagnostic using flamelets

Aphale Siddhant S., DesJardin Paul E.

DOI: [10.1016/j.combustflame.2021.111395](https://doi.org/10.1016/j.combustflame.2021.111395)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Radiative heat loss]] — “Two-color pyrometry based flame to fuel surface radiative heat flux diagnostic using flamelets” (text)
