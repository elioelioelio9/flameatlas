---
id: "pub:9"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.05.076"
generated: "Fire Lab knowledge engine"
---

# A novel apparatus for flame spread study

S Bhattacharjee, M Bundy, C Paolini, G Patel, W Tran.

DOI: [10.1016/j.proci.2012.05.076](https://doi.org/10.1016/j.proci.2012.05.076)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “A novel apparatus for flame spread study” (text)
