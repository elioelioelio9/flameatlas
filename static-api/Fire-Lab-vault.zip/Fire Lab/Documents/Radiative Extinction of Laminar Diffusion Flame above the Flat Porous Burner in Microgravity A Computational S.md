---
id: "pub:213"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1134/S0010508220040036"
generated: "Fire Lab knowledge engine"
---

# Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study

Kuznetsov E. A., Snegirev A. Yu., Markus E. S.

DOI: [10.1134/S0010508220040036](https://doi.org/10.1134/S0010508220040036)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study” (text)
- [[Microgravity]] — “Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study” (text)
- [[Diffusion flame]] — “Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study” (text)
- [[Radiative heat loss]] — “Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study” (text)
- [[Numerical modeling]] — “Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study” (text)
