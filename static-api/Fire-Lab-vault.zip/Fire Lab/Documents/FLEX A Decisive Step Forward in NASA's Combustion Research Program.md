---
id: "pub:70"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# FLEX: A Decisive Step Forward in NASA's Combustion Research Program

JM Hickman, DL Dietrich, MC Hicks, V Nayagam, D Stocker

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)
