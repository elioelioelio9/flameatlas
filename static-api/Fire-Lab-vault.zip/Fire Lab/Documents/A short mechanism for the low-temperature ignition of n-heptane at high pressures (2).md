---
id: "pub:88"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.fuel.2014.08.063"
generated: "Fire Lab knowledge engine"
---

# A short mechanism for the low-temperature ignition of n-heptane at high pressures

Prince Juan C., Williams Forman A., Ovando Guillermo E.

DOI: [10.1016/j.fuel.2014.08.063](https://doi.org/10.1016/j.fuel.2014.08.063)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Ignition]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
- [[Pressure]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
- [[Temperature]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
