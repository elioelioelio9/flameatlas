---
id: "pub:50"
type: "document"
tags: ["fire-lab/document"]
doi: "10.4271/2008-01-2089"
generated: "Fire Lab knowledge engine"
---

# Measurement of Smoke Particle Size under Low-Gravity Conditions

Urban David L., Ruff Gary A., Mulholland George W., Cleary Thomas G., Yang Jiann C., Yuan Zengguang

DOI: [10.4271/2008-01-2089](https://doi.org/10.4271/2008-01-2089)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Measurement of Smoke Particle Size under Low-Gravity Conditions” (text)
- [[Particle size]] — “Measurement of Smoke Particle Size under Low-Gravity Conditions” (text)
