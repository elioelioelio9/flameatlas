---
id: "pub:228"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2017.1403051"
generated: "Fire Lab knowledge engine"
---

# Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames: A computational and experimental study

Cao Su, Ma Bin, Giassi Davide, Bennett Beth Anne V., Long Marshall B., Smooke Mitchell D.

DOI: [10.1080/13647830.2017.1403051](https://doi.org/10.1080/13647830.2017.1403051)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames: A computational and experimental study” (text)
- [[Diffusion flame]] — “Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames: A computational and experimental study” (text)
- [[Suppressant diluent]] — “Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames: A computational and experimental study” (text)
- [[Numerical modeling]] — “Effects of pressure and fuel dilution on coflow laminar methane–air diffusion flames: A computational and experimental study” (text)
