---
id: "doc:PSI-108"
type: "document"
aliases: ["STDCE-1"]
tags: ["fire-lab/document", "family/Out-of-scope"]
doi: "10.60555/j1z3-bw42"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-108"
generated: "Fire Lab knowledge engine"
---

# STDCE-1 — Surface Tension Driven Convection Experiment-1

Surface-tension-driven convection — not a combustion investigation.

DOI: [10.60555/j1z3-bw42](https://doi.org/10.60555/j1z3-bw42)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Space Shuttle]] — “Space Shuttle STDCE Hardware Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “Space Shuttle STDCE Hardware Glenn Research Center (GRC)” (metadata)
- [[Temperature]] — “-Temperature distributions along the free surface and in the bulk fluid.” (text)
- [[Microgravity]] — “…ompassed a combination of theoretical analysis, numerical modeling, ground-based experiments, and ultimately, microgravity experiments aboard the Space Shuttle” (text)
- [[Numerical modeling]] — “…plexities of thermocapillary flow. This strategy encompassed a combination of theoretical analysis, numerical modeling, ground-based experiments, and ultimatel” (text)
- [[Fuel thickness]] — “…entists established scaling laws that characterized the behavior of key flow features, such as boundary layer thicknesses and velocity scales. This theoretical” (text)
- [[Buoyancy]] — “…towers and other reduced-gravity facilities to observe thermocapillary flows under conditions with minimized buoyancy effects. These experiments served as a st” (text)
- [[Drop tower]] — “Reduced-Gravity Simulations: Researchers conducted experiments in drop towers and other reduced-gravity facilities to observe thermocapillary flows under condit” (text)
- [[Earth]] — “…environment to study thermocapillary flows over a broader range of parameters and conditions than possible on Earth. This included meticulous execution of the” (text)
- [[Particle size]] — “…hniques: The development and refinement of non-intrusive measurement techniques, such as infrared imaging and particle image velocimetry, for the STDCE have ex” (text)
- [[Suppressant diluent]] — “…ns of High Prandtl Number Fluids; Oscillatory thermocapillary flows in open cylindrical containers induced by CO2 laser heating; Oscillatory Thermocapillary Fl” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Surface Tension Driven Convection Experiment Completed]] · describes
- [[Containment of a silicone fluid free surface in reduced gravity using barrier coatings]] · describes
- [[Infrared Surface Temperature Measurements for the Surface Tension Driven Convection Experiment]] · describes
- [[Development of an Infrared Imaging System for the Surface Tension Driven Convection Experiment]] · describes
- [[Particle Image Velocimetry for the Surface Tensions Driven Convection Experiment Using a Particle Displacement]] · describes
- [[Thermocapillary flow under microgravity — Experimental results]] · describes
- [[Theoretical Analysis of Thermocapillary Flow in Cylindrical Columns of High Prandtl Number Fluids]] · describes
- [[Oscillatory thermocapillary flows in open cylindrical containers induced by CO2 laser heating]] · describes
- [[Oscillatory Thermocapillary Flow in Cylindrical Columns of High Prandtl Number Fluids]] · describes
- [[Effects of Heating Mode on Steady Axisymmetric Thermocapillary Flows in Microgravity]] · describes
- [[Oscillatory convection due to combined buoyancy and thermocapillarity]] · describes
- [[A Thermocapillary Convection Experiment in Microgravity]] · describes
- [[An experimental study of free surface deformation in oscillatory thermocapillary flow]] · describes
- [[Analysis of velocity data taken in Surface Tension Driven Convection Experiment in microgravity]] · describes
- [[Revisiting the NASA surface tension driven convection experiments]] · describes
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
