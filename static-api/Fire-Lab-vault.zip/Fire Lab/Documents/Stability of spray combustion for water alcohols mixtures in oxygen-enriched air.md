---
id: "pub:191"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.05.088"
generated: "Fire Lab knowledge engine"
---

# Stability of spray combustion for water/alcohols mixtures in oxygen-enriched air

Yi Fei, Axelbaum Richard L.

DOI: [10.1016/j.proci.2012.05.088](https://doi.org/10.1016/j.proci.2012.05.088)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Oxygen concentration]] — “Stability of spray combustion for water/alcohols mixtures in oxygen-enriched air” (text)
