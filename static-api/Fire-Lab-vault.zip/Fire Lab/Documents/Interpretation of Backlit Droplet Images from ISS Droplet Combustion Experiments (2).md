---
id: "pub:164"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2478/gsr-2014-0007"
generated: "Fire Lab knowledge engine"
---

# Interpretation of Backlit Droplet Images from ISS Droplet Combustion Experiments

Yu Fei, Shaw Benjamin D.

DOI: [10.2478/gsr-2014-0007](https://doi.org/10.2478/gsr-2014-0007)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Interpretation of Backlit Droplet Images from ISS Droplet Combustion Experiments” (text)
