---
id: "pub:19"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2016.06.025"
generated: "Fire Lab knowledge engine"
---

# Radiative, thermal, and kinetic regimes of opposed-flow flame spread: A comparison between experiment and theory

Bhattacharjee Subrata, Simsek Aslihan, Miller Fletcher, Olson Sandra, Ferkul Paul

DOI: [10.1016/j.proci.2016.06.025](https://doi.org/10.1016/j.proci.2016.06.025)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Radiative, thermal, and kinetic regimes of opposed-flow flame spread: A comparison between experiment and theory” (text)
- [[Radiative heat loss]] — “Radiative, thermal, and kinetic regimes of opposed-flow flame spread: A comparison between experiment and theory” (text)
