---
id: "pub:45"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection

D Urban, G Ruff, G Mulholland, M Meyer, ZG Yuan, T Cleary, J Yang, P Greenberg, V Bryg

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME-R]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection” (text)
- [[Particle size]] — “Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection” (text)
- [[Smoke detection]] — “Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection” (text)
