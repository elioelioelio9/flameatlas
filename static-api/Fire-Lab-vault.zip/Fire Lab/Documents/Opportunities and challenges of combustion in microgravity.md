---
id: "pub:266"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/0360-1285(94)90006-X"
generated: "Fire Lab knowledge engine"
---

# Opportunities and challenges of combustion in microgravity

Law C.K., Faeth G.M.

DOI: [10.1016/0360-1285(94)90006-X](https://doi.org/10.1016/0360-1285(94)90006-X)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Opportunities and challenges of combustion in microgravity” (text)
