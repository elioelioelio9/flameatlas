---
id: "pub:176"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2022.07.049"
generated: "Fire Lab knowledge engine"
---

# On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation heat loss

Irace Phillip H., Waddell Kendyl A., Constales Denis, Kim Minhyeng, Yablonsky Gregory, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.proci.2022.07.049](https://doi.org/10.1016/j.proci.2022.07.049)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation heat loss” (text)
- [[Diffusion flame]] — “On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation heat loss” (text)
- [[Radiative heat loss]] — “On the existence of steady-state gaseous microgravity spherical diffusion flames in the presence of radiation heat loss” (text)
