---
id: "pub:32"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.actaastro.2014.11.025"
generated: "Fire Lab knowledge engine"
---

# Fire safety in space – beyond flammability testing of small samples

Jomaas Grunde, Torero Jose L., Eigenbrod Christian, Niehaus Justin, Olson Sandra L., Ferkul Paul V., Legros Guillaume, Fernandez-Pello A. Carlos, Cowlard Adam J., Rouvreau Sebastien, Smirnov Nickolay, Fujita Osamu, T׳ien James S., Ruff Gary A., Urban David L.

DOI: [10.1016/j.actaastro.2014.11.025](https://doi.org/10.1016/j.actaastro.2014.11.025)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-I]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Material flammability]] — “Fire safety in space – beyond flammability testing of small samples” (text)
- [[Spacecraft fire safety]] — “Fire safety in space – beyond flammability testing of small samples” (text)
