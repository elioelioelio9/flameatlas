---
id: "doc:PSI-115"
type: "document"
tags: ["fire-lab/document", "family/Ground-study"]
doi: "10.60555/q0v5-1v28"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-115"
generated: "Fire Lab knowledge engine"
---

# Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Generation in Micro-Gravity

Uses SAME data for advanced modelling and simulation of smoke generation in microgravity.

DOI: [10.60555/q0v5-1v28](https://doi.org/10.60555/q0v5-1v28)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[NASA Glenn Research Center]] — “Not Applicable  Glenn Research Center (GRC)” (metadata)
- [[Microgravity]] — “Uses SAME data for advanced modelling and simulation of smoke generation in microgravity.” (text)
- [[Smoke]] — “Uses SAME data for advanced modelling and simulation of smoke generation in microgravity.” (text)
- [[Numerical modeling]] — “Uses SAME data for advanced modelling and simulation of smoke generation in microgravity.” (text)
- [[Earth]] — “…fundamental perspective. The intention of this effort is to quantify the differences between microgravity and Earth gravity smoke, and to identify the fluid dy” (text)
- [[Buoyancy]] — “…dered in the SAME experiments. This study considered two cross-flow velocities of sufficiently low speed that buoyancy cannot be neglected in the presence of g” (text)
- [[Particle size]] — “…uoyancy cannot be neglected in the presence of gravity. Simulations are presented to assess the dependence of particle size distributions on thermophoresis, pa” (text)
- [[Forced flow]] — “…space under consideration.The differences in the wake geometry attributable to buoyancy for the lower of two flow speeds was examined. Instantaneous scalar fie” (text)
- [[Temperature]] — “Without buoyancy, mixing and heat transfer are reduced, the time-temperature history of the combustion vapors (or particle precursors) and particle trajectories” (text)
- [[Smoke detection]] — “…erature, gravity, and material properties affect the smoke produced. This would directly lead to better smoke detection devices and prevent fires that can lead” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SAME]] (metadata)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[SAME-R]] (metadata)
- [[SAME]] (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME BRE]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[BASS-II]] (inferred)
- [[DAFT DAFT-2]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
