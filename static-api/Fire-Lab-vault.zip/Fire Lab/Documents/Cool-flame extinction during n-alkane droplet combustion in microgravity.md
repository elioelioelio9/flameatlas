---
id: "pub:127"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Cool-flame extinction during n-alkane droplet combustion in microgravity

V Nayagam, DL Dietrich, MC Hicks, FA Williams

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Microgravity]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Droplet combustion]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Cool flame]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
