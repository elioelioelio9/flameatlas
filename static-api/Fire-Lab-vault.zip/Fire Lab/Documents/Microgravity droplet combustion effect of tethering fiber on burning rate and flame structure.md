---
id: "pub:105"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2010.547601"
generated: "Fire Lab knowledge engine"
---

# Microgravity droplet combustion: effect of tethering fiber on burning rate and flame structure

Farouk T., Dryer F. L.

DOI: [10.1080/13647830.2010.547601](https://doi.org/10.1080/13647830.2010.547601)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Microgravity droplet combustion: effect of tethering fiber on burning rate and flame structure” (text)
- [[Droplet combustion]] — “Microgravity droplet combustion: effect of tethering fiber on burning rate and flame structure” (text)
- [[Burning rate]] — “Microgravity droplet combustion: effect of tethering fiber on burning rate and flame structure” (text)
