---
id: "pub:322"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Smoke Points of Microgravity and Normal Gravity Coflow Diffusion

KT Dotson

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Smoke Points of Microgravity and Normal Gravity Coflow Diffusion” (text)
- [[Smoke]] — “Smoke Points of Microgravity and Normal Gravity Coflow Diffusion” (text)
