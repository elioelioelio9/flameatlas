---
id: "pub:253"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2016.06.193"
generated: "Fire Lab knowledge engine"
---

# Impinging nonpremixed coflow methane–air flames with unity Lewis number

M. Sauer Vinicius, Dunn-Rankin Derek

DOI: [10.1016/j.proci.2016.06.193](https://doi.org/10.1016/j.proci.2016.06.193)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Impinging nonpremixed coflow methane–air flames with unity Lewis number” (text)
