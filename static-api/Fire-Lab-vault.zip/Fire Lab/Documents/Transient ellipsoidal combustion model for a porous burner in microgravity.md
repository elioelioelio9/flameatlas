---
id: "pub:214"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2019.09.030"
generated: "Fire Lab knowledge engine"
---

# Transient ellipsoidal combustion model for a porous burner in microgravity

Markan Akshit, Baum Howard R., Sunderland Peter B., Quintiere James G., de Ris John L.

DOI: [10.1016/j.combustflame.2019.09.030](https://doi.org/10.1016/j.combustflame.2019.09.030)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Transient ellipsoidal combustion model for a porous burner in microgravity” (text)
