---
id: "pub:351"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames

CB. Reuter, E. Lin, Y. Ju

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames” (text)
- [[Diffusion flame]] — “Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames” (text)
- [[Radiative heat loss]] — “Pressure and Radiation Effects on the Dynamics of Hot and Cool Diffusion Flames” (text)
