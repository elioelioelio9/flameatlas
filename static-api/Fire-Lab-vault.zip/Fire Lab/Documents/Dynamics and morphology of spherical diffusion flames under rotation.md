---
id: "pub:304"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2012-1251"
generated: "Fire Lab knowledge engine"
---

# Dynamics and morphology of spherical diffusion flames under rotation

S Yoo, S Chaudhuri, K Sacksteder, P Zhang, D Zhu, C Law

DOI: [10.2514/6.2012-1251](https://doi.org/10.2514/6.2012-1251)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Dynamics and morphology of spherical diffusion flames under rotation” (text)
