---
id: "pub:116"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Detailed results from the flame extinugishment experiment (FLEX) - March 2009 to December 2011

DL Dietrich, VM Bryg, PV Ferkul, FA Williams, FL Dryer, BD Shaw, MY Choi, MV Nayagam, MC Hicks, CT Avedisian

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)
