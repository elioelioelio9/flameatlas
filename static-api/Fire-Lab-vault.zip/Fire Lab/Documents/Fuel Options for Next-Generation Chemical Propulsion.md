---
id: "pub:286"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/1.J051328"
generated: "Fire Lab knowledge engine"
---

# Fuel Options for Next-Generation Chemical Propulsion

Law Chung K.

DOI: [10.2514/1.J051328](https://doi.org/10.2514/1.J051328)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
