---
id: "pub:343"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.01.006"
generated: "Fire Lab knowledge engine"
---

# On the propagation limits and speeds of premixed cool flames at elevated pressures

Ju Yiguang

DOI: [10.1016/j.combustflame.2017.01.006](https://doi.org/10.1016/j.combustflame.2017.01.006)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “On the propagation limits and speeds of premixed cool flames at elevated pressures” (text)
- [[Premixed flame]] — “On the propagation limits and speeds of premixed cool flames at elevated pressures” (text)
- [[Cool flame]] — “On the propagation limits and speeds of premixed cool flames at elevated pressures” (text)
