---
id: "pub:23"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits

JW Marcum, SL Olson, PV Ferkul

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits” (text)
- [[Forced flow]] — “Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits” (text)
- [[Microgravity]] — “Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits” (text)
