---
id: "pub:168"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2014.934296"
generated: "Fire Lab knowledge engine"
---

# The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets

Paczko Guenter, Peters Norbert, Seshadri Kalyanasundaram, Williams Forman Arthur

DOI: [10.1080/13647830.2014.934296](https://doi.org/10.1080/13647830.2014.934296)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[CFI]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets” (text)
- [[Droplet combustion]] — “The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets” (text)
- [[Cool flame]] — “The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets” (text)
