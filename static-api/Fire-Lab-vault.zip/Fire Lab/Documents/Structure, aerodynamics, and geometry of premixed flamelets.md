---
id: "pub:274"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0360-1285(00)00018-6"
generated: "Fire Lab knowledge engine"
---

# Structure, aerodynamics, and geometry of premixed flamelets

Law C.K, Sung C.J

DOI: [10.1016/S0360-1285(00)00018-6](https://doi.org/10.1016/S0360-1285(00)00018-6)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Premixed flame]] — “Structure, aerodynamics, and geometry of premixed flamelets” (text)
