---
id: "pub:221"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2022.08.107"
generated: "Fire Lab knowledge engine"
---

# Demonstrating steady burning for small flat materials in microgravity in a quiescent ambient

Dehghani Parham, de Ris John L., Quintiere James G.

DOI: [10.1016/j.proci.2022.08.107](https://doi.org/10.1016/j.proci.2022.08.107)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Demonstrating steady burning for small flat materials in microgravity in a quiescent ambient” (text)
