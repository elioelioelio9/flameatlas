---
id: "pub:320"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2004.12.009"
generated: "Fire Lab knowledge engine"
---

# Shapes of nonbuoyant round hydrocarbon-fueled laminar-jet diffusion flames in still air

Aalburg C., Diez F.J., Faeth G.M., Sunderland P.B., Urban D.L., Yuan Z.-G.

DOI: [10.1016/j.combustflame.2004.12.009](https://doi.org/10.1016/j.combustflame.2004.12.009)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Shapes of nonbuoyant round hydrocarbon-fueled laminar-jet diffusion flames in still air” (text)
