---
id: "pub:245"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2009.08.008"
generated: "Fire Lab knowledge engine"
---

# Ionization and chemiluminescence during the progressive aeration of methane flames

Weinberg Felix, Carleton Fred

DOI: [10.1016/j.combustflame.2009.08.008](https://doi.org/10.1016/j.combustflame.2009.08.008)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)
