---
id: "pub:326"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.03.001"
generated: "Fire Lab knowledge engine"
---

# Microgravity flammability boundary for PMMA rods in axial stagnation flow: Experimental results and energy balance analyses (2017)

Olson Sandra L., Ferkul Paul V.

DOI: [10.1016/j.combustflame.2017.03.001](https://doi.org/10.1016/j.combustflame.2017.03.001)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Microgravity flammability boundary for PMMA rods in axial stagnation flow: Experimental results and energy balance analyses (2017)” (text)
- [[Material flammability]] — “Microgravity flammability boundary for PMMA rods in axial stagnation flow: Experimental results and energy balance analyses (2017)” (text)
