---
id: "pub:96"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2012.04.005"
generated: "Fire Lab knowledge engine"
---

# On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical study

Farouk Tanvir I., Dryer Frederick L.

DOI: [10.1016/j.combustflame.2012.04.005](https://doi.org/10.1016/j.combustflame.2012.04.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical study” (text)
- [[Microgravity]] — “On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical study” (text)
- [[Droplet combustion]] — “On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical study” (text)
