---
id: "pub:233"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.carbon.2011.07.050"
generated: "Fire Lab knowledge engine"
---

# A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames

Herdman Jennifer D., Connelly Blair C., Smooke Mitchell D., Long Marshall B., Miller J. Houston

DOI: [10.1016/j.carbon.2011.07.050](https://doi.org/10.1016/j.carbon.2011.07.050)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames” (text)
- [[Premixed flame]] — “A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames” (text)
- [[Soot]] — “A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames” (text)
- [[Numerical modeling]] — “A comparison of Raman signatures and laser-induced incandescence with direct numerical simulation of soot growth in non-premixed ethylene/air flames” (text)
