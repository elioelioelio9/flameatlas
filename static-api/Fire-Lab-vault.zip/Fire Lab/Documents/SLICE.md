---
id: "doc:PSI-106"
type: "document"
aliases: ["SLICE"]
tags: ["fire-lab/document", "family/MSG-duct"]
doi: "10.60555/pm12-rg61"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-106"
generated: "Fire Lab knowledge engine"
---

# SLICE — Structure and Liftoff In Combustion Experiment

Liftoff and stabilisation of jet flames in co-flow — how flames anchor or blow off.

DOI: [10.60555/pm12-rg61](https://doi.org/10.60555/pm12-rg61)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS)  Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS)  Glenn Research Center (GRC)” (metadata)
- [[Diffusion flame]] — “Liftoff and stabilisation of jet flames in co-flow — how flames anchor or blow off.” (text)
- [[Microgravity]] — “…tive of this investigation is to better understand the structure and stability of laminar diffusion flames in microgravity.” (text)
- [[Soot]] — “3. Evaluate the impact of fuel dilution with nitrogen on soot formation and flame stability.” (text)
- [[Suppressant diluent]] — “3. Evaluate the impact of fuel dilution with nitrogen on soot formation and flame stability.” (text)
- [[Radiative heat loss]] — “4. Quantify the effects of microgravity on flame length and radiative heat loss compared to normal gravity conditions.” (text)
- [[Earth]] — “4. Quantify the effects of microgravity on flame length and radiative heat loss compared to normal gravity conditions.” (text)
- [[Premixed flame]] — “5. Validate numerical models for flame dynamics, soot production, and thermal radiation in non-premixed flames.” (text)
- [[Numerical modeling]] — “5. Validate numerical models for flame dynamics, soot production, and thermal radiation in non-premixed flames.” (text)
- [[Forced flow]] — “…resolution camera captured still images while sensor data was overlaid on these images. Calibration tests for airflow velocity, soot measurement, and the fans” (text)
- [[Smoke detection]] — “The SLICE apparatus consisted of a fan-driven flow duct, exchangeable burner tubes, and integrated sensors to measure flow rates and temperature. This setup use” (text)
- [[Temperature]] — “…sisted of a fan-driven flow duct, exchangeable burner tubes, and integrated sensors to measure flow rates and temperature. This setup used several fuels such a” (text)
- [[Spacecraft fire safety]] — “3. Insights into flame stability and behavior to enhance fire safety.” (text)
- [[Heat release]] — “…ormation in a coflow jet flame under microgravity and normal gravity; Analysis of CH* concentration and flame heat release rate in laminar coflow diffusion fla” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SPICE]] (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SPICE]] (inferred)
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] (inferred)
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (inferred)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (inferred)
- [[ACME CFI-G]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SPICE]] · extends
- [[A computational and experimental study of coflow laminar methane air diffusion flames Effects of fuel dilution (3)]] · describes
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2)]] · describes
- [[Effects of Fuel Dilution and Gravity on Laminar Coflow Methane-Air Diffusion Flames A Computational and Experi]] · describes
- [[An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal  (2)]] · describes
- [[Analysis of CH concentration and flame heat release rate in laminar coflow diffusion flames under microgravity (2)]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
