---
id: "pub:37"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.10.016"
generated: "Fire Lab knowledge engine"
---

# Buoyancy effects on concurrent flame spread over thick PMMA

Thomsen Maria, Fernandez-Pello Carlos, Ruff Gary A., Urban David L.

DOI: [10.1016/j.combustflame.2018.10.016](https://doi.org/10.1016/j.combustflame.2018.10.016)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Buoyancy effects on concurrent flame spread over thick PMMA” (text)
- [[Buoyancy]] — “Buoyancy effects on concurrent flame spread over thick PMMA” (text)
