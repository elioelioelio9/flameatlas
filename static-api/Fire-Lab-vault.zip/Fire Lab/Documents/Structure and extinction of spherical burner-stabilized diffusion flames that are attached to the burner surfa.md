---
id: "pub:184"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.08.024"
generated: "Fire Lab knowledge engine"
---

# Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surface

Rodenhurst Melvin K., Chao Beei-Huan, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.combustflame.2017.08.024](https://doi.org/10.1016/j.combustflame.2017.08.024)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surface” (text)
- [[Diffusion flame]] — “Structure and extinction of spherical burner-stabilized diffusion flames that are attached to the burner surface” (text)
