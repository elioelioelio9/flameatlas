---
id: "pub:14"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2015.10.023"
generated: "Fire Lab knowledge engine"
---

# The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and theoretical results

Bhattacharjee Subrata, Simsek Aslihan, Olson Sandra, Ferkul Paul

DOI: [10.1016/j.combustflame.2015.10.023](https://doi.org/10.1016/j.combustflame.2015.10.023)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
- [[Extinction]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
- [[Forced flow]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
- [[Microgravity]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
- [[Radiative heat loss]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
- [[Numerical modeling]] — “The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment: A comparison of experimental, computational, and” (text)
