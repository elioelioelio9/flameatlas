---
id: "pub:121"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced gravity

N Ghata, BD Shaw

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced gravity” (text)
- [[Droplet combustion]] — “Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced gravity” (text)
- [[Numerical modeling]] — “Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced gravity” (text)
