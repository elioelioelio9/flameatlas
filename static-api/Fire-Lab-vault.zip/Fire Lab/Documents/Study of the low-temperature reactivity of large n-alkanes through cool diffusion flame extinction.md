---
id: "pub:344"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.01.028"
generated: "Fire Lab knowledge engine"
---

# Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction

Reuter Christopher B., Lee Minhyeok, Won Sang Hee, Ju Yiguang

DOI: [10.1016/j.combustflame.2017.01.028](https://doi.org/10.1016/j.combustflame.2017.01.028)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction” (text)
- [[Diffusion flame]] — “Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction” (text)
- [[Temperature]] — “Study of the low-temperature reactivity of large n-alkanes through cool diffusion flame extinction” (text)
