---
id: "pub:268"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/0010-2180(94)00102-X"
generated: "Fire Lab knowledge engine"
---

# On the structure, stabilization, and dual response of flat-burner flames

Eng J.A., Zhu D.L., Law C.K.

DOI: [10.1016/0010-2180(94)00102-X](https://doi.org/10.1016/0010-2180(94)00102-X)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
