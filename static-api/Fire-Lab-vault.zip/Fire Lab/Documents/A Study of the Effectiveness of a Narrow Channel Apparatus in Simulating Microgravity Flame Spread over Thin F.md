---
id: "pub:21"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2012-3493"
generated: "Fire Lab knowledge engine"
---

# A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin Fuels

Pepper Jacob, Miller Fletcher, Olson Sandra, Wichman Indrek

DOI: [10.2514/6.2012-3493](https://doi.org/10.2514/6.2012-3493)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin Fuels” (text)
- [[Microgravity]] — “A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin Fuels” (text)
- [[Fuel thickness]] — “A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin Fuels” (text)
