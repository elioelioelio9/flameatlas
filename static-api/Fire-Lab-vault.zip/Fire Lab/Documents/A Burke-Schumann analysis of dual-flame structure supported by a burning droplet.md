---
id: "pub:161"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.icheatmasstransfer.2017.06.016"
generated: "Fire Lab knowledge engine"
---

# A Burke-Schumann analysis of dual-flame structure supported by a burning droplet

Nayagam Vedha, Dietrich Daniel L., Williams Forman A.

DOI: [10.1016/j.icheatmasstransfer.2017.06.016](https://doi.org/10.1016/j.icheatmasstransfer.2017.06.016)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “A Burke-Schumann analysis of dual-flame structure supported by a burning droplet” (text)
