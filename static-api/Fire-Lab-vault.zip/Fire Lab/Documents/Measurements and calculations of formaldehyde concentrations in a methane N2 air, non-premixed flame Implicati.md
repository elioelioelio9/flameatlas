---
id: "pub:239"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2008.05.083"
generated: "Fire Lab knowledge engine"
---

# Measurements and calculations of formaldehyde concentrations in a methane/N2/air, non-premixed flame: Implications for heat release rate

Dworkin S.B., Schaffer A.M., Connelly B.C., Long M.B., Smooke M.D., Puccio M.A., McAndrew B., Miller J.H.

DOI: [10.1016/j.proci.2008.05.083](https://doi.org/10.1016/j.proci.2008.05.083)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Measurements and calculations of formaldehyde concentrations in a methane/N2/air, non-premixed flame: Implications for heat release rate” (text)
- [[Premixed flame]] — “Measurements and calculations of formaldehyde concentrations in a methane/N2/air, non-premixed flame: Implications for heat release rate” (text)
- [[Heat release]] — “Measurements and calculations of formaldehyde concentrations in a methane/N2/air, non-premixed flame: Implications for heat release rate” (text)
