---
id: "pub:361"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/2.6207"
generated: "Fire Lab knowledge engine"
---

# Oscillatory Thermocapillary Flow in Cylindrical Columns of High Prandtl Number Fluids

Masud J., Kamotani Y., Ostrach S.

DOI: [10.2514/2.6207](https://doi.org/10.2514/2.6207)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
