---
id: "pub:291"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.06.015"
generated: "Fire Lab knowledge engine"
---

# Extended flammability limits of n-heptane/air mixtures with cool flames

Liang Wenkai, Law Chung K.

DOI: [10.1016/j.combustflame.2017.06.015](https://doi.org/10.1016/j.combustflame.2017.06.015)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Cool flame]] — “Extended flammability limits of n-heptane/air mixtures with cool flames” (text)
- [[Material flammability]] — “Extended flammability limits of n-heptane/air mixtures with cool flames” (text)
