---
id: "pub:155"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2016.1225730"
generated: "Fire Lab knowledge engine"
---

# Experimental Observations of the Low-Temperature Burning of Decane/Hexanol Droplets in Microgravity

Dietrich D. L., Calabria R., Massoli P., Nayagam V., Williams F. A.

DOI: [10.1080/00102202.2016.1225730](https://doi.org/10.1080/00102202.2016.1225730)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Experimental Observations of the Low-Temperature Burning of Decane/Hexanol Droplets in Microgravity” (text)
- [[Droplet combustion]] — “Experimental Observations of the Low-Temperature Burning of Decane/Hexanol Droplets in Microgravity” (text)
- [[Temperature]] — “Experimental Observations of the Low-Temperature Burning of Decane/Hexanol Droplets in Microgravity” (text)
