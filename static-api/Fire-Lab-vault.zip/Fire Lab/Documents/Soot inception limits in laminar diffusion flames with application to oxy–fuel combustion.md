---
id: "pub:197"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2008.03.008"
generated: "Fire Lab knowledge engine"
---

# Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion

Kumfer B.M., Skeen S.A., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2008.03.008](https://doi.org/10.1016/j.combustflame.2008.03.008)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion” (text)
- [[Soot]] — “Soot inception limits in laminar diffusion flames with application to oxy–fuel combustion” (text)
