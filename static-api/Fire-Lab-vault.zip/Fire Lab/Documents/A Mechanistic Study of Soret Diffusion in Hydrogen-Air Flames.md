---
id: "pub:302"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2009-988"
generated: "Fire Lab knowledge engine"
---

# A  Mechanistic Study of Soret Diffusion in Hydrogen-Air Flames

Yang Fan, Law C.K., Sung C.J., Zhang Huiqiang

DOI: [10.2514/6.2009-988](https://doi.org/10.2514/6.2009-988)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
