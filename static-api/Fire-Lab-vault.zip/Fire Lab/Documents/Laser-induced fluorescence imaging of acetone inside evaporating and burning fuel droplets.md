---
id: "pub:112"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.optlaseng.2008.08.002"
generated: "Fire Lab knowledge engine"
---

# Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets

Shringi D.S., Shaw B.D., Dwyer H.A.

DOI: [10.1016/j.optlaseng.2008.08.002](https://doi.org/10.1016/j.optlaseng.2008.08.002)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets” (text)
