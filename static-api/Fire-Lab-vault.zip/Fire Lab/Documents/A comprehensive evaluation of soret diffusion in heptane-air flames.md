---
id: "pub:303"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# A comprehensive evaluation of soret diffusion in heptane-air flames

YX Xin, CJ Sung, CK Law

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
