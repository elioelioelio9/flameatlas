---
id: "doc:PSI-69"
type: "document"
aliases: ["FLEX"]
tags: ["fire-lab/document", "family/FLEX"]
doi: "10.60555/mbq8-0451"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-69"
generated: "Fire Lab knowledge engine"
---

# FLEX — Flame Extinguishment Experiment

Flammability limits of liquid fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extinction diameter and end state.

DOI: [10.60555/mbq8-0451](https://doi.org/10.60555/mbq8-0451)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combustion Appartatus (MDCA) Glenn R” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combustion Appartatus (MDCA) Glenn R” (metadata)
- [[Extinction]] — “…rogravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extinction diameter and end state.” (text)
- [[Microgravity]] — “Flammability limits of liquid fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extincti” (text)
- [[Droplet combustion]] — “Flammability limits of liquid fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extincti” (text)
- [[Burning rate]] — “…d fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extinction diameter and end state.” (text)
- [[Material flammability]] — “Flammability limits of liquid fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet test…” (text)
- [[Suppressant diluent]] — “Flammability limits of liquid fuels in microgravity and effectiveness of gaseous suppressants (CO2, He) — 274 droplet tests with measured burning rate, extincti” (text)
- [[Soot]] — “…e obtaining high-resolution measurements of droplet burning rates, flame extinction behavior, heat radiation, soot levels, and temperature profiles, while syst” (text)
- [[Radiative heat loss]] — “…oals include obtaining high-resolution measurements of droplet burning rates, flame extinction behavior, heat radiation, soot levels, and temperature profiles,” (text)
- [[Temperature]] — “…resolution measurements of droplet burning rates, flame extinction behavior, heat radiation, soot levels, and temperature profiles, while systematically analyz” (text)
- [[Spacecraft fire safety]] — “…e essential for advancing the fundamental understanding of combustion processes in microgravity and enhancing fire safety protocols for future space missions.” (text)
- [[Pressure]] — “…primary objective of the experiments is to determine the Limiting Oxygen Index (LOI) as a function of ambient pressure and determine how the presence of a supp” (text)
- [[Oxygen concentration]] — “3. Select an ambient oxygen mole fraction that, based on ground-based testing, will support droplets burning to completion (as opposed to extinguishing…” (text)
- [[Ignition]] — “6. Continue steps 4 and 5 until flame exists for only a short time after ignition (radiative extinction).” (text)
- [[Buoyancy]] — “…iameters. Near the end of the tests, prior to flame extinction, the droplet will be subjected to a small, sub-buoyant, convective flow (imparted by translating” (text)
- [[Earth]] — “…ifferences in the flammability limits and suppression efficacy of various fire suppressant agents compared to normal gravity conditions. This hypothesis underp” (text)
- [[Cool flame]] — “…e suppression systems, reducing the risk of toxic byproducts during fire events. Additionally, the study of ''cool flames'' and low-temperature combustion proc” (text)
- [[Combustion Integrated Rack]] — “FLEX Flame Extinguishment Experiment. Spacecraft Fire Safety. Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combusti” (text)
- [[Multi-user Droplet Combustion Apparatus]] — “…nt Experiment. Spacecraft Fire Safety. Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combustion Appartatus (MDCA)” (text)
- [[Diffusion flame]] — “…in microgravity: “Cool Flames” – Two-stage combustion; Theory of the propagation dynamics of spiral edges of diffusion flames in von Kármán swirling flows; Ana” (text)
- [[Numerical modeling]] — “…teady n-heptane droplet combustion supported by cool-flame chemistry; n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments; Droplet” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combustion Appartatus (MDCA) Glenn R” (metadata)
- [[Multi-user Droplet Combustion Apparatus]] — “International Space Station (ISS) Combustion Integrated Rack (CIR)-Fluids and Combustion Facility (FCF), Multi-user Droplet Combustion Appartatus (MDCA) Glenn R” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 274 values, 0.12–0.34 - (table)
- [[Pressure (2)]] — 273 values, 70.168–309.295 kPa (table)
- [[CO2 mole fraction]] — 274 values, 0–0.7 - (table)
- [[Helium mole fraction]] — 274 values, 0–0.45 - (table)
- [[Burn time]] — 266 values, 0.3–39.2 s (table)
- [[Burning-rate constant K]] — 258 values, 0.05–1.06 mm²/s (table)
- [[Initial droplet diameter]] — 262 values, 1.1–4.67 mm (table)
- [[Flame extinction diameter]] — 197 values, 0–4.6 mm (table)
- [[n2 mole frac]] — 274 values, 0.09–0.88 mole fraction (table)

## Contains related data
_Inferred: both sides hold data for the same quantity, or test conditions fall inside the target envelope._

- [[Atmosphere — ISS Earth-normal cabin]] (table)
- [[Atmosphere — Mars surface habitat]] (table)

## Supports
_The source is cited as evidence for the target finding._

- [[More oxygen droplet flames more often survive to burnout]] — “FLEX droplet tests in N2-only atmospheres that ended in flame extinction before burnout — Heptane: 5/17 at 21 % O2 vs 0/11 at 30–34 % O2; Methanol: 9/12 at 21 %” (computed)
- [[FLEX compares CO2 and helium as gaseous suppressants]] — “At 21 % O2, share of FLEX tests ending in flame extinction before burnout by atmosphere — N2 only: 14/29; CO2: 13/18; He: 7/7. FLEX varied CO2 up to 0.7 and He” (computed)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[CFI]] · references
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · references
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · depends on
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · references
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · depends on
- [[FLEX-2]] · extends
- [[Methanol Droplet Combustion in Oxygen-Inert Environments in Microgravity]] · describes
- [[Methanol Droplet Extinction in Oxygen Carbon-dioxide Nitrogen Mixtures in Microgravity Results from the Intern]] · describes
- [[A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions]] · describes
- [[Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions]] · describes
- [[FLEX A Decisive Step Forward in NASA's Combustion Research Program]] · describes
- [[Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity]] · describes
- [[Activation energy asymptotics for methanol droplet extinction in microgravity]] · describes
- [[Experimental Study of Initial Diameter Effects on Convection-free Droplet Combustion in the Standard Atmospher (2)]] · describes
- [[Isolated n-heptane droplet combustion in microgravity “Cool Flames” – Two-stage combustion (2)]] · describes
- [[Theory of the propagation dynamics of spiral edges of diffusion flames in von Kármán swirling flows]] · describes
- [[Analysis of the melt phase of a rotating polymer disc supporting a diffusion flame]] · describes
- [[Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames (2)]] · describes
- [[Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry (2)]] · describes
- [[n-Butanol droplet combustion Numerical modeling and reduced gravity experiments (2)]] · describes
- [[Droplet Combustion Experiments Aboard the International Space Station (2)]] · describes
- [[Computational modeling of the effects of support fibers on evaporation of fiber-supported droplets in reduced  (2)]] · describes
- [[Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets]] · describes
- [[ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates (2)]] · describes
- [[Combustion of n-Butanol, Gasoline, and n-Butanol Gasoline Mixture Droplets]] · describes
- [[Computational Modeling of Unsupported and Fiber-Supported n-Heptane Droplet Combustion in Reduced Gravity A St (2)]] · describes
- [[The effect of support fibers on micro-convection in droplet combustion experiments (2)]] · describes
- [[Cool-flame extinction during n-alkane droplet combustion in microgravity (3)]] · describes
- [[A short mechanism for the low-temperature ignition of n-heptane at high pressures (2)]] · describes
- [[The role of cool-flame chemistry in quasi-steady combustion and extinction of n-heptane droplets (3)]] · describes
- [[Combustion of Submillimeter Heptane Methanol and Heptane Ethanol Droplets in Reduced Gravity (2)]] · describes
- [[Sub-millimeter sized methyl butanoate droplet combustion Microgravity experiments and detailed numerical model (2)]] · describes
- [[On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical (2)]] · describes
- [[The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tall (2)]] · describes
- [[Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A (2)]] · describes
- [[AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS (2)]] · describes
- [[On the extinction characteristics of alcohol droplet combustion under microgravity conditions – A numerical st (2)]] · describes
- [[A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane (2)]] · describes
- [[Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convectio (2)]] · describes
- [[Can cool flames support quasi-steady alkane droplet burning (3)]] · describes
- [[Experiments on Submillimeter Free Droplet Flame Extinction]] · describes
- [[Influences of support fibers on vaporizing fuel droplets]] · describes
- [[Numerical studies of flows over liquid droplets on cylindrical fibers]] · describes
- [[Interpretation of Backlit Droplet Images from ISS Droplet Combustion Experiments]] · describes
- [[Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity]] · describes
- [[Microgravity droplet combustion effect of tethering fiber on burning rate and flame structure]] · describes
- [[Influence of Gravity and Ambient Pressure on Combustion and Flammability of n-Heptane and 1-Propanol Droplets ]] · describes
- [[Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments]] · describes
- [[Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity]] · describes
- [[Numerical Simulation of Unsteady Flows and Shape Oscillations in Liquid Droplets Induced by Deployment Needle ]] · describes
- [[Nonane droplet combustion with and without buoyant convection Flame structure, burning rate and extinction in ]] · describes
- [[Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets]] · describes
- [[Laser-induced fluorescence imaging of acetone inside evaporating and burning fuel droplets]] · describes
- [[Reduced Gravity Combustion of Propanol Droplets in Oxygen-Inert Environments]] · describes
- [[PROPANOL DROPLET FLAMMABILITY AND COMBUSTION IN AIR-DILUENT ENVIRONMENTS UNDER NORMAL AND REDUCED GRAVITY]] · describes
- [[Developing Surrogates for Liquid Transportation Fuels The Role of Spherically Symmetric Droplet Combustion]] · describes
- [[Detailed results from the flame extinugishment experiment (FLEX) - March 2009 to December 2011]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[Computational and Experimental Analysis of SPICE Data Sets]] · shares concept
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · shares concept
- [[FLEX-2]] · shares concept
