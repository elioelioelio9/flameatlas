---
id: "pub:97"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2011.08.015"
generated: "Fire Lab knowledge engine"
---

# A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane/iso-octane and n-heptane/toluene with a commercial unleaded gasoline

Liu Yu Cheng, Avedisian C. Thomas

DOI: [10.1016/j.combustflame.2011.08.015](https://doi.org/10.1016/j.combustflame.2011.08.015)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “A comparison of the spherical flame characteristics of sub-millimeter droplets of binary mixtures of n-heptane/iso-octane and n-heptane/toluene with a commercia” (text)
