---
id: "pub:270"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0010-2180(97)00069-2"
generated: "Fire Lab knowledge engine"
---

# On the spreading of unsteady cylindrical diffusion flames

Qian J., Law C.K.

DOI: [10.1016/S0010-2180(97)00069-2](https://doi.org/10.1016/S0010-2180(97)00069-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “On the spreading of unsteady cylindrical diffusion flames” (text)
