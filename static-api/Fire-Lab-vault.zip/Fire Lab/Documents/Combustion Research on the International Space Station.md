---
id: "pub:58"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Combustion Research on the International Space Station

Malley, WA Sheredy, DP Stocker

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)
