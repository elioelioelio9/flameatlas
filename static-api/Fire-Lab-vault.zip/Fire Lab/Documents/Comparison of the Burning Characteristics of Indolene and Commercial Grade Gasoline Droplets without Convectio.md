---
id: "pub:139"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1021/ef3007849"
generated: "Fire Lab knowledge engine"
---

# Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convection

Liu Yu Cheng, Savas Anthony J., Avedisian C. Thomas

DOI: [10.1021/ef3007849](https://doi.org/10.1021/ef3007849)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Comparison of the Burning Characteristics of Indolene and Commercial Grade Gasoline Droplets without Convection” (text)
