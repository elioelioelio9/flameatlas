---
id: "pub:42"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status

W Schoren, GA Ruff, DL Urban

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-III]] (metadata)
