---
id: "pub:250"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2022.112067"
generated: "Fire Lab knowledge engine"
---

# PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures

Escofet-Martin David, Chien Yu-Chien, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2022.112067](https://doi.org/10.1016/j.combustflame.2022.112067)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures” (text)
- [[Diffusion flame]] — “PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures” (text)
