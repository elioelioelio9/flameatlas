---
id: "pub:341"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.pecs.2019.100787"
generated: "Fire Lab knowledge engine"
---

# Dynamics of cool flames

Ju Yiguang, Reuter Christopher B., Yehia Omar R., Farouk Tanvir I., Won Sang Hee

DOI: [10.1016/j.pecs.2019.100787](https://doi.org/10.1016/j.pecs.2019.100787)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Cool flame]] — “Dynamics of cool flames” (text)
