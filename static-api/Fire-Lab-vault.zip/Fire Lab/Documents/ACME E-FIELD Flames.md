---
id: "doc:PSI-22"
type: "document"
aliases: ["ACME E-FIELD Flames"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/se5a-8c73"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-22"
generated: "Fire Lab knowledge engine"
---

# ACME E-FIELD Flames — Advanced Combustion via Microgravity Experiments Electric-Field Effects on Laminar Diffusion Flames

Electric-field effects on laminar flames. Noted by the challenge as a way to mimic partial gravity through ion-driven forces — the only partial-gravity proxy in PSI.

DOI: [10.60555/se5a-8c73](https://doi.org/10.60555/se5a-8c73)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[Partial gravity]] — “Electric-field effects on laminar flames. Noted by the challenge as a way to mimic partial gravity through ion-driven forces — the only partial-gravity proxy in” (text)
- [[Diffusion flame]] — “Electric-field effects on laminar flames. Noted by the challenge as a way to mimic partial gravity through ion-driven forces — the only partial-gravit…” (text)
- [[Electric field]] — “Electric-field effects on laminar flames. Noted by the challenge as a way to mimic partial gravity through ion-driven forces…” (text)
- [[Soot]] — “…eld voltage and chemi-ion current, analyze the dynamic response of flames to electric field changes, evaluate soot formation, and characterize stabilized near-” (text)
- [[Buoyancy]] — “…diffusion flames in microgravity. This unique environment is ideal for isolating electric field effects from buoyancy forces.” (text)
- [[Microgravity]] — “…IELD flames experiment investigates how electric fields influence the behavior of laminar diffusion flames in microgravity. This unique environment is ideal fo” (text)
- [[Extinction]] — “…e strength. Dilution levels were varied to explore a range of combustion dynamics, from highly stable to near-extinction flames.” (text)
- [[Forced flow]] — “…r detailed ion-driven convection studies while the coflow burner surrounds the fuel jet with a weak synthetic air flow to enable flame stability and soot behav” (text)
- [[Suppressant diluent]] — “…flame behavior. Methane and ethylene were used as fuels and diluted with nitrogen to control flame strength. Dilution levels were varied to explore a range of” (text)
- [[Smoke detection]] — “…tral imaging with filters measures chemiluminescent emissions and soot volume fraction. There were thermopile detectors to measure flame radiant emissions.” (text)
- [[Combustion Integrated Rack]] — “All experiments were conducted in the combustion integrated rack (CIR). Tests were administered with Glenn Research Center (GRC) directing astronaut actions. Pa” (text)
- [[Earth]] — “…g). The use of electric fields to control flames can reduce the production of harmful pollutants in practical terrestrial combustion. The combustion of fossil” (text)
- [[Pressure]] — “…land, OH 44106.; PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures; Ion current and carbon monoxide releas” (text)
- [[Premixed flame]] — “…al environment using an ion-driven wind.; Detailed characterization of DC electric field effects on small non-premixed flames; Microgravity burner-generated sp” (text)
- [[Carbon monoxide]] — “…hemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures; Ion current and carbon monoxide release from an impinging methane” (text)
- [[Numerical modeling]] — “…aximizing ion-driven gas flows; Inducing gas flow and swirl in tubes using ionic wind from corona discharges; Modeling of Elevated Pressure Diffusion Flames wi” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[ACME s-Flame]] (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[ACME CLD Flame]] — “ACME E-FIELD Flames (11-18-2016) follows ACME CLD Flame (10-01-2006) in the ACME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[Flames ignited]] — 21 values, 8–15 count (table)

## Supports
_The source is cited as evidence for the target finding._

- [[No partial-gravity combustion data yet]] — “PSI currently holds no combustion data at lunar or martian gravity. The challenge notes that microgravity and normal-gravity results can bound intermediate grav” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[Ion Current and Flame Changes with Electric Fields in Microgravity]] · describes
- [[Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface]] · describes
- [[Electrical Aspects of Impinging Flames]] · describes
- [[The Influence of Electric Field Power Systems on Flame Behavior]] · describes
- [[Ionization and chemiluminescence during the progressive aeration of methane flames]] · describes
- [[Modelling electric field driven convection in small combustion plasmas and surrounding gases]] · describes
- [[Canceling buoyancy of gaseous fuel flames in a gravitational environment using an ion-driven wind.]] · describes
- [[Detailed characterization of DC electric field effects on small non-premixed flames]] · describes
- [[Microgravity burner-generated spherical diffusion flames experiment and computation. Currently at Department o]] · describes
- [[PLIF and chemiluminescence in a small laminar coflow methane-air diffusion flame at elevated pressures]] · describes
- [[Ion current and carbon monoxide release from an impinging methane air coflow flame in an electric field]] · describes
- [[Non-premixed axisymmetric flames driven by ion currents]] · describes
- [[Impinging nonpremixed coflow methane–air flames with unity Lewis number]] · describes
- [[Characterizing I-V Curves for Non-Premixed Methane Flames Stabilized on Different Burner Configurations]] · describes
- [[CO emission from an impinging non-premixed flame]] · describes
- [[Electrical aspects of flame quenching]] · describes
- [[Behavior of a small diffusion flame as an electrically active component in a high-voltage circuit]] · describes
- [[Numerical prediction of ion current from a small methane jet flame]] · describes
- [[Electric field-controlled mesoscale burners]] · describes
- [[Numerical simulation of a tubular ion-driven wind generator]] · describes
- [[Using large electric fields to control transport in microgravity.]] · describes
- [[Maximizing ion-driven gas flows]] · describes
- [[Inducing gas flow and swirl in tubes using ionic wind from corona discharges]] · describes
- [[Modeling of Elevated Pressure Diffusion Flames with Water Addition]] · describes
- [[Electric-field effects on methane coflow flames aboard the international space station (ISS) ACME E-FIELD flam]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
