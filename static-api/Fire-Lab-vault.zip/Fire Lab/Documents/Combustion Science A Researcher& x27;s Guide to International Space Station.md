---
id: "pub:309"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Combustion Science: A Researcher&#x27;s Guide to International Space Station

SA Gokoglu, DL Dietrich, DP Stocker, PV Ferkul, SL Olson

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
