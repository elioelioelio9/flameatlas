---
id: "pub:177"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2022.07.043"
generated: "Fire Lab knowledge engine"
---

# Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar

Irace Phillip H., Waddell Kendyl A., Constales Denis, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.proci.2022.07.043](https://doi.org/10.1016/j.proci.2022.07.043)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar” (text)
- [[Microgravity]] — “Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar” (text)
- [[Diffusion flame]] — “Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar” (text)
- [[Radiative heat loss]] — “Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar” (text)
- [[Temperature]] — “Critical temperature and reactant mass flux for radiative extinction of ethylene microgravity spherical diffusion flames at 1 bar” (text)
