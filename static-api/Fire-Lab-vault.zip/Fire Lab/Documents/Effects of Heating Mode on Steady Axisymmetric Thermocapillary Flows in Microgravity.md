---
id: "pub:362"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Effects of Heating Mode on Steady Axisymmetric Thermocapillary Flows in Microgravity

Y Kamotani, A Chang, S Ostrach

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Effects of Heating Mode on Steady Axisymmetric Thermocapillary Flows in Microgravity” (text)
