---
id: "pub:51"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Properties of Smoke from Overheated Spacecraft Materials in Low-Gravity

DL Urban, GA Ruff, W Sheredy, T Cleary, J Yang, G Mulholland, Z Yuan

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Properties of Smoke from Overheated Spacecraft Materials in Low-Gravity” (text)
