---
id: "pub:352"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.07.050"
generated: "Fire Lab knowledge engine"
---

# Transient interactions between a premixed double flame and a vortex

Reuter Christopher B., Katta Viswanath R., Yehia Omar R., Ju Yiguang

DOI: [10.1016/j.proci.2018.07.050](https://doi.org/10.1016/j.proci.2018.07.050)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Premixed flame]] — “Transient interactions between a premixed double flame and a vortex” (text)
