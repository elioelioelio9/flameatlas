---
id: "pub:198"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2007.08.009"
generated: "Fire Lab knowledge engine"
---

# Radiative extinction of gaseous spherical diffusion flames in microgravity

SANTA K, CHAO B, SUNDERLAND P, URBAN D, STOCKER D, AXELBAUM R

DOI: [10.1016/j.combustflame.2007.08.009](https://doi.org/10.1016/j.combustflame.2007.08.009)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Radiative extinction of gaseous spherical diffusion flames in microgravity” (text)
- [[Microgravity]] — “Radiative extinction of gaseous spherical diffusion flames in microgravity” (text)
- [[Diffusion flame]] — “Radiative extinction of gaseous spherical diffusion flames in microgravity” (text)
- [[Radiative heat loss]] — “Radiative extinction of gaseous spherical diffusion flames in microgravity” (text)
