---
id: "pub:5"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1504/PCFD.2012.048249"
generated: "Fire Lab knowledge engine"
---

# Radiation signature in opposed-flow flame spread

Bhattacharjee Subrata, Paolini Christopher P., Miller Fletcher, Nagarkar Rohit

DOI: [10.1504/PCFD.2012.048249](https://doi.org/10.1504/PCFD.2012.048249)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Radiation signature in opposed-flow flame spread” (text)
- [[Radiative heat loss]] — “Radiation signature in opposed-flow flame spread” (text)
