---
id: "pub:178"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2022.112158"
generated: "Fire Lab knowledge engine"
---

# An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen

Irace P.H., Gopan A., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2022.112158](https://doi.org/10.1016/j.combustflame.2022.112158)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen” (text)
- [[Radiative heat loss]] — “An investigation of thermal radiation from laminar diffusion flames in a tri-coflow burner with central oxygen” (text)
