---
id: "pub:6"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1299/jsmeatem.2015.14.289"
generated: "Fire Lab knowledge engine"
---

# OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread: Results of Experiments and Simplified Analysis(invited,Scale modeling on solid combustion,OS24 Scale modeling,FLUID AND THERMODYNAM

Bhattacharjee Subrata, Cartnignani Luca

DOI: [10.1299/jsmeatem.2015.14.289](https://doi.org/10.1299/jsmeatem.2015.14.289)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread: Results of Experiments and Simplified Analysis(invited,Scale modeling o” (text)
- [[Extinction]] — “OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread: Results of Experiments and Simplified Analysis(invited,Scale modeling o” (text)
- [[Numerical modeling]] — “OS24-1 The Effect of Boundary Layer on Blow-Off Extinction in Opposed-Flow Flame Spread: Results of Experiments and Simplified Analysis(invited,Scale modeling o” (text)
