---
id: "pub:53"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2008-806"
generated: "Fire Lab knowledge engine"
---

# Spacecraft Fire Detection: Smoke Properties and Transport in Low-Gravity

Urban David, Ruff Gary, Brooker John, Cleary Thomas, Yang Jiann, Mulholland George, Yuan Zeng-Guang

DOI: [10.2514/6.2008-806](https://doi.org/10.2514/6.2008-806)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Spacecraft Fire Detection: Smoke Properties and Transport in Low-Gravity” (text)
- [[Smoke detection]] — “Spacecraft Fire Detection: Smoke Properties and Transport in Low-Gravity” (text)
