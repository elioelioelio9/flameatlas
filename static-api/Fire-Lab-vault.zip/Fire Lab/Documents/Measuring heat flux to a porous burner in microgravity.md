---
id: "pub:215"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.05.006"
generated: "Fire Lab knowledge engine"
---

# Measuring heat flux to a porous burner in microgravity

Markan Akshit, Sunderland Peter B., Quintiere James G., de Ris John L., Baum Howard R.

DOI: [10.1016/j.proci.2018.05.006](https://doi.org/10.1016/j.proci.2018.05.006)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Measuring heat flux to a porous burner in microgravity” (text)
