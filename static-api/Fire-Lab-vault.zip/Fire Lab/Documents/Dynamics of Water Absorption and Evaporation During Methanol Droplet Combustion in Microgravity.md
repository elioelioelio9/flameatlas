---
id: "pub:71"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity

MC Hicks, DL Dietrich, V Nayagam, FA Williams

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity” (text)
- [[Droplet combustion]] — “Dynamics of Water Absorption and Evaporation During Methanol Droplet Combustion in Microgravity” (text)
