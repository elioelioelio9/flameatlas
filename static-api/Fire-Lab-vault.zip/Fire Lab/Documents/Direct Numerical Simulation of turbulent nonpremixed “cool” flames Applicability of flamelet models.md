---
id: "pub:293"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.06.191"
generated: "Fire Lab knowledge engine"
---

# Direct Numerical Simulation of turbulent nonpremixed “cool” flames: Applicability of flamelet models

Novoselov Alex G., Law Chung K., Mueller Michael E.

DOI: [10.1016/j.proci.2018.06.191](https://doi.org/10.1016/j.proci.2018.06.191)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Direct Numerical Simulation of turbulent nonpremixed “cool” flames: Applicability of flamelet models” (text)
- [[Numerical modeling]] — “Direct Numerical Simulation of turbulent nonpremixed “cool” flames: Applicability of flamelet models” (text)
