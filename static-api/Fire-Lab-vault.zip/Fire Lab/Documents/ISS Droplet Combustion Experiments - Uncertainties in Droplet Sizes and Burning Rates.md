---
id: "pub:123"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s12217-014-9377-x"
generated: "Fire Lab knowledge engine"
---

# ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates

Shaw Benjamin D.

DOI: [10.1007/s12217-014-9377-x](https://doi.org/10.1007/s12217-014-9377-x)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates” (text)
- [[Burning rate]] — “ISS Droplet Combustion Experiments - Uncertainties in Droplet Sizes and Burning Rates” (text)
