---
id: "pub:264"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2023.2182205"
generated: "Fire Lab knowledge engine"
---

# Modeling of Elevated Pressure Diffusion Flames with Water Addition

Chien Yu-Chien, Girodon Hugo, Esquivias Rodriguez Brandon

DOI: [10.1080/00102202.2023.2182205](https://doi.org/10.1080/00102202.2023.2182205)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “Modeling of Elevated Pressure Diffusion Flames with Water Addition” (text)
- [[Diffusion flame]] — “Modeling of Elevated Pressure Diffusion Flames with Water Addition” (text)
- [[Numerical modeling]] — “Modeling of Elevated Pressure Diffusion Flames with Water Addition” (text)
