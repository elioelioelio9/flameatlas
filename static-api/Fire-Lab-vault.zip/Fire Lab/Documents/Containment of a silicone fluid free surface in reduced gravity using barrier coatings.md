---
id: "pub:354"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Containment of a silicone fluid free surface in reduced gravity using barrier coatings

AD Pline, TP Jacobson

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Containment of a silicone fluid free surface in reduced gravity using barrier coatings” (text)
