---
id: "pub:231"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.05.064"
generated: "Fire Lab knowledge engine"
---

# An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal gravity

Ma Bin, Cao Su, Giassi Davide, Stocker Dennis P., Takahashi Fumiaki, Bennett Beth Anne V., Smooke Mitchell D., Long Marshall B.

DOI: [10.1016/j.proci.2014.05.064](https://doi.org/10.1016/j.proci.2014.05.064)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal gravity” (text)
- [[Diffusion flame]] — “An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal gravity” (text)
- [[Soot]] — “An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal gravity” (text)
- [[Numerical modeling]] — “An experimental and computational study of soot formation in a coflow jet flame under microgravity and normal gravity” (text)
