---
id: "pub:260"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.elstat.2007.04.003"
generated: "Fire Lab knowledge engine"
---

# Numerical simulation of a tubular ion-driven wind generator

Rickard Matthew, Dunn-Rankin Derek

DOI: [10.1016/j.elstat.2007.04.003](https://doi.org/10.1016/j.elstat.2007.04.003)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Numerical modeling]] — “Numerical simulation of a tubular ion-driven wind generator” (text)
