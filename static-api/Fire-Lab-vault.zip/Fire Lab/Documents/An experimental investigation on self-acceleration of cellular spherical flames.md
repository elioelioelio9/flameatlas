---
id: "pub:288"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.05.068"
generated: "Fire Lab knowledge engine"
---

# An experimental investigation on self-acceleration of cellular spherical flames

Wu Fujia, Jomaas Grunde, Law Chung K.

DOI: [10.1016/j.proci.2012.05.068](https://doi.org/10.1016/j.proci.2012.05.068)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
