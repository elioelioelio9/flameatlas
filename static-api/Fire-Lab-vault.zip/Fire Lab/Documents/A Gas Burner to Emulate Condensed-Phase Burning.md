---
id: "pub:208"
type: "document"
tags: ["fire-lab/document"]
doi: "10.3850/978-981-07-5936-0_03-01"
generated: "Fire Lab knowledge engine"
---

# A Gas Burner to Emulate Condensed-Phase Burning

Zhang Y., Bustamante M. J., Dotson K. T., Sunderland P. B., Quintiere J. G.

DOI: [10.3850/978-981-07-5936-0_03-01](https://doi.org/10.3850/978-981-07-5936-0_03-01)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)
