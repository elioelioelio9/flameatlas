---
id: "pub:76"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1017/jfm.2011.349"
generated: "Fire Lab knowledge engine"
---

# Analysis of the melt phase of a rotating polymer disc supporting a diffusion flame

Nayagam Vedha, Williams F. A.

DOI: [10.1017/jfm.2011.349](https://doi.org/10.1017/jfm.2011.349)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Analysis of the melt phase of a rotating polymer disc supporting a diffusion flame” (text)
