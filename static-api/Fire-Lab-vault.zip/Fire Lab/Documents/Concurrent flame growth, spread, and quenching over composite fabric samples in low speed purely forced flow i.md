---
id: "pub:20"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2016.06.028"
generated: "Fire Lab knowledge engine"
---

# Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow in microgravity

Zhao Xiaoyang, Liao Ya-Ting T., Johnston Michael C., T'ien James S., Ferkul Paul V., Olson Sandra L.

DOI: [10.1016/j.proci.2016.06.028](https://doi.org/10.1016/j.proci.2016.06.028)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow in microgravity” (text)
- [[Forced flow]] — “Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow in microgravity” (text)
- [[Microgravity]] — “Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow in microgravity” (text)
