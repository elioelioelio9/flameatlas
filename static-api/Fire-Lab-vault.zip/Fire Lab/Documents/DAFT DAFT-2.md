---
id: "doc:PSI-47"
type: "document"
aliases: ["DAFT / DAFT-2"]
tags: ["fire-lab/document", "family/SAME"]
doi: "10.60555/ztgj-d202"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-47"
generated: "Fire Lab knowledge engine"
---

# DAFT / DAFT-2 — Dust and Aerosol Measurement Feasibility Test / Dust and Aerosol Measurement Feasibility Test-2

Risk-reduction test for SAME: checked that a modified commercial condensation particle counter works in microgravity, using a test dust aerosol on the ISS.

DOI: [10.60555/ztgj-d202](https://doi.org/10.60555/ztgj-d202)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) TSI P-Trak Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) TSI P-Trak Glenn Research Center (GRC)” (metadata)
- [[Microgravity]] — “Risk-reduction test for SAME: checked that a modified commercial condensation particle counter works in microgravity, using a test dust aerosol on the ISS.” (text)
- [[Smoke]] — “…ME: checked that a modified commercial condensation particle counter works in microgravity, using a test dust aerosol on the ISS.” (text)
- [[Particle size]] — “Risk-reduction test for SAME: checked that a modified commercial condensation particle counter works in microgravity, using a test dust aerosol on the ISS.” (text)
- [[Smoke detection]] — “Extended duration space flight missions with larger vessels will require fire detection systems with increased reliability and sensitivity. This research will i” (text)
- [[Earth]] — “…aptation of the TSI P-Trak for microgravity can inform the design of instruments for use in other challenging Earth environments, such as submarines or underwa” (text)
- [[Spacecraft fire safety]] — “…2 Dust and Aerosol Measurement Feasibility Test / Dust and Aerosol Measurement Feasibility Test-2. Spacecraft Fire Safety. TSI P-Trak” (text)
- [[Suppressant diluent]] — “A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems; Detection of Smoke from Microgravity Fires” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SAME]] (metadata)

## Supports
_The source is cited as evidence for the target finding._

- [[Dust can look like smoke to a particle counter]] — “DAFT showed that a modified commercial particle counter could be used in microgravity, measuring a test dust aerosol released on the ISS.” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SAME]] · extends
- [[A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems]] · describes
- [[Detection of Smoke from Microgravity Fires]] · describes
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[ACME BRE]] · shares concept
