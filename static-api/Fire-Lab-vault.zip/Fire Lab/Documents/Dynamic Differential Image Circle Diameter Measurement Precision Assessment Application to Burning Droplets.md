---
id: "pub:163"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Dynamic Differential Image Circle Diameter Measurement Precision Assessment: Application to Burning Droplets

RB Rasul, CT Avedisian, Y Xu, MC Hicks, AP Reeves

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Dynamic Differential Image Circle Diameter Measurement Precision Assessment: Application to Burning Droplets” (text)
