---
id: "pub:108"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.ijheatmasstransfer.2010.08.005"
generated: "Fire Lab knowledge engine"
---

# Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity

Jin Y., Shaw B.D.

DOI: [10.1016/j.ijheatmasstransfer.2010.08.005](https://doi.org/10.1016/j.ijheatmasstransfer.2010.08.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity” (text)
- [[Suppressant diluent]] — “Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity” (text)
- [[Numerical modeling]] — “Computational modeling of n-heptane droplet combustion in air–diluent environments under reduced-gravity” (text)
