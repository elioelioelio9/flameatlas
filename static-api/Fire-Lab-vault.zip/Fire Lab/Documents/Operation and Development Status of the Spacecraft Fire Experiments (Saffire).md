---
id: "pub:33"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Operation and Development Status of the Spacecraft Fire Experiments (Saffire)

Gary A. Ruff and David L. Urban.

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-I]] (metadata)
