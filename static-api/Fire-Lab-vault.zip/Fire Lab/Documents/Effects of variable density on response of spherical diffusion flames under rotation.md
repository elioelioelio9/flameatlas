---
id: "pub:282"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.ijheatmasstransfer.2006.12.014"
generated: "Fire Lab knowledge engine"
---

# Effects of variable density on response of spherical diffusion flames under rotation

Yoo S.W., Law C.K.

DOI: [10.1016/j.ijheatmasstransfer.2006.12.014](https://doi.org/10.1016/j.ijheatmasstransfer.2006.12.014)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Effects of variable density on response of spherical diffusion flames under rotation” (text)
