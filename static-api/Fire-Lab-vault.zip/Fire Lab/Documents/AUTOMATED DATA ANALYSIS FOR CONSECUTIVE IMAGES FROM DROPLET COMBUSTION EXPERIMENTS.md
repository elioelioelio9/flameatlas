---
id: "pub:136"
type: "document"
tags: ["fire-lab/document"]
doi: "10.5566/ias.v31.p137-148"
generated: "Fire Lab knowledge engine"
---

# AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS

Dembia Christopher Lee, Liu Yu Cheng, Avedisian C. Thomas

DOI: [10.5566/ias.v31.p137-148](https://doi.org/10.5566/ias.v31.p137-148)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “AUTOMATED DATA ANALYSIS FOR CONSECUTIVE IMAGES FROM DROPLET COMBUSTION EXPERIMENTS” (text)
