---
id: "pub:22"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# BASS-II Summary Report

J Marcum, S Olson, P Ferkul

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)
