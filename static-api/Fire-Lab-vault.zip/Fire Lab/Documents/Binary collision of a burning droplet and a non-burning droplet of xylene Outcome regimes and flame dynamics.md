---
id: "pub:295"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.06.198"
generated: "Fire Lab knowledge engine"
---

# Binary collision of a burning droplet and a non-burning droplet of xylene: Outcome regimes and flame dynamics

Xiong Gang, Gandhi Rahul, Zhong Xiaosheng, Mädler Lutz, Tse Stephen D.

DOI: [10.1016/j.proci.2018.06.198](https://doi.org/10.1016/j.proci.2018.06.198)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Binary collision of a burning droplet and a non-burning droplet of xylene: Outcome regimes and flame dynamics” (text)
