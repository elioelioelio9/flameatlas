---
id: "pub:175"
type: "document"
tags: ["fire-lab/document"]
doi: "10.3390/math11020261"
generated: "Fire Lab knowledge engine"
---

# Soot Formation in Spherical Diffusion Flames

Frolov Sergey M., Ivanov Vladislav S., Frolov Fedor S., Vlasov Pavel A., Axelbaum Richard, Irace Phillip H., Yablonsky Grigoriy, Waddell Kendyl

DOI: [10.3390/math11020261](https://doi.org/10.3390/math11020261)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Soot Formation in Spherical Diffusion Flames” (text)
- [[Soot]] — “Soot Formation in Spherical Diffusion Flames” (text)
