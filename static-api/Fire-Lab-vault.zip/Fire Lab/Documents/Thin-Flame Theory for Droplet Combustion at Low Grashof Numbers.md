---
id: "pub:299"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2005-1140"
generated: "Fire Lab knowledge engine"
---

# Thin-Flame Theory for Droplet Combustion at Low Grashof Numbers

Chen Shr-Jing, Tse Stephen

DOI: [10.2514/6.2005-1140](https://doi.org/10.2514/6.2005-1140)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Thin-Flame Theory for Droplet Combustion at Low Grashof Numbers” (text)
