---
id: "pub:159"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.01.035"
generated: "Fire Lab knowledge engine"
---

# Unsteady droplet combustion with fuel thermal expansion

Nayagam Vedha, Dietrich Daniel L., Williams Forman A.

DOI: [10.1016/j.combustflame.2018.01.035](https://doi.org/10.1016/j.combustflame.2018.01.035)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Unsteady droplet combustion with fuel thermal expansion” (text)
