---
id: "pub:202"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2006.08.004"
generated: "Fire Lab knowledge engine"
---

# Measurement and analysis of soot inception limits of oxygen-enriched coflow flames

Kumfer B.M., Skeen S.A., Chen R., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2006.08.004](https://doi.org/10.1016/j.combustflame.2006.08.004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Oxygen concentration]] — “Measurement and analysis of soot inception limits of oxygen-enriched coflow flames” (text)
- [[Soot]] — “Measurement and analysis of soot inception limits of oxygen-enriched coflow flames” (text)
