---
id: "pub:236"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2008.05.066"
generated: "Fire Lab knowledge engine"
---

# A paradigm shift in the interaction of experiments and computations in combustion research

Connelly B.C., Bennett B.A.V., Smooke M.D., Long M.B.

DOI: [10.1016/j.proci.2008.05.066](https://doi.org/10.1016/j.proci.2008.05.066)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)
