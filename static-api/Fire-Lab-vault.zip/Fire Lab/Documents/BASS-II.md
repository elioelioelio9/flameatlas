---
id: "doc:PSI-25"
type: "document"
aliases: ["BASS-II"]
tags: ["fire-lab/document", "family/BASS"]
doi: "10.60555/4qc4-de67"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-25"
generated: "Fire Lab knowledge engine"
---

# BASS-II — Burning and Suppression of Solids - II

Ignition, flame growth, spread and extinction limits of solid fuels in low-velocity forced flow, including reduced-oxygen runs (initial O2 13.6–22.2 % vol). Data feed the combustion models used to design detection and suppression systems.

DOI: [10.60555/4qc4-de67](https://doi.org/10.60555/4qc4-de67)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)
- [[Flame spread]] — “Ignition, flame growth, spread and extinction limits of solid fuels in low-velocity forced flow, including reduced-oxygen runs (initial O2 1…” (text)
- [[Extinction]] — “Ignition, flame growth, spread and extinction limits of solid fuels in low-velocity forced flow, including reduced-oxygen runs (initial O2 13.6–22.2 % vol)…” (text)
- [[Ignition]] — “Ignition, flame growth, spread and extinction limits of solid fuels in low-velocity forced flow, including reduced-oxy…” (text)
- [[Forced flow]] — “Ignition, flame growth, spread and extinction limits of solid fuels in low-velocity forced flow, including reduced-oxygen runs (initial O2 13.6–22.2 % vol). Dat” (text)
- [[Smoke detection]] — “…w, including reduced-oxygen runs (initial O2 13.6–22.2 % vol). Data feed the combustion models used to design detection and suppression systems.” (text)
- [[Suppressant diluent]] — “…educed-oxygen runs (initial O2 13.6–22.2 % vol). Data feed the combustion models used to design detection and suppression systems.” (text)
- [[Microgravity]] — “…ribute to the combustion computational models used in the design of fire detection and suppression systems in microgravity and on Earth.” (text)
- [[Numerical modeling]] — “BASS-II results contribute to the combustion computational models used in the design of fire detection and suppression systems in microgravity and on Earth.” (text)
- [[Earth]] — “…tion computational models used in the design of fire detection and suppression systems in microgravity and on Earth.” (text)
- [[Material flammability]] — “…between the normal gravity NASA-STD-6001 Test #1 method, ground-based microgravity tests, and actual material flammability in microgravity.” (text)
- [[Oxygen concentration]] — “• Ambient oxygen concentration (via working volume nitrogen vitiation)” (text)
- [[Microgravity Science Glovebox]] — “…ace Station. Active crew support for real-time “lab partner” operations. The wind tunnel was installed in the Microgravity Science Glovebox which supplied powe” (text)
- [[Pressure]] — “…n, burn as well if not better than the same material in normal gravity with other conditions being identical (pressure, O2” (text)
- [[Temperature]] — “concentration, temperature, etc.). NASA tests and controls materials from a flammability perspective using an upward burning test in nor…” (text)
- [[Spacecraft fire safety]] — “A primary goal of BASS-II is improved spacecraft fire safety, improved understanding of combustion in space and how to avoid it. If you’re on a mission far from” (text)
- [[Radiative heat loss]] — “…f microgravity and normal gravity experiments to establish the thermal regime; The critical flow velocity for radiative extinction in opposed-flow flame spread” (text)
- [[Fuel thickness]] — “…s - II (BASS-II) Experiment in the Microgravity Science Glovebox (MSG); Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opp” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Microgravity Science Glovebox]] — “International Space Station (ISS) Microgravity Science Glovebox (MSG) Glenn Research Center (GRC)” (metadata)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[BASS]] (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 129 values, 0.136–0.222 - (table)
- [[Flow velocity]] — 123 values, 0–49 cm/s (table)
- [[Fuel thickness (2)]] — 41 values, 0.1–5 mm (table)
- [[Final CO2]] — 123 values, 0.2–3.22 % vol (table)
- [[co2 initial pct]] — 127 values, 0–1.85 % vol (table)
- [[Final CO]] — 123 values, 0.2–3.22 ppm (table)
- [[co initial ppm]] — 127 values, 0–1.85 ppm (table)
- [[flow sequence]] — 63 values, 0–20 display units (table)
- [[frames shot]] — 123 values, 2–316 count (table)
- [[Final O2]] — 127 values, 0.6–40.4 % vol (table)
- [[sample diameter mm]] — 56 values, 6.35–40 mm (table)
- [[sample width cm]] — 69 values, 1–2 cm (table)

## Supports
_The source is cited as evidence for the target finding._

- [[1-g material screening is not automatically conservative]] — “Spacecraft material selection relies on NASA-STD-6001 Test 1, which ranks materials by 1-g behaviour. BASS and BASS-II were built on the hypothesis that, with a” (text)
- [[BASS-II maps solid-fuel burning down to 13.6 % O2]] — “BASS-II ran 129 tests with initial O2 between 13.6 and 22.2 % vol, mostly on PMMA, SIBAL (cotton-fiberglass fabric), Nomex. Flow annotations record extinction i” (computed)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[BASS]] · references
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · references
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · depends on
- [[BASS]] · extends
- [[Microgravity flammability boundary for PMMA rods in axial stagnation flow Experimental results and energy bala]] · describes
- [[Temperature and CO2 fields of a downward spreading flame over thin cellulose A comparison of experimental and ]] · describes
- [[Opposed-flow flame spread A comparison of microgravity and normal gravity experiments to establish the thermal]] · describes
- [[The critical flow velocity for radiative extinction in opposed-flow flame spread in a microgravity environment]] · describes
- [[Experimental validation of a correlation capturing the boundary layer effect on spread rate in the kinetic reg]] · describes
- [[Results from on-board CSA-CP and CDM Sensor Readings during the Burning and Suppression of Solids - II (BASS-I]] · describes
- [[Modeling and Analysis of Intermediate Thickness PMMA Sheets Burning in Microgravity Opposed Flow]] · describes
- [[Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow i]] · describes
- [[Radiative, thermal, and kinetic regimes of opposed-flow flame spread A comparison between experiment and theor]] · describes
- [[Concurrent flame growth, spread, and quenching over composite fabric samples in low speed purely forced flow i]] · describes
- [[A Study of the Effectiveness of a Narrow Channel Apparatus in Simulating Microgravity Flame Spread over Thin F]] · describes
- [[BASS-II Summary Report]] · describes
- [[Correlation of normal gravity mixed convection blowoff limits with microgravity forced flow blowoff limits]] · describes
- [[Fire in Microgravity]] · describes
- [[Microgravity Flammability of PMMA Rods in Concurrent Flow]] · describes
- [[Using a Narrow Channel Apparatus to Study Thermally-Intermediate Fuel Combustion in a Simulated 0g Environment]] · describes
- [[Burning and Suppression of Solids – II Fire Safety Investigation for the Microgravity Science Glovebox]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[STDCE-1]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
