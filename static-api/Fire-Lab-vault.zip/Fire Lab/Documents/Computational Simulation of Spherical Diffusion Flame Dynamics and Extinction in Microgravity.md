---
id: "pub:308"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity

T Xia

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity” (text)
- [[Microgravity]] — “Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity” (text)
- [[Diffusion flame]] — “Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity” (text)
- [[Numerical modeling]] — “Computational Simulation of Spherical Diffusion Flame Dynamics and Extinction in Microgravity” (text)
