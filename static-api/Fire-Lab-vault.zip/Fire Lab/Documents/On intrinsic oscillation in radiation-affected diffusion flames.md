---
id: "pub:281"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2006.07.183"
generated: "Fire Lab knowledge engine"
---

# On intrinsic oscillation in radiation-affected diffusion flames

Wang H.Y., Law C.K.

DOI: [10.1016/j.proci.2006.07.183](https://doi.org/10.1016/j.proci.2006.07.183)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “On intrinsic oscillation in radiation-affected diffusion flames” (text)
- [[Radiative heat loss]] — “On intrinsic oscillation in radiation-affected diffusion flames” (text)
