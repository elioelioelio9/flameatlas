---
id: "pub:54"
type: "document"
tags: ["fire-lab/document"]
doi: "10.4271/2007-01-3076"
generated: "Fire Lab knowledge engine"
---

# ISS Destiny Laboratory Smoke Detection Model

Brooker John E., Urban David L., Ruff Gary A.

DOI: [10.4271/2007-01-3076](https://doi.org/10.4271/2007-01-3076)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “ISS Destiny Laboratory Smoke Detection Model” (text)
- [[Smoke detection]] — “ISS Destiny Laboratory Smoke Detection Model” (text)
