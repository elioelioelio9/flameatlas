---
id: "pub:252"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.10.036"
generated: "Fire Lab knowledge engine"
---

# Non-premixed axisymmetric flames driven by ion currents

Tinajero Jesse, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2018.10.036](https://doi.org/10.1016/j.combustflame.2018.10.036)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Non-premixed axisymmetric flames driven by ion currents” (text)
- [[Premixed flame]] — “Non-premixed axisymmetric flames driven by ion currents” (text)
