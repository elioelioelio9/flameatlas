---
id: "pub:61"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/02786826.2015.1025125"
generated: "Fire Lab knowledge engine"
---

# Pyrolysis Smoke Generated Under Low-Gravity Conditions

Mulholland George W., Meyer Marit, Urban David L., Ruff Gary A., Yuan Zeng-guang, Bryg Victoria, Cleary Thomas, Yang Jiann

DOI: [10.1080/02786826.2015.1025125](https://doi.org/10.1080/02786826.2015.1025125)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Pyrolysis Smoke Generated Under Low-Gravity Conditions” (text)
