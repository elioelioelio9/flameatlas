---
id: "pub:263"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s00348-005-0062-0"
generated: "Fire Lab knowledge engine"
---

# Inducing gas flow and swirl in tubes using ionic wind from corona discharges

Weinberg Felix, Carleton Fred, Kara Dhiren, Xavier Agatha, Dunn-Rankin Derek, Rickard Matthew

DOI: [10.1007/s00348-005-0062-0](https://doi.org/10.1007/s00348-005-0062-0)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “Inducing gas flow and swirl in tubes using ionic wind from corona discharges” (text)
