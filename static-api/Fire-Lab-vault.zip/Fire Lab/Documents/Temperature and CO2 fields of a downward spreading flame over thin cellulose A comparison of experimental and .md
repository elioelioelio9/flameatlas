---
id: "pub:12"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.05.093"
generated: "Fire Lab knowledge engine"
---

# Temperature and CO2 fields of a downward spreading flame over thin cellulose: A comparison of experimental and computational results

Bhattacharjee Subrata, Paolini Christopher, Tran Wynn, Villaraza Jeanie Ray, Takahashi Shuhei

DOI: [10.1016/j.proci.2014.05.093](https://doi.org/10.1016/j.proci.2014.05.093)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Temperature and CO2 fields of a downward spreading flame over thin cellulose: A comparison of experimental and computational results” (text)
- [[Suppressant diluent]] — “Temperature and CO2 fields of a downward spreading flame over thin cellulose: A comparison of experimental and computational results” (text)
- [[Temperature]] — “Temperature and CO2 fields of a downward spreading flame over thin cellulose: A comparison of experimental and computational results” (text)
- [[Numerical modeling]] — “Temperature and CO2 fields of a downward spreading flame over thin cellulose: A comparison of experimental and computational results” (text)
