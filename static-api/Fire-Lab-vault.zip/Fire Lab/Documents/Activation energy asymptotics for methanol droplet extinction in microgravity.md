---
id: "pub:72"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2013.05.011"
generated: "Fire Lab knowledge engine"
---

# Activation energy asymptotics for methanol droplet extinction in microgravity

Nayagam Vedha

DOI: [10.1016/j.combustflame.2013.05.011](https://doi.org/10.1016/j.combustflame.2013.05.011)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Activation energy asymptotics for methanol droplet extinction in microgravity” (text)
- [[Microgravity]] — “Activation energy asymptotics for methanol droplet extinction in microgravity” (text)
- [[Droplet combustion]] — “Activation energy asymptotics for methanol droplet extinction in microgravity” (text)
