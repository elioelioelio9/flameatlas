---
id: "pub:358"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0273-1177(99)00746-2"
generated: "Fire Lab knowledge engine"
---

# Thermocapillary flow under microgravity — Experimental results

Kamotani Y.

DOI: [10.1016/S0273-1177(99)00746-2](https://doi.org/10.1016/S0273-1177(99)00746-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Thermocapillary flow under microgravity — Experimental results” (text)
