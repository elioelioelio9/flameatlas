---
id: "pub:87"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2015.01.012"
generated: "Fire Lab knowledge engine"
---

# Cool-flame extinction during n-alkane droplet combustion in microgravity

Nayagam Vedha, Dietrich Daniel L., Hicks Michael C., Williams Forman A.

DOI: [10.1016/j.combustflame.2015.01.012](https://doi.org/10.1016/j.combustflame.2015.01.012)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Microgravity]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Droplet combustion]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
- [[Cool flame]] — “Cool-flame extinction during n-alkane droplet combustion in microgravity” (text)
