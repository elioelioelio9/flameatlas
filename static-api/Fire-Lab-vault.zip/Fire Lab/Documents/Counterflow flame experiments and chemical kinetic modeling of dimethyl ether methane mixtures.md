---
id: "pub:345"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2018.06.004"
generated: "Fire Lab knowledge engine"
---

# Counterflow flame experiments and chemical kinetic modeling of dimethyl ether/methane mixtures

Reuter Christopher B., Zhang Rui, Yehia Omar R., Rezgui Yacine, Ju Yiguang

DOI: [10.1016/j.combustflame.2018.06.004](https://doi.org/10.1016/j.combustflame.2018.06.004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Numerical modeling]] — “Counterflow flame experiments and chemical kinetic modeling of dimethyl ether/methane mixtures” (text)
