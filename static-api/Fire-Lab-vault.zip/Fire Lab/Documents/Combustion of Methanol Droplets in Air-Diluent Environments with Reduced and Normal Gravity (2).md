---
id: "pub:143"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1155/2012/587987"
generated: "Fire Lab knowledge engine"
---

# Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity

Shaw Benjamin, Wei Jingbin

DOI: [10.1155/2012/587987](https://doi.org/10.1155/2012/587987)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity” (text)
- [[Suppressant diluent]] — “Combustion of Methanol Droplets in Air-Diluent Environments with Reduced and Normal Gravity” (text)
