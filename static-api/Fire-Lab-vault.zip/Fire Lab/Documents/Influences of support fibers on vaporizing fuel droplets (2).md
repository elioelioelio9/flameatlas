---
id: "pub:142"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Influences of support fibers on vaporizing fuel droplets

D Shringi, HA Dwyer, BD Shaw

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Influences of support fibers on vaporizing fuel droplets” (text)
