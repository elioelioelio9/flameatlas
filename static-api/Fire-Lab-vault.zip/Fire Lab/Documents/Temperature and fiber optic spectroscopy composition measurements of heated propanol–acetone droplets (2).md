---
id: "pub:150"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.optlaseng.2009.05.004"
generated: "Fire Lab knowledge engine"
---

# Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets

Xiao J.S., Wei J.B., Shaw B.D., Peng Z.

DOI: [10.1016/j.optlaseng.2009.05.004](https://doi.org/10.1016/j.optlaseng.2009.05.004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets” (text)
- [[Temperature]] — “Temperature and fiber optic spectroscopy composition measurements of heated propanol–acetone droplets” (text)
