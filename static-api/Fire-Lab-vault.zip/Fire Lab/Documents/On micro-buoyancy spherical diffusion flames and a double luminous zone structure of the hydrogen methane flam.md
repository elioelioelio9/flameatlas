---
id: "pub:273"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0082-0784(98)80108-2"
generated: "Fire Lab knowledge engine"
---

# On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen/methane flame

Sung C.J., Zhu D.L., Law C.K.

DOI: [10.1016/S0082-0784(98)80108-2](https://doi.org/10.1016/S0082-0784(98)80108-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen/methane flame” (text)
- [[Diffusion flame]] — “On micro-buoyancy spherical diffusion flames and a double luminous zone structure of the hydrogen/methane flame” (text)
