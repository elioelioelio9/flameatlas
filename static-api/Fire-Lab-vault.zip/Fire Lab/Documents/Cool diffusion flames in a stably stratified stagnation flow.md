---
id: "pub:173"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2023.112852"
generated: "Fire Lab knowledge engine"
---

# Cool diffusion flames in a stably stratified stagnation flow

Waddell Kendyl A., Lee Han Ju, Nayagam Vedha, Axelbaum Richard L., Sunderland Peter B.

DOI: [10.1016/j.combustflame.2023.112852](https://doi.org/10.1016/j.combustflame.2023.112852)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CFI-G]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Cool diffusion flames in a stably stratified stagnation flow” (text)
