---
id: "pub:255"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2016.09.004"
generated: "Fire Lab knowledge engine"
---

# CO emission from an impinging non-premixed flame

Chien Yu-Chien, Escofet-Martin David, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2016.09.004](https://doi.org/10.1016/j.combustflame.2016.09.004)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “CO emission from an impinging non-premixed flame” (text)
- [[Premixed flame]] — “CO emission from an impinging non-premixed flame” (text)
