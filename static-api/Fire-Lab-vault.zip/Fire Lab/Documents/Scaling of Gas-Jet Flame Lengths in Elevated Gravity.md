---
id: "pub:316"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/978-1-4020-8682-3_22"
generated: "Fire Lab knowledge engine"
---

# Scaling of Gas-Jet Flame Lengths in Elevated Gravity

Sunderland Peter B., Urban David L., Nayagam Vedha

DOI: [10.1007/978-1-4020-8682-3_22](https://doi.org/10.1007/978-1-4020-8682-3_22)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Scaling of Gas-Jet Flame Lengths in Elevated Gravity” (text)
