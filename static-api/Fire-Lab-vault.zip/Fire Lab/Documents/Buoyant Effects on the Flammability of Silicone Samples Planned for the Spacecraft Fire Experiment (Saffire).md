---
id: "pub:29"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)

JE Niehaus, PV Ferkul, SA Gokoglu, GA Ruff

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-I]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)” (text)
- [[Material flammability]] — “Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire)” (text)
