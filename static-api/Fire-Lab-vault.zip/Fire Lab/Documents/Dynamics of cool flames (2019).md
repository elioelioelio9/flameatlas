---
id: "pub:340"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.pecs.2019.100787"
generated: "Fire Lab knowledge engine"
---

# Dynamics of cool flames (2019)

Ju Yiguang, Reuter Christopher B., Yehia Omar R., Farouk Tanvir I., Won Sang Hee

DOI: [10.1016/j.pecs.2019.100787](https://doi.org/10.1016/j.pecs.2019.100787)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Cool flame]] — “Dynamics of cool flames (2019)” (text)
