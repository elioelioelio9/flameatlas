---
id: "pub:128"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# A short mechanism for the low-temperature ignition of n-heptane at high pressures

JC Prince, FA Williams, GE Ovando

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Ignition]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
- [[Pressure]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
- [[Temperature]] — “A short mechanism for the low-temperature ignition of n-heptane at high pressures” (text)
