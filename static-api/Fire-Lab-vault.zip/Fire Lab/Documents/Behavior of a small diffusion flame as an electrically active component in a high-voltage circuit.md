---
id: "pub:257"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2011.06.002"
generated: "Fire Lab knowledge engine"
---

# Behavior of a small diffusion flame as an electrically active component in a high-voltage circuit

Borgatelli Francesco, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2011.06.002](https://doi.org/10.1016/j.combustflame.2011.06.002)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Behavior of a small diffusion flame as an electrically active component in a high-voltage circuit” (text)
