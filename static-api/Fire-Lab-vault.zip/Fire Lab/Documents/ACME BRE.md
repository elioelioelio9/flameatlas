---
id: "doc:PSI-20"
type: "document"
aliases: ["ACME BRE"]
tags: ["fire-lab/document", "family/ACME"]
doi: "10.60555/vb93-3y72"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-20"
generated: "Fire Lab knowledge engine"
---

# ACME BRE — Advanced Combustion via Microgravity Experiments - Burning Rate Emulator

Burning Rate Emulator: burning of condensed-fuel surrogates in still air as a function of material properties, explicitly in NASA-considered crew atmospheres (14.7 psia/21 %, 10.2 psia/26.5 %, 8.2 psia/34 % O2).

DOI: [10.60555/vb93-3y72](https://doi.org/10.60555/vb93-3y72)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)
- [[Oxygen concentration]] — “…ial properties, explicitly in NASA-considered crew atmospheres (14.7 psia/21 %, 10.2 psia/26.5 %, 8.2 psia/34 % O2).” (text)
- [[Pressure]] — “…gates in still air as a function of material properties, explicitly in NASA-considered crew atmospheres (14.7 psia/21 %, 10.2 psia/26.5 %, 8.2 psia/34 % O2).” (text)
- [[Burning rate]] — “Burning Rate Emulator: burning of condensed-fuel surrogates in still air as a function of material properties, explicitly…” (text)
- [[Spacecraft atmosphere]] — “…ion of material properties, explicitly in NASA-considered crew atmospheres (14.7 psia/21 %, 10.2 psia/26.5 %, 8.2 psia/34 % O2).” (text)
- [[Microgravity]] — “The BRE flight program seeks to establish the burning conditions in a quiescent microgravity ambient in terms of material properties.” (text)
- [[Suppressant diluent]] — “2. Consider the conditions of Objective 1 for ambients of O2/CO2 (desired).” (text)
- [[Extinction]] — “3. Consider the conditions of Objectives 1 – 2 for extinction limits.” (text)
- [[Ignition]] — “…r contents, namely choice of diluent, oxygen concentration, and pressure. Fuel flow will commence followed by ignition. The flames will initially be observed w” (text)
- [[Material flammability]] — “…mperature of the burner increases, and the flame remains steady, a continuous set of data is produced for the flammability map.” (text)
- [[Temperature]] — “…by ignition. The flames will initially be observed without varying the fuel flow rate. Because burner surface temperature and heat flux will vary, this will al” (text)
- [[Smoke detection]] — “…extinguish, the surface temperature of the burner will equilibrate, or the temperature limit of the heat flux sensor will be reached. At this time the fuel flo” (text)
- [[Earth]] — “…posed for microgravity, but we will explore these under normal gravity. We believe there is better control on Earth-based ignition testing and that these resul” (text)
- [[Numerical modeling]] — “We will also pursue a CFD model for the quiescent microgravity burning. This will also guide us in the flight experiments, and potentia…” (text)
- [[Smoke]] — “…a function of heat of gasification, reradiation heat flux, applied radiant heat flux, heat of combustion and smoke point.” (text)
- [[Forced flow]] — “…arious condensed-phase materials (such as PMMA and Nylon) was observed in microgravity despite the absence of air flow, where the cessation of ventilation is a” (text)
- [[Spacecraft fire safety]] — “BRE yielded important data relevant to spacecraft fire safety. Quasi-steady burning corresponding to various condensed-phase materials (such as PMMA and Nylon)” (text)
- [[Combustion Integrated Rack]] — “ACME BRE Advanced Combustion via Microgravity Experiments - Burning Rate Emulator. Flames of Gaseous Fuels. Combustion Integrated Rack (CIR), ACME” (text)
- [[Diffusion flame]] — “…y: Experimental results and analysis; Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames; Emulation of condensed fuel fla” (text)
- [[Radiative heat loss]] — “…Microgravity Applications; Burning in microgravity: Experimental results and analysis; Transient dynamics of radiative extinction in low-momentum microgravity” (text)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[Combustion Integrated Rack]] — “International Space Station (ISS) Combustion Integrated Rack (CIR), ACME Glenn Research Center (GRC)” (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[ACME CFI-G]] — “ACME BRE (01-01-2010) follows ACME CFI-G (?) in the ACME family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[O2 mole fraction]] — 43 values, 0.21–0.4 - (table)
- [[Flow velocity]] — 43 values, 0–0 cm/s (table)
- [[burner diameter]] — 43 values, 25–50 mm (table)
- [[flames ignited that day]] — 43 values, 0–21 count (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Stopping ventilation may not be enough in oxygen-enriched cabins]] — “In quiescent microgravity, BRE flames emulating condensed materials (e.g. PMMA, nylon) kept burning quasi-steadily in the elevated-oxygen atmospheres considered” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[DAFT DAFT-2]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[ACME Flame Design]] · extends
- [[Burning on flat wicks at various orientations]] · describes
- [[A Gas Burner to Emulate Condensed-Phase Burning]] · describes
- [[Experimental Investigation of Liquid and Gas Fueled Flames Towards the Development of a Burning Rate Emulator ]] · describes
- [[Burning in microgravity Experimental results and analysis]] · describes
- [[Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames]] · describes
- [[Emulation of condensed fuel flames with gaseous fuels supplied through a porous copper calorimeter]] · describes
- [[Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity A Computational S]] · describes
- [[Transient ellipsoidal combustion model for a porous burner in microgravity]] · describes
- [[Measuring heat flux to a porous burner in microgravity]] · describes
- [[Analysis of extinction and sustained ignition]] · describes
- [[A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity]] · describes
- [[Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner]] · describes
- [[Emulation of condensed fuel flames with gases in microgravity]] · describes
- [[Flammability maps for microgravity burning of a small flat material in a quiescent ambient]] · describes
- [[Demonstrating steady burning for small flat materials in microgravity in a quiescent ambient]] · describes
- [[Theoretical analysis and predictions of burning in microgravity using a burning emulator]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME CFI-G]] · shares concept
