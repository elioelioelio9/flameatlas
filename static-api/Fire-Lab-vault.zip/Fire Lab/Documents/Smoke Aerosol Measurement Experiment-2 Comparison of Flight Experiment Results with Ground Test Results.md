---
id: "pub:44"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2013-3433"
generated: "Fire Lab knowledge engine"
---

# Smoke Aerosol Measurement Experiment-2: Comparison of Flight Experiment Results with Ground Test Results

Meyer Marit E., Urban David L., Ruff Gary A., Mulholland George, Yuan Zeng-guang, Bryg Victoria, Cleary Thomas, Yang Jiann

DOI: [10.2514/6.2013-3433](https://doi.org/10.2514/6.2013-3433)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME-R]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Smoke Aerosol Measurement Experiment-2: Comparison of Flight Experiment Results with Ground Test Results” (text)
