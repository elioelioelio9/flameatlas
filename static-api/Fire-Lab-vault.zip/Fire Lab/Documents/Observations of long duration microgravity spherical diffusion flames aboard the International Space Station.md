---
id: "pub:180"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2021.02.019"
generated: "Fire Lab knowledge engine"
---

# Observations of long duration microgravity spherical diffusion flames aboard the International Space Station

Irace Phillip H., Lee Han Ju, Waddell Kendyl, Tan Logan, Stocker Dennis P., Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.combustflame.2021.02.019](https://doi.org/10.1016/j.combustflame.2021.02.019)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Observations of long duration microgravity spherical diffusion flames aboard the International Space Station” (text)
- [[Diffusion flame]] — “Observations of long duration microgravity spherical diffusion flames aboard the International Space Station” (text)
