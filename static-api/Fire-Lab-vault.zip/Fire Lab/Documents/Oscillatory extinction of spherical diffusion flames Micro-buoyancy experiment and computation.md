---
id: "pub:277"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S1540-7489(02)80008-6"
generated: "Fire Lab knowledge engine"
---

# Oscillatory extinction of spherical diffusion flames: Micro-buoyancy experiment and computation

Yoo S.W., Christiansen E.W., Law C.K.

DOI: [10.1016/S1540-7489(02)80008-6](https://doi.org/10.1016/S1540-7489(02)80008-6)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Oscillatory extinction of spherical diffusion flames: Micro-buoyancy experiment and computation” (text)
- [[Buoyancy]] — “Oscillatory extinction of spherical diffusion flames: Micro-buoyancy experiment and computation” (text)
- [[Diffusion flame]] — “Oscillatory extinction of spherical diffusion flames: Micro-buoyancy experiment and computation” (text)
