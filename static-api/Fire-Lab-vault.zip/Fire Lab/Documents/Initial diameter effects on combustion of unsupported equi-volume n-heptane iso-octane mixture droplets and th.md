---
id: "pub:333"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2020.06.012"
generated: "Fire Lab knowledge engine"
---

# Initial diameter effects on combustion of unsupported equi-volume n-heptane/iso-octane mixture droplets and the transition to cool flame behavior: Experimental observations and detailed numerical modeling (2020)

Xu Yuhao, Farouk Tanvir I., Hicks Michael C., Avedisian C. Thomas

DOI: [10.1016/j.combustflame.2020.06.012](https://doi.org/10.1016/j.combustflame.2020.06.012)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Initial diameter effects on combustion of unsupported equi-volume n-heptane/iso-octane mixture droplets and the transition to cool flame behavior: Experimental” (text)
- [[Cool flame]] — “Initial diameter effects on combustion of unsupported equi-volume n-heptane/iso-octane mixture droplets and the transition to cool flame behavior: Experimental” (text)
- [[Numerical modeling]] — “Initial diameter effects on combustion of unsupported equi-volume n-heptane/iso-octane mixture droplets and the transition to cool flame behavior: Experimental” (text)
