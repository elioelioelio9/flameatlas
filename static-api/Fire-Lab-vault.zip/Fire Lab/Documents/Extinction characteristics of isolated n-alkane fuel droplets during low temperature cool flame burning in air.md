---
id: "pub:331"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2022.07.094"
generated: "Fire Lab knowledge engine"
---

# Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air (2023)

Farouk Tanvir I., Dryer Frederick L.

DOI: [10.1016/j.proci.2022.07.094](https://doi.org/10.1016/j.proci.2022.07.094)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air (2023)” (text)
- [[Droplet combustion]] — “Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air (2023)” (text)
- [[Cool flame]] — “Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air (2023)” (text)
- [[Temperature]] — “Extinction characteristics of isolated n-alkane fuel droplets during low temperature cool flame burning in air (2023)” (text)
