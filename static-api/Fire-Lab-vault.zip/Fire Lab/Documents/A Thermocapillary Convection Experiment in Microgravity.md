---
id: "pub:364"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1115/1.2822621"
generated: "Fire Lab knowledge engine"
---

# A Thermocapillary Convection Experiment in Microgravity

Kamotani Y., Ostrach S., Pline A.

DOI: [10.1115/1.2822621](https://doi.org/10.1115/1.2822621)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “A Thermocapillary Convection Experiment in Microgravity” (text)
