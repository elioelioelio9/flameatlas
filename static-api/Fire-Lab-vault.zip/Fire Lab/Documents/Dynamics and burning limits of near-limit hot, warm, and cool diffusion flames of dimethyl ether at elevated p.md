---
id: "pub:347"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.05.082"
generated: "Fire Lab knowledge engine"
---

# Dynamics and burning limits of near-limit hot, warm, and cool diffusion flames of dimethyl ether at elevated pressures

Lin Eric, Reuter Christopher B., Ju Yiguang

DOI: [10.1016/j.proci.2018.05.082](https://doi.org/10.1016/j.proci.2018.05.082)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Pressure]] — “Dynamics and burning limits of near-limit hot, warm, and cool diffusion flames of dimethyl ether at elevated pressures” (text)
- [[Diffusion flame]] — “Dynamics and burning limits of near-limit hot, warm, and cool diffusion flames of dimethyl ether at elevated pressures” (text)
