---
id: "pub:94"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.05.065"
generated: "Fire Lab knowledge engine"
---

# Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A

Liu Yu Cheng, Savas Anthony J., Thomas Avedisian C.

DOI: [10.1016/j.proci.2012.05.065](https://doi.org/10.1016/j.proci.2012.05.065)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Spherically symmetric droplet combustion of three and four component miscible mixtures as surrogates for Jet-A” (text)
