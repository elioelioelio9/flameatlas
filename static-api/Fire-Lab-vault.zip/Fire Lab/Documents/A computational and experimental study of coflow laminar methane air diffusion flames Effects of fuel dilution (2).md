---
id: "pub:230"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.05.138"
generated: "Fire Lab knowledge engine"
---

# A computational and experimental study of coflow laminar methane/air diffusion flames: Effects of fuel dilution, inlet velocity, and gravity

Cao S., Ma B., Bennett B.A.V., Giassi D., Stocker D.P., Takahashi F., Long M.B., Smooke M.D.

DOI: [10.1016/j.proci.2014.05.138](https://doi.org/10.1016/j.proci.2014.05.138)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “A computational and experimental study of coflow laminar methane/air diffusion flames: Effects of fuel dilution, inlet velocity, and gravity” (text)
- [[Suppressant diluent]] — “A computational and experimental study of coflow laminar methane/air diffusion flames: Effects of fuel dilution, inlet velocity, and gravity” (text)
- [[Numerical modeling]] — “A computational and experimental study of coflow laminar methane/air diffusion flames: Effects of fuel dilution, inlet velocity, and gravity” (text)
