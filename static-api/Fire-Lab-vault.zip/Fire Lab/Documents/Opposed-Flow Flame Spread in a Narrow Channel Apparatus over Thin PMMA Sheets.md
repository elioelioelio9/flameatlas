---
id: "pub:10"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Opposed-Flow Flame Spread in a Narrow Channel Apparatus over Thin PMMA Sheets

GR Bornand, FJ Miller, JM Pepper, SL Olson, IS Wichman

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Opposed-Flow Flame Spread in a Narrow Channel Apparatus over Thin PMMA Sheets” (text)
