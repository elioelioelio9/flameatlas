---
id: "pub:158"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2019.04.027"
generated: "Fire Lab knowledge engine"
---

# Radiative extinction of burner-supported spherical diffusion flames: A scaling analysis

Nayagam Vedha, Dietrich Daniel L., Williams Forman A.

DOI: [10.1016/j.combustflame.2019.04.027](https://doi.org/10.1016/j.combustflame.2019.04.027)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Radiative extinction of burner-supported spherical diffusion flames: A scaling analysis” (text)
- [[Diffusion flame]] — “Radiative extinction of burner-supported spherical diffusion flames: A scaling analysis” (text)
- [[Radiative heat loss]] — “Radiative extinction of burner-supported spherical diffusion flames: A scaling analysis” (text)
