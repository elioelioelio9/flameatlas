---
id: "pub:179"
type: "document"
tags: ["fire-lab/document"]
doi: "10.30826/NEPCAP9B-13"
generated: "Fire Lab knowledge engine"
---

# SPHERICAL DIFFUSION FLAME IN MICROGRAVITY CONDITIONS: FIRST RESULTS OF JOINT RUSSIAN-AMERICAN SPACE EXPERIMENT FLAME DESIGN - ADAMANT

undefined undefined, FROLOV S. M.

DOI: [10.30826/NEPCAP9B-13](https://doi.org/10.30826/NEPCAP9B-13)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “SPHERICAL DIFFUSION FLAME IN MICROGRAVITY CONDITIONS: FIRST RESULTS OF JOINT RUSSIAN-AMERICAN SPACE EXPERIMENT FLAME DESIGN - ADAMANT” (text)
- [[Diffusion flame]] — “SPHERICAL DIFFUSION FLAME IN MICROGRAVITY CONDITIONS: FIRST RESULTS OF JOINT RUSSIAN-AMERICAN SPACE EXPERIMENT FLAME DESIGN - ADAMANT” (text)
