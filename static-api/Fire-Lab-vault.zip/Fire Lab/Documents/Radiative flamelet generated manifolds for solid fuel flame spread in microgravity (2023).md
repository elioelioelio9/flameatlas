---
id: "pub:327"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2023.112939"
generated: "Fire Lab knowledge engine"
---

# Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)

Budzinski Kenneth, DesJardin Paul E.

DOI: [10.1016/j.combustflame.2023.112939](https://doi.org/10.1016/j.combustflame.2023.112939)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)” (text)
- [[Microgravity]] — “Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)” (text)
- [[Radiative heat loss]] — “Radiative flamelet generated manifolds for solid fuel flame spread in microgravity (2023)” (text)
