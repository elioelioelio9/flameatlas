---
id: "pub:15"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.06.125"
generated: "Fire Lab knowledge engine"
---

# Experimental validation of a correlation capturing the boundary layer effect on spread rate in the kinetic regime of opposed-flow flame spread

Bhattacharjee Subrata, Tran Wynn, Laue Matthew, Paolini Christopher, Nakamura Yuji

DOI: [10.1016/j.proci.2014.06.125](https://doi.org/10.1016/j.proci.2014.06.125)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Experimental validation of a correlation capturing the boundary layer effect on spread rate in the kinetic regime of opposed-flow flame spread” (text)
