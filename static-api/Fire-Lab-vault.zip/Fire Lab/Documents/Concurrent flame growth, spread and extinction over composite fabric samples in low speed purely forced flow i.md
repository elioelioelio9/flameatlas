---
id: "pub:18"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow in microgravity

X Zhao, JS Tien, PV Ferkul, S. Olson

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow in microgravity” (text)
- [[Extinction]] — “Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow in microgravity” (text)
- [[Forced flow]] — “Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow in microgravity” (text)
- [[Microgravity]] — “Concurrent flame growth, spread and extinction over composite fabric samples in low speed purely forced flow in microgravity” (text)
