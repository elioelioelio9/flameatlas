---
id: "pub:237"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2008.06.182"
generated: "Fire Lab knowledge engine"
---

# Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames

Connelly B.C., Long M.B., Smooke M.D., Hall R.J., Colket M.B.

DOI: [10.1016/j.proci.2008.06.182](https://doi.org/10.1016/j.proci.2008.06.182)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames” (text)
- [[Soot]] — “Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames” (text)
- [[Numerical modeling]] — “Computational and experimental investigation of the interaction of soot and NO in coflow diffusion flames” (text)
