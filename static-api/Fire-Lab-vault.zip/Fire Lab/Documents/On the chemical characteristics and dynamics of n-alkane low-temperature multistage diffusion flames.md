---
id: "pub:348"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.06.161"
generated: "Fire Lab knowledge engine"
---

# On the chemical characteristics and dynamics of n-alkane low-temperature multistage diffusion flames

Yehia Omar R., Reuter Christopher B., Ju Yiguang

DOI: [10.1016/j.proci.2018.06.161](https://doi.org/10.1016/j.proci.2018.06.161)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “On the chemical characteristics and dynamics of n-alkane low-temperature multistage diffusion flames” (text)
- [[Temperature]] — “On the chemical characteristics and dynamics of n-alkane low-temperature multistage diffusion flames” (text)
