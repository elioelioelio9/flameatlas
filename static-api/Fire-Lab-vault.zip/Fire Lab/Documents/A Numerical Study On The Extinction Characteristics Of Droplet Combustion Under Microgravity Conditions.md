---
id: "pub:68"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2012-1252"
generated: "Fire Lab knowledge engine"
---

# A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions

Farouk Tanvir, Dryer Frederick

DOI: [10.2514/6.2012-1252](https://doi.org/10.2514/6.2012-1252)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions” (text)
- [[Microgravity]] — “A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions” (text)
- [[Droplet combustion]] — “A Numerical Study On The Extinction Characteristics Of Droplet Combustion Under Microgravity Conditions” (text)
