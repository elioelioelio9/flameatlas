---
id: "pub:188"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.07.029"
generated: "Fire Lab knowledge engine"
---

# Modeled quenching limits of spherical hydrogen diffusion flames

Lecoustre V.R., Sunderland P.B., Chao B.H., Axelbaum R.L.

DOI: [10.1016/j.proci.2012.07.029](https://doi.org/10.1016/j.proci.2012.07.029)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Modeled quenching limits of spherical hydrogen diffusion flames” (text)
