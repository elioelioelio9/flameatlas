---
id: "pub:86"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.07.022"
generated: "Fire Lab knowledge engine"
---

# The effect of support fibers on micro-convection in droplet combustion experiments

Liu Y.C., Xu Y., Avedisian C.T., Hicks M.C.

DOI: [10.1016/j.proci.2014.07.022](https://doi.org/10.1016/j.proci.2014.07.022)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “The effect of support fibers on micro-convection in droplet combustion experiments” (text)
