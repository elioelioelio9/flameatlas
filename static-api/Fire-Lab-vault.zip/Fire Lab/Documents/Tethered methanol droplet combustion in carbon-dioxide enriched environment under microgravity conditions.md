---
id: "pub:69"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2011.06.014"
generated: "Fire Lab knowledge engine"
---

# Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions

Farouk Tanvir, Dryer Frederick L.

DOI: [10.1016/j.combustflame.2011.06.014](https://doi.org/10.1016/j.combustflame.2011.06.014)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions” (text)
- [[Droplet combustion]] — “Tethered methanol droplet combustion in carbon-dioxide enriched environment under microgravity conditions” (text)
