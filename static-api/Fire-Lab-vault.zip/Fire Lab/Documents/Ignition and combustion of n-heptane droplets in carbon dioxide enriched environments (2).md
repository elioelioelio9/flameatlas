---
id: "pub:146"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.icheatmasstransfer.2009.10.006"
generated: "Fire Lab knowledge engine"
---

# Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments

Dzik Justin, Nayagam Vedha, Williams Forman A.

DOI: [10.1016/j.icheatmasstransfer.2009.10.006](https://doi.org/10.1016/j.icheatmasstransfer.2009.10.006)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Ignition]] — “Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments” (text)
- [[Droplet combustion]] — “Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments” (text)
- [[Suppressant diluent]] — “Ignition and combustion of n-heptane droplets in carbon dioxide enriched environments” (text)
