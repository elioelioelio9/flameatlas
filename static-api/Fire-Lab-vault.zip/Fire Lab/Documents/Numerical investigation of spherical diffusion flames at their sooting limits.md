---
id: "pub:192"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2011.05.022"
generated: "Fire Lab knowledge engine"
---

# Numerical investigation of spherical diffusion flames at their sooting limits

Lecoustre V.R., Sunderland P.B., Chao B.H., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2011.05.022](https://doi.org/10.1016/j.combustflame.2011.05.022)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Numerical investigation of spherical diffusion flames at their sooting limits” (text)
- [[Soot]] — “Numerical investigation of spherical diffusion flames at their sooting limits” (text)
