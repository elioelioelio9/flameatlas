---
id: "pub:256"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2012.07.007"
generated: "Fire Lab knowledge engine"
---

# Electrical aspects of flame quenching

Weinberg F.J., Dunn-Rankin D., Carleton F.B., Karnani S., Markides C., Zhai M.

DOI: [10.1016/j.proci.2012.07.007](https://doi.org/10.1016/j.proci.2012.07.007)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)
