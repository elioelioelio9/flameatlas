---
id: "pub:272"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0082-0784(98)80038-6"
generated: "Fire Lab knowledge engine"
---

# Role of flamefront motion and criterion for global quasi-steadiness in droplet burning

He Longtin, Tse Stephen D., Law Chung K.

DOI: [10.1016/S0082-0784(98)80038-6](https://doi.org/10.1016/S0082-0784(98)80038-6)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Role of flamefront motion and criterion for global quasi-steadiness in droplet burning” (text)
