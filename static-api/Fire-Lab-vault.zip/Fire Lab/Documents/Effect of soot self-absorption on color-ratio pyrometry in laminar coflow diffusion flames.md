---
id: "pub:229"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1364/OL.43.001103"
generated: "Fire Lab knowledge engine"
---

# Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames

Kempema Nathan J., Long Marshall B.

DOI: [10.1364/OL.43.001103](https://doi.org/10.1364/OL.43.001103)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames” (text)
- [[Soot]] — “Effect of soot self-absorption on color-ratio pyrometry in laminar coflow diffusion flames” (text)
