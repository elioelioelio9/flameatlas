---
id: "pub:134"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tallow

YC Liu, AJ Savas, CT Avedisian

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “The spherically symmetric droplet burning characteristics of Jet-A and biofuels derived from camelina and tallow” (text)
