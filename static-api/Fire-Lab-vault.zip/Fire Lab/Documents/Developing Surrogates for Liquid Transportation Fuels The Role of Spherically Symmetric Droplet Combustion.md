---
id: "pub:115"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/978-81-322-2211-8_16"
generated: "Fire Lab knowledge engine"
---

# Developing Surrogates for Liquid Transportation Fuels: The Role of Spherically Symmetric Droplet Combustion

Avedisian C. Thomas

DOI: [10.1007/978-81-322-2211-8_16](https://doi.org/10.1007/978-81-322-2211-8_16)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Developing Surrogates for Liquid Transportation Fuels: The Role of Spherically Symmetric Droplet Combustion” (text)
