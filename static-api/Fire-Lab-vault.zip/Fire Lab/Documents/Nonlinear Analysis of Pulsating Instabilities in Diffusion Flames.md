---
id: "pub:300"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2005-544"
generated: "Fire Lab knowledge engine"
---

# Nonlinear Analysis of Pulsating Instabilities in Diffusion Flames

Wang Heyang, Bechtold John, Law Chung

DOI: [10.2514/6.2005-544](https://doi.org/10.2514/6.2005-544)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Nonlinear Analysis of Pulsating Instabilities in Diffusion Flames” (text)
