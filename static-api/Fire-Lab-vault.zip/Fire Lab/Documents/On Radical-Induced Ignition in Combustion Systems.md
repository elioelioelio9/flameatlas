---
id: "pub:294"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1146/annurev-chembioeng-060718-030141"
generated: "Fire Lab knowledge engine"
---

# On Radical-Induced Ignition in Combustion Systems

Liang Wenkai, Law Chung K.

DOI: [10.1146/annurev-chembioeng-060718-030141](https://doi.org/10.1146/annurev-chembioeng-060718-030141)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Ignition]] — “On Radical-Induced Ignition in Combustion Systems” (text)
