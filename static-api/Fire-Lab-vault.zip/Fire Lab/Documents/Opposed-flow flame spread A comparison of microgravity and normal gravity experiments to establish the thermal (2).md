---
id: "pub:2"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.firesaf.2015.11.011"
generated: "Fire Lab knowledge engine"
---

# Opposed-flow flame spread: A comparison of microgravity and normal gravity experiments to establish the thermal regime

Bhattacharjee Subrata, Laue Matthew, Carmignani Luca, Ferkul Paul, Olson Sandra

DOI: [10.1016/j.firesaf.2015.11.011](https://doi.org/10.1016/j.firesaf.2015.11.011)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Opposed-flow flame spread: A comparison of microgravity and normal gravity experiments to establish the thermal regime” (text)
- [[Microgravity]] — “Opposed-flow flame spread: A comparison of microgravity and normal gravity experiments to establish the thermal regime” (text)
