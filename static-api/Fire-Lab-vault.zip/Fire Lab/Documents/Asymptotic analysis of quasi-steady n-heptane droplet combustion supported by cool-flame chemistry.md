---
id: "pub:169"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2016.1248494"
generated: "Fire Lab knowledge engine"
---

# Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry

Seshadri Kalyanasundaram, Peters Norbert, Williams Forman A., Nayagam Vedha, Paczko Guenter

DOI: [10.1080/13647830.2016.1248494](https://doi.org/10.1080/13647830.2016.1248494)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[CFI]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry” (text)
- [[Cool flame]] — “Asymptotic analysis of quasi-steady n-heptane droplet combustion supported by cool-flame chemistry” (text)
