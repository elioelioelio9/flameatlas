---
id: "pub:201"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102209808952065"
generated: "Fire Lab knowledge engine"
---

# On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure

CHAO B. H., LIU S., AXELBAUM R. L.

DOI: [10.1080/00102209808952065](https://doi.org/10.1080/00102209808952065)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure” (text)
- [[Soot]] — “On Soot Inception in Nonpremixed Flames and the Effects of Flame Structure” (text)
