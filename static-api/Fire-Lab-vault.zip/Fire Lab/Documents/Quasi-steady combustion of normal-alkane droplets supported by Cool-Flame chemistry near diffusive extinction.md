---
id: "pub:157"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830.2019.1588380"
generated: "Fire Lab knowledge engine"
---

# Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction

Williams Forman A., Nayagam Vedha

DOI: [10.1080/13647830.2019.1588380](https://doi.org/10.1080/13647830.2019.1588380)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction” (text)
- [[Droplet combustion]] — “Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction” (text)
- [[Cool flame]] — “Quasi-steady combustion of normal-alkane droplets supported by Cool-Flame chemistry near diffusive extinction” (text)
