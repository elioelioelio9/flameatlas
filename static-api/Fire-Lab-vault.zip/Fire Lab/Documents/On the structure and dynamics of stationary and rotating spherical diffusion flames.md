---
id: "pub:306"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# On the structure and dynamics of stationary and rotating spherical diffusion flames

SW Yoo

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “On the structure and dynamics of stationary and rotating spherical diffusion flames” (text)
