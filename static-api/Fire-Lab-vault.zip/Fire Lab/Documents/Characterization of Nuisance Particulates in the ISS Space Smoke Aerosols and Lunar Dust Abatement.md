---
id: "pub:57"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1017/S1431927610060563"
generated: "Fire Lab knowledge engine"
---

# Characterization of Nuisance Particulates in the ISS: Space Smoke Aerosols and Lunar Dust Abatement

Bryg VM, Yuan Z-G, Urban DL, Ruff G, Mulholland G, Agui J

DOI: [10.1017/S1431927610060563](https://doi.org/10.1017/S1431927610060563)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Characterization of Nuisance Particulates in the ISS: Space Smoke Aerosols and Lunar Dust Abatement” (text)
- [[Particle size]] — “Characterization of Nuisance Particulates in the ISS: Space Smoke Aerosols and Lunar Dust Abatement” (text)
