---
id: "pub:280"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1063/1.2212399"
generated: "Fire Lab knowledge engine"
---

# Porous spherical burner for combustion experimentation

Yoo Sean W., Zhu Delin, Law Chung K.

DOI: [10.1063/1.2212399](https://doi.org/10.1063/1.2212399)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
