---
id: "pub:297"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.1998-563"
generated: "Fire Lab knowledge engine"
---

# On burner-supported, spherical diffusion flames under micro-buoyancy conditions

Sung C., Zhu D., Tse S., Law C.

DOI: [10.2514/6.1998-563](https://doi.org/10.2514/6.1998-563)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “On burner-supported, spherical diffusion flames under micro-buoyancy conditions” (text)
- [[Diffusion flame]] — “On burner-supported, spherical diffusion flames under micro-buoyancy conditions” (text)
