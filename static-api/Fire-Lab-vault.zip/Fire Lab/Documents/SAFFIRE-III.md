---
id: "doc:PSI-100"
type: "document"
aliases: ["SAFFIRE-III"]
tags: ["fire-lab/document", "family/SAFFIRE"]
doi: "10.60555/040q-4h36"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-100"
generated: "Fire Lab knowledge engine"
---

# SAFFIRE-III — Spacecraft Fire Experiment-III

Repeat of the large-scale fabric fire in a Cygnus vehicle at 30 cm/s, in concurrent and opposed flow.

DOI: [10.60555/040q-4h36](https://doi.org/10.60555/040q-4h36)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS) Saffire III enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[Cygnus cargo vehicle]] — “International Space Station (ISS) Saffire III enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[NASA Glenn Research Center]] — “International Space Station (ISS) Saffire III enclosure in Cygnus Glenn Research Center (GRC)” (metadata)
- [[Forced flow]] — “Repeat of the large-scale fabric fire in a Cygnus vehicle at 30 cm/s, in concurrent and opposed flow.” (text)
- [[Material flammability]] — “(1) determine how rapidly a large scale fire grows in low-gravity and (2) investigate the low-g flammability limits compared to those obtained in NASA’s normal” (text)
- [[Earth]] — “…e grows in low-gravity and (2) investigate the low-g flammability limits compared to those obtained in NASA’s normal gravity material flammability screening te” (text)
- [[Pressure]] — “…e, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemom” (text)
- [[Smoke detection]] — “…mocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2” (text)
- [[Radiative heat loss]] — “…eras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radiation, solid state sensors were used to measu” (text)
- [[Suppressant diluent]] — “…me temperatures, two radiometers recorded flame radiation, solid state sensors were used to measure pressure, CO2 and O2 mole faction, and two anemometer track” (text)
- [[Temperature]] — “…ited flame images were captured using two cameras. In addition, thermocouples provided flow, flame, and plume temperatures, two radiometers recorded flame radi” (text)
- [[Microgravity]] — “…e further from earth with considerably longer transit times for a safe return. There is a significant lack of microgravity data available for spacecraft design” (text)
- [[Spacecraft fire safety]] — “…behavior in normal and reduced gravity, the use of terrestrial fires and fire standards to design spacecraft fire safety systems presents an inherent risk to t” (text)
- [[Buoyancy]] — “Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire), 45th In…” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SAFFIRE-II]] (metadata)
- [[SAFFIRE-I]] (metadata)

## Extends
_The source continues the target programme (same family, later flight)._

- [[SAFFIRE-I]] — “SAFFIRE-III (04-18-2017) follows SAFFIRE-I (03-02-2001) in the SAFFIRE family” (metadata)

## Measures
_The source reports values of the target quantity (test tables or extracted numbers with units)._

- [[Flow velocity]] — 2 values, 30–30 cm/s (table)
- [[Fuel thickness (2)]] — 2 values, 3.3–3.3 mm (table)
- [[sample length cm]] — 2 values, 94–94 cm (table)
- [[sample width cm]] — 2 values, 40.6–40.6 cm (table)

## Supports
_The source is cited as evidence for the target finding._

- [[Scale matters only SAFFIRE burned spacecraft-size samples]] — “SAFFIRE-I and -III burned ~0.4 m × 0.94 m fabric samples in uncrewed Cygnus vehicles, with O2/CO2, pressure, temperature and flame-growth measurements — the onl” (text)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[SAME-R]] (inferred)
- [[SAME]] (inferred)
- [[SLICE]] (inferred)
- [[SPICE]] (inferred)
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] (inferred)
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] (inferred)
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (inferred)
- [[ACME BRE]] (inferred)
- [[ACME CLD Flame]] (inferred)
- [[ACME E-FIELD Flames]] (inferred)
- [[ACME s-Flame]] (inferred)
- [[BASS-II]] (inferred)
- [[BASS]] (inferred)
- [[CFI]] (inferred)
- [[Computational and Experimental Analysis of SPICE Data Sets]] (inferred)
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[SAFFIRE-I]] · references
- [[SAFFIRE-II]] · extends
- [[Buoyant Effects on the Flammability of Silicone Samples Planned for the Spacecraft Fire Experiment (Saffire),  (2)]] · describes
- [[The Spacecraft Fire Experiment (Saffire) - Objectives, Development and Status (3)]] · describes
- [[Operation and Development Status of the Spacecraft Fire Experiments (Saffire), 46th International Conference o]] · describes
- [[ACME Flame Design]] · shares concept
