---
id: "pub:3"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.07.017"
generated: "Fire Lab knowledge engine"
---

# Simplified model for predicting difference between flammability limits of a thin material in normal gravity and microgravity environments

Takahashi Shuhei, Ebisawa Tomoya, Bhattacharjee Subrata, Ihara Tadayoshi

DOI: [10.1016/j.proci.2014.07.017](https://doi.org/10.1016/j.proci.2014.07.017)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Simplified model for predicting difference between flammability limits of a thin material in normal gravity and microgravity environments” (text)
- [[Material flammability]] — “Simplified model for predicting difference between flammability limits of a thin material in normal gravity and microgravity environments” (text)
