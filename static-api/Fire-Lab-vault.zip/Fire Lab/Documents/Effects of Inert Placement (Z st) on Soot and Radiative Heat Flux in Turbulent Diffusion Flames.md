---
id: "pub:185"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1021/acs.energyfuels.7b01092"
generated: "Fire Lab knowledge engine"
---

# Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames

Gopan Akshay, Yang Zhiwei, Kumfer Benjamin M., Axelbaum Richard L.

DOI: [10.1021/acs.energyfuels.7b01092](https://doi.org/10.1021/acs.energyfuels.7b01092)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames” (text)
- [[Soot]] — “Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames” (text)
- [[Radiative heat loss]] — “Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames” (text)
- [[Suppressant diluent]] — “Effects of Inert Placement (Z st) on Soot and Radiative Heat Flux in Turbulent Diffusion Flames” (text)
