---
id: "pub:79"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2014.06.043"
generated: "Fire Lab knowledge engine"
---

# n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments

Alam Fahd E., Liu Y.C., Avedisian C.T., Dryer F.L., Farouk T.I.

DOI: [10.1016/j.proci.2014.06.043](https://doi.org/10.1016/j.proci.2014.06.043)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
- [[Droplet combustion]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
- [[Numerical modeling]] — “n-Butanol droplet combustion: Numerical modeling and reduced gravity experiments” (text)
