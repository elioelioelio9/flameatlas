---
id: "doc:PSI-60"
type: "document"
tags: ["fire-lab/document", "family/Ground-study"]
doi: "10.60555/mzjm-yv57"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-60"
generated: "Fire Lab knowledge engine"
---

# Computational and Experimental Analysis of SPICE Data Sets

Why soot formation differs so much between 1-g and 0-g flames, using SPICE images and detailed soot models.

DOI: [10.60555/mzjm-yv57](https://doi.org/10.60555/mzjm-yv57)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[NASA Glenn Research Center]] — “Glenn Research Center (GRC)” (metadata)
- [[Soot]] — “Why soot formation differs so much between 1-g and 0-g flames, using SPICE images and detailed soot models.” (text)
- [[Earth]] — “Why soot formation differs so much between 1-g and 0-g flames, using SPICE images and detailed soot models.” (text)
- [[Smoke]] — “…computational and experimental methods to derive temperature distributions and soot volume fractions from the Smoke Point in Coflow Experiment (SPICE) data ava” (text)
- [[Radiative heat loss]] — “…d incorporating advanced soot models, the study sought to improve understanding of soot formation, oxidation, radiative re-absorption, and aggregate growth in” (text)
- [[Temperature]] — “…flames. The objective of this investigation was to integrate computational and experimental methods to derive temperature distributions and soot volume fractio” (text)
- [[Numerical modeling]] — “…screpancy between soot formation in 1g and in 0g flames. The objective of this investigation was to integrate computational and experimental methods to derive” (text)
- [[Microgravity]] — “The work further aimed to reconcile microgravity and normal gravity flame behavior, identify key physical and chemical processes influencing smoke point devel…” (text)
- [[Smoke detection]] — “…combustion in both spacecraft and terrestrial systems. For space applications, the results support safer fire detection, suppression, and cleaner combustion te” (text)
- [[Suppressant diluent]] — “…in both spacecraft and terrestrial systems. For space applications, the results support safer fire detection, suppression, and cleaner combustion technologies” (text)

## References
_Explicitly cites or links to the target (PSI 'related' field, a wikilink, or a reference list)._

- [[SPICE]] (metadata)

## Depends on
_The source relies on the target (hardware used, or flight data re-used by a ground study)._

- [[SPICE]] (metadata)

## Shares concept
_Inferred: both documents mention at least two of the same concepts (listed in the evidence)._

- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] (inferred)
- [[FLEX-2]] (inferred)
- [[FLEX]] (inferred)
- [[SAFFIRE-I]] (inferred)
- [[SAFFIRE-II]] (inferred)

## Linked from
- [[A Combined Experimental and Computational Study of Soot Formation in Normal and Microgravity Conditions (2022)]] · describes
- [[ACME Flame Design]] · shares concept
- [[SAFFIRE-III]] · shares concept
- [[SAME-R]] · shares concept
- [[SAME]] · shares concept
- [[SLICE]] · shares concept
- [[SPICE]] · shares concept
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · shares concept
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · shares concept
- [[ACME BRE]] · shares concept
- [[ACME CLD Flame]] · shares concept
- [[ACME E-FIELD Flames]] · shares concept
- [[ACME s-Flame]] · shares concept
- [[BASS-II]] · shares concept
- [[BASS]] · shares concept
- [[CFI]] · shares concept
- [[DAFT DAFT-2]] · shares concept
