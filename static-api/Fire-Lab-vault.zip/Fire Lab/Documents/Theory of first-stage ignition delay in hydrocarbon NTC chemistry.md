---
id: "pub:292"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2017.10.003"
generated: "Fire Lab knowledge engine"
---

# Theory of first-stage ignition delay in hydrocarbon NTC chemistry

Liang Wenkai, Law Chung K.

DOI: [10.1016/j.combustflame.2017.10.003](https://doi.org/10.1016/j.combustflame.2017.10.003)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Ignition]] — “Theory of first-stage ignition delay in hydrocarbon NTC chemistry” (text)
