---
id: "pub:315"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2010-1105"
generated: "Fire Lab knowledge engine"
---

# Laminar Smoke Points in Coflow Measured Aboard the International Space Station

Dotson Keenan, Sunderland Peter, Yuan Zeng-Guang, Urban David

DOI: [10.2514/6.2010-1105](https://doi.org/10.2514/6.2010-1105)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Laminar Smoke Points in Coflow Measured Aboard the International Space Station” (text)
