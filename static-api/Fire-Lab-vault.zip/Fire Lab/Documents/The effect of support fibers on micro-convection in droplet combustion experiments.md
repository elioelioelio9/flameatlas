---
id: "pub:126"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# The effect of support fibers on micro-convection in droplet combustion experiments

YC Liu, Y Xu, CT Avedisian, MC Hicks

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “The effect of support fibers on micro-convection in droplet combustion experiments” (text)
