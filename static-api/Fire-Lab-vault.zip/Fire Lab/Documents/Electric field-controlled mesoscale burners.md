---
id: "pub:259"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2007.07.007"
generated: "Fire Lab knowledge engine"
---

# Electric field-controlled mesoscale burners

Weinberg Felix, Carleton Fred, Dunn-Rankin Derek

DOI: [10.1016/j.combustflame.2007.07.007](https://doi.org/10.1016/j.combustflame.2007.07.007)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “Electric field-controlled mesoscale burners” (text)
