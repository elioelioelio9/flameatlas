---
id: "doc:PSI-181"
type: "document"
tags: ["fire-lab/document", "family/Out-of-scope"]
doi: "10.60555/td9e-cz97"
source: "https://psi.nasa.gov/physci/repo/data/investigations/PSI-181"
generated: "Fire Lab knowledge engine"
---

# Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Environments under Extremes of Elevated and Cryo Temperatures

Solder microstructure in microgravity — not a combustion investigation.

DOI: [10.60555/td9e-cz97](https://doi.org/10.60555/td9e-cz97)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[International Space Station]] — “International Space Station (ISS)  Marshall Space Flight Center (MSFC)” (metadata)
- [[Microgravity]] — “Solder microstructure in microgravity — not a combustion investigation.” (text)
- [[Buoyancy]] — “…s aboard the International Space Station, specifically examining the impact of suppressed convective flow and buoyancy on 40Pb-60Sn alloys utilized in the In-S” (text)
- [[Temperature]] — “…der’s material and mechanical properties under extreme thermal environments, including elevated and cryogenic temperature exposures characteristic of spaceflig” (text)
- [[Earth]] — “…cterization was performed on four solder specimens processed in microgravity from the ISSI investigation, one terrestrial ISSI solder, and a freshly fabricated” (text)
- [[Suppressant diluent]] — “…solidification-induced volumetric changes, thermally driven density gradients, and Marangoni convection. This suppression of fluid motion results in diminished” (text)
- [[Moon]] — “…NASA proposal calls, including those associated with the Artemis program, which aims to return humans to the lunar surface, (iii) The insights gained into micr” (text)
