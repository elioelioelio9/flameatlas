---
id: "pub:206"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0010-2180(02)00424-8"
generated: "Fire Lab knowledge engine"
---

# Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames

Sunderland P

DOI: [10.1016/S0010-2180(02)00424-8](https://doi.org/10.1016/S0010-2180(02)00424-8)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames” (text)
- [[Diffusion flame]] — “Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames” (text)
- [[Soot]] — “Effects of structure and hydrodynamics on the sooting behavior of spherical microgravity diffusion flames” (text)
