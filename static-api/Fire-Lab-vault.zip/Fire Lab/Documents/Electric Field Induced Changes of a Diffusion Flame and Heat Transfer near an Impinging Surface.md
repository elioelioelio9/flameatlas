---
id: "pub:242"
type: "document"
tags: ["fire-lab/document"]
doi: "10.3390/en11051235"
generated: "Fire Lab knowledge engine"
---

# Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface

Chien Yu-Chien, Dunn-Rankin Derek

DOI: [10.3390/en11051235](https://doi.org/10.3390/en11051235)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface” (text)
- [[Electric field]] — “Electric Field Induced Changes of a Diffusion Flame and Heat Transfer near an Impinging Surface” (text)
