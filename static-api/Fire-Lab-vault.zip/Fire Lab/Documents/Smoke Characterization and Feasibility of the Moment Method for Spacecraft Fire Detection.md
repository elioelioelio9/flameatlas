---
id: "pub:62"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/02786826.2015.1025124"
generated: "Fire Lab knowledge engine"
---

# Smoke Characterization and Feasibility of the Moment Method for Spacecraft Fire Detection

Meyer Marit E., Mulholland George W., Bryg Victoria, Urban David L., Yuan Zeng-Guang, Ruff Gary A., Cleary Thomas, Yang Jiann

DOI: [10.1080/02786826.2015.1025124](https://doi.org/10.1080/02786826.2015.1025124)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Smoke Characterization and Feasibility of the Moment Method for Spacecraft Fire Detection” (text)
- [[Smoke detection]] — “Smoke Characterization and Feasibility of the Moment Method for Spacecraft Fire Detection” (text)
