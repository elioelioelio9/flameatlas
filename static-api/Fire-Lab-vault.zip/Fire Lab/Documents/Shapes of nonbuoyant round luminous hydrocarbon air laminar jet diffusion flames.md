---
id: "pub:321"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0010-2180(98)00100-X"
generated: "Fire Lab knowledge engine"
---

# Shapes of nonbuoyant round luminous hydrocarbon/air laminar jet diffusion flames

LIN K, FAETH G, SUNDERLAND P, URBAN D, YUAN Z

DOI: [10.1016/S0010-2180(98)00100-X](https://doi.org/10.1016/S0010-2180(98)00100-X)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SPICE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Shapes of nonbuoyant round luminous hydrocarbon/air laminar jet diffusion flames” (text)
