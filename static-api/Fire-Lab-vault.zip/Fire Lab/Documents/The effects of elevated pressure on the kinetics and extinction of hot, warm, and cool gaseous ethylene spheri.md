---
id: "pub:200"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2024.105400"
generated: "Fire Lab knowledge engine"
---

# The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spherical diffusion flames

Waddell Kendyl A., Yablonsky Gregory, Constales Denis, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.proci.2024.105400](https://doi.org/10.1016/j.proci.2024.105400)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spherical diffusion flames” (text)
- [[Pressure]] — “The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spherical diffusion flames” (text)
- [[Diffusion flame]] — “The effects of elevated pressure on the kinetics and extinction of hot, warm, and cool gaseous ethylene spherical diffusion flames” (text)
