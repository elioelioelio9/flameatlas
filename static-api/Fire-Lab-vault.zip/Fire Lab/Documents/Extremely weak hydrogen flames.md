---
id: "pub:194"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2010.07.024"
generated: "Fire Lab knowledge engine"
---

# Extremely weak hydrogen flames

Lecoustre V.R., Sunderland P.B., Chao B.H., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2010.07.024](https://doi.org/10.1016/j.combustflame.2010.07.024)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)
