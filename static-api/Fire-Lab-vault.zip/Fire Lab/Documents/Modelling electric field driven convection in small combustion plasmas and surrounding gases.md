---
id: "pub:246"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830701383814"
generated: "Fire Lab knowledge engine"
---

# Modelling electric field driven convection in small combustion plasmas and surrounding gases

Papac M. J., Dunn-Rankin D.

DOI: [10.1080/13647830701383814](https://doi.org/10.1080/13647830701383814)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Electric field]] — “Modelling electric field driven convection in small combustion plasmas and surrounding gases” (text)
- [[Numerical modeling]] — “Modelling electric field driven convection in small combustion plasmas and surrounding gases” (text)
