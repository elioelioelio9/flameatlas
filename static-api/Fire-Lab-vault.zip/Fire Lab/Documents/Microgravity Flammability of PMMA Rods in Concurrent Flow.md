---
id: "pub:25"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Microgravity Flammability of PMMA Rods in Concurrent Flow

SL Olson, PV Ferkul

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Forced flow]] — “Microgravity Flammability of PMMA Rods in Concurrent Flow” (text)
- [[Microgravity]] — “Microgravity Flammability of PMMA Rods in Concurrent Flow” (text)
- [[Material flammability]] — “Microgravity Flammability of PMMA Rods in Concurrent Flow” (text)
