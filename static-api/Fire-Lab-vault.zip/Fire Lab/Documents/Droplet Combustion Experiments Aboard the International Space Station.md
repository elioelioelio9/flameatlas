---
id: "pub:119"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s12217-014-9372-2"
generated: "Fire Lab knowledge engine"
---

# Droplet Combustion Experiments Aboard the International Space Station

Dietrich Daniel L., Nayagam Vedha, Hicks Michael C., Ferkul Paul V., Dryer Frederick L., Farouk Tanvir, Shaw Benjamin D., Suh Hyun Kyu, Choi Mun Y., Liu Yu Cheng, Avedisian C. Thomas, Williams Forman A.

DOI: [10.1007/s12217-014-9372-2](https://doi.org/10.1007/s12217-014-9372-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Droplet Combustion Experiments Aboard the International Space Station” (text)
