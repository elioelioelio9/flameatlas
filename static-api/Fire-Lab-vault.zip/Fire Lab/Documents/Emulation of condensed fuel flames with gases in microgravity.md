---
id: "pub:219"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2015.05.005"
generated: "Fire Lab knowledge engine"
---

# Emulation of condensed fuel flames with gases in microgravity

Zhang Yi, Kim Matt, Guo Haiqing, Sunderland Peter B., Quintiere James G., deRis John, Stocker Dennis P.

DOI: [10.1016/j.combustflame.2015.05.005](https://doi.org/10.1016/j.combustflame.2015.05.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Emulation of condensed fuel flames with gases in microgravity” (text)
