---
id: "pub:305"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Dynamics and morphology of colliding spherical flames

S Yang, S Chaudhuri, D Zhu, CK Law

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
