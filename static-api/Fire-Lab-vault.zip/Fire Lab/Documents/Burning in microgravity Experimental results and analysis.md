---
id: "pub:210"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2021.01.035"
generated: "Fire Lab knowledge engine"
---

# Burning in microgravity: Experimental results and analysis

P Dehghani, PB Sunderland, JG Quintiere, JL deRis

DOI: [10.1016/j.combustflame.2021.01.035](https://doi.org/10.1016/j.combustflame.2021.01.035)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Burning in microgravity: Experimental results and analysis” (text)
