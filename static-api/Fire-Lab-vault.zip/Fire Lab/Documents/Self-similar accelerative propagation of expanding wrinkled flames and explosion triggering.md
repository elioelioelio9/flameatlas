---
id: "pub:284"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1103/PhysRevE.83.026305"
generated: "Fire Lab knowledge engine"
---

# Self-similar accelerative propagation of expanding wrinkled flames and explosion triggering

Akkerman V’yacheslav, Law Chung K., Bychkov Vitaly

DOI: [10.1103/PhysRevE.83.026305](https://doi.org/10.1103/PhysRevE.83.026305)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
