---
id: "pub:203"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2005.02.008"
generated: "Fire Lab knowledge engine"
---

# Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion

Chen R., Axelbaum R.L.

DOI: [10.1016/j.combustflame.2005.02.008](https://doi.org/10.1016/j.combustflame.2005.02.008)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion” (text)
- [[Oxygen concentration]] — “Scalar dissipation rate at extinction and the effects of oxygen-enriched combustion” (text)
