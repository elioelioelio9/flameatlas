---
id: "pub:82"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2015.1072176"
generated: "Fire Lab knowledge engine"
---

# Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets

Shaw Benjamin D., Vang Chang L.

DOI: [10.1080/00102202.2015.1072176](https://doi.org/10.1080/00102202.2015.1072176)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets” (text)
- [[Droplet combustion]] — “Oxygen Lewis Number Effects on Reduced Gravity Combustion of Methanol and n-Heptane Droplets” (text)
