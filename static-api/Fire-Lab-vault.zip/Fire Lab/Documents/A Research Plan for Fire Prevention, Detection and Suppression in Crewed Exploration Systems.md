---
id: "pub:324"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2005-341"
generated: "Fire Lab knowledge engine"
---

# A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems

Ruff Gary, Urban David, King Merrill

DOI: [10.2514/6.2005-341](https://doi.org/10.2514/6.2005-341)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[DAFT DAFT-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke detection]] — “A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems” (text)
- [[Suppressant diluent]] — “A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems” (text)
- [[Spacecraft fire safety]] — “A Research Plan for Fire Prevention, Detection and Suppression in Crewed Exploration Systems” (text)
