---
id: "pub:247"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1196/annals.1362.038"
generated: "Fire Lab knowledge engine"
---

# Canceling buoyancy of gaseous fuel flames in a gravitational environment using an ion-driven wind.

Papac MJ, Dunn-Rankin D.

DOI: [10.1196/annals.1362.038](https://doi.org/10.1196/annals.1362.038)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME E-FIELD Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Buoyancy]] — “Canceling buoyancy of gaseous fuel flames in a gravitational environment using an ion-driven wind.” (text)
