---
id: "pub:181"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2019.09.014"
generated: "Fire Lab knowledge engine"
---

# Double blue zones in inverse and normal laminar jet diffusion flames

Wang Zhengyang, Sunderland Peter B., Axelbaum Richard L.

DOI: [10.1016/j.combustflame.2019.09.014](https://doi.org/10.1016/j.combustflame.2019.09.014)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME Flame Design]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Double blue zones in inverse and normal laminar jet diffusion flames” (text)
