---
id: "pub:267"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/S0082-0784(06)80819-2"
generated: "Fire Lab knowledge engine"
---

# On burner-stabilized cylindrical premixed flames in microgravity

Eng J.A., Law C.K., Zhu D.L.

DOI: [10.1016/S0082-0784(06)80819-2](https://doi.org/10.1016/S0082-0784(06)80819-2)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “On burner-stabilized cylindrical premixed flames in microgravity” (text)
- [[Premixed flame]] — “On burner-stabilized cylindrical premixed flames in microgravity” (text)
