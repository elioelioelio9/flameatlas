---
id: "pub:141"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2012.759946"
generated: "Fire Lab knowledge engine"
---

# Experiments on Submillimeter Free Droplet Flame Extinction

Shaw B. D., Wang D. F.

DOI: [10.1080/00102202.2012.759946](https://doi.org/10.1080/00102202.2012.759946)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Experiments on Submillimeter Free Droplet Flame Extinction” (text)
- [[Droplet combustion]] — “Experiments on Submillimeter Free Droplet Flame Extinction” (text)
