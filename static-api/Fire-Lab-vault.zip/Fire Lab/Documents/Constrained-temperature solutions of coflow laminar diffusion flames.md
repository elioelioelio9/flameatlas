---
id: "pub:227"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2020.06.034"
generated: "Fire Lab knowledge engine"
---

# Constrained-temperature solutions of coflow laminar diffusion flames

Kempema Nathan J., Dobbins Richard R., Long Marshall B., Smooke Mitchell D.

DOI: [10.1016/j.proci.2020.06.034](https://doi.org/10.1016/j.proci.2020.06.034)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Constrained-temperature solutions of coflow laminar diffusion flames” (text)
- [[Temperature]] — “Constrained-temperature solutions of coflow laminar diffusion flames” (text)
