---
id: "pub:224"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1007/s00348-016-2218-5"
generated: "Fire Lab knowledge engine"
---

# Signal-to-noise ratio improvements in laser flow diagnostics using time-resolved image averaging and high dynamic range imaging

Giassi Davide, Long Marshall B.

DOI: [10.1007/s00348-016-2218-5](https://doi.org/10.1007/s00348-016-2218-5)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)
