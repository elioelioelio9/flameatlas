---
id: "pub:4"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/00102202.2014.900056"
generated: "Fire Lab knowledge engine"
---

# A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spread over Thin Fuels

S Bhattacharjee, R Nagarkar, Y Nakamura

DOI: [10.1080/00102202.2014.900056](https://doi.org/10.1080/00102202.2014.900056)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spread over Thin Fuels” (text)
- [[Forced flow]] — “A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spread over Thin Fuels” (text)
- [[Fuel thickness]] — “A Correlation for an Effective Flow Velocity for Capturing the Boundary Layer Effect in Opposed-Flow Flame Spread over Thin Fuels” (text)
