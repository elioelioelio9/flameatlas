---
id: "pub:283"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2009.09.018"
generated: "Fire Lab knowledge engine"
---

# A mechanistic study of Soret diffusion in hydrogen–air flames

Yang F., Law C.K., Sung C.J., Zhang H.Q.

DOI: [10.1016/j.combustflame.2009.09.018](https://doi.org/10.1016/j.combustflame.2009.09.018)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
