---
id: "pub:77"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/1.J054437"
generated: "Fire Lab knowledge engine"
---

# Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames

Nayagam Vedha, Dietrich Daniel L., Williams Forman A.

DOI: [10.2514/1.J054437](https://doi.org/10.2514/1.J054437)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames” (text)
- [[Cool flame]] — “Partial-Burning Regime for Quasi-Steady Droplet Combustion Supported by Cool Flames” (text)
