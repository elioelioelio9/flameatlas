---
id: "pub:46"
type: "document"
tags: ["fire-lab/document"]
doi: "10.2514/6.2012-3536"
generated: "Fire Lab knowledge engine"
---

# Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2

Urban David, Ruff Gary, Greenberg Paul, Fischer David, Meyer Marit, Mulholland George, Yuan Zeng-guang, Bryg Victoria, Cleary Thomas, Yang Jiann

DOI: [10.2514/6.2012-3536](https://doi.org/10.2514/6.2012-3536)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME-R]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2” (text)
- [[Particle size]] — “Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2” (text)
