---
id: "pub:350"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes

Yiguang Ju, Mengni Zhou, Omar R. Yehia, Wenbin Xu, Christopher B. Reuter, Ziyu Wang,  Chao Yan

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Oxygen concentration]] — “SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Diffusion flame]] — “SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Premixed flame]] — “SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
- [[Cool flame]] — “SUPPLEMENTARY MATERIAL
The radical index and the effect of oxygen concentration on non-premixed cool flame extinction of large n-alkanes” (text)
