---
id: "pub:290"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2015.10.029"
generated: "Fire Lab knowledge engine"
---

# On colliding spherical flames: Morphology, corner dynamics, and flame-generated vorticity

Yang Sheng, Zhu Delin, Law Chung K.

DOI: [10.1016/j.combustflame.2015.10.029](https://doi.org/10.1016/j.combustflame.2015.10.029)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
