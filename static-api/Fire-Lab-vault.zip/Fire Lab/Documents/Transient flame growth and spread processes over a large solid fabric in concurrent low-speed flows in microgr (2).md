---
id: "pub:39"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.proci.2018.05.168"
generated: "Fire Lab knowledge engine"
---

# Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgravity – Model versus experiment

Li Chengyao, Liao Ya-Ting T., T'ien James S., Urban David L., Ferkul Paul, Olson Sandra, Ruff Gary A., Easton John

DOI: [10.1016/j.proci.2018.05.168](https://doi.org/10.1016/j.proci.2018.05.168)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-II]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgravity – Model versus experiment” (text)
- [[Microgravity]] — “Transient flame growth and spread processes over a large solid fabric in concurrent low-speed flows in microgravity – Model versus experiment” (text)
