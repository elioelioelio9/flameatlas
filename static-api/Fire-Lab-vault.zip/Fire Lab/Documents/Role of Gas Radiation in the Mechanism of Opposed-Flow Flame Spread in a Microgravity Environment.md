---
id: "pub:7"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment

JR Villaraza, L Carmignani, S Bhattacharjee

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[BASS]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Flame spread]] — “Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment” (text)
- [[Microgravity]] — “Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment” (text)
- [[Radiative heat loss]] — “Role of Gas Radiation in the Mechanism of Opposed-Flow Flame Spread in a Microgravity Environment” (text)
