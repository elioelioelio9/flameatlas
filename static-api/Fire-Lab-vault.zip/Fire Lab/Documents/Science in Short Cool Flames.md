---
id: "pub:170"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Science in Short: Cool Flames

Rachel Barry

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[CFI]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Cool flame]] — “Science in Short: Cool Flames” (text)
