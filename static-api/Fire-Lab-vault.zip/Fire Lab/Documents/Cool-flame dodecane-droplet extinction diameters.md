---
id: "pub:156"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2019.10.036"
generated: "Fire Lab knowledge engine"
---

# Cool-flame dodecane-droplet extinction diameters

Williams Forman A., Nayagam Vedha

DOI: [10.1016/j.combustflame.2019.10.036](https://doi.org/10.1016/j.combustflame.2019.10.036)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX-2]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Extinction]] — “Cool-flame dodecane-droplet extinction diameters” (text)
- [[Droplet combustion]] — “Cool-flame dodecane-droplet extinction diameters” (text)
- [[Cool flame]] — “Cool-flame dodecane-droplet extinction diameters” (text)
