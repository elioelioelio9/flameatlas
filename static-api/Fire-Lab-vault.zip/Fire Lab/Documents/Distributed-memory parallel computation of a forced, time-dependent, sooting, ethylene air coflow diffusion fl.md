---
id: "pub:238"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1080/13647830903159293"
generated: "Fire Lab knowledge engine"
---

# Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene/air coflow diffusion flame

Dworkin S. B., Cooke J. A., Bennett B. A.V., Connelly B. C., Long M. B., Smooke M. D., Hall R. J., Colket M. B.

DOI: [10.1080/13647830903159293](https://doi.org/10.1080/13647830903159293)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME CLD Flame]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Diffusion flame]] — “Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene/air coflow diffusion flame” (text)
- [[Soot]] — “Distributed-memory parallel computation of a forced, time-dependent, sooting, ethylene/air coflow diffusion flame” (text)
