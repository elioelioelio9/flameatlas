---
id: "pub:207"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1177/0734904113495650"
generated: "Fire Lab knowledge engine"
---

# Burning on flat wicks at various orientations

Zhang Yi, Bustamante Michael J, Gollner Michael J, Sunderland Peter B, Quintiere James G

DOI: [10.1177/0734904113495650](https://doi.org/10.1177/0734904113495650)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)
