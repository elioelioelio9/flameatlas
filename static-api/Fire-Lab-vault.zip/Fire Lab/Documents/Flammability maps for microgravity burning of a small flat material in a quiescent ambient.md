---
id: "pub:220"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2023.112809"
generated: "Fire Lab knowledge engine"
---

# Flammability maps for microgravity burning of a small flat material in a quiescent ambient

Dehghani Parham, Quintiere James G.

DOI: [10.1016/j.combustflame.2023.112809](https://doi.org/10.1016/j.combustflame.2023.112809)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME BRE]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Microgravity]] — “Flammability maps for microgravity burning of a small flat material in a quiescent ambient” (text)
- [[Material flammability]] — “Flammability maps for microgravity burning of a small flat material in a quiescent ambient” (text)
