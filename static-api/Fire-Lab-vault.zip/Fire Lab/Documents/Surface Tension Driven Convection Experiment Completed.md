---
id: "pub:353"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Surface Tension Driven Convection Experiment Completed

TP Jacobson, DA Sedlak

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
