---
id: "pub:287"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2012.03.005"
generated: "Fire Lab knowledge engine"
---

# A mechanistic evaluation of Soret diffusion in heptane/air flames

Xin Yuxuan, Sung Chih-Jen, Law Chung K.

DOI: [10.1016/j.combustflame.2012.03.005](https://doi.org/10.1016/j.combustflame.2012.03.005)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[ACME s-Flame]] (metadata)
