---
id: "pub:92"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1016/j.combustflame.2012.11.006"
generated: "Fire Lab knowledge engine"
---

# On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling

Liu Yu Cheng, Farouk Tanvir, Savas Anthony J., Dryer Frederick L., Thomas Avedisian C.

DOI: [10.1016/j.combustflame.2012.11.006](https://doi.org/10.1016/j.combustflame.2012.11.006)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[FLEX]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Droplet combustion]] — “On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling” (text)
- [[Numerical modeling]] — “On the spherically symmetrical combustion of methyl decanoate droplets and comparisons with detailed numerical modeling” (text)
