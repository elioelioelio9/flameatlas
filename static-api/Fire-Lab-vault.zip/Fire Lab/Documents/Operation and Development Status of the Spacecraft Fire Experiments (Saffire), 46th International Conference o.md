---
id: "pub:43"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Operation and Development Status of the Spacecraft Fire Experiments (Saffire), 46th International Conference on Environmental Systems (ICES), July 2016

https://ntrs.nasa.gov/citations/20170000230

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAFFIRE-III]] (metadata)
