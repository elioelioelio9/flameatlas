---
id: "pub:56"
type: "document"
tags: ["fire-lab/document"]
generated: "Fire Lab knowledge engine"
---

# Smoke: Characterization of Smoke Particulate for Spacecraft Fire Detection

DL Urban, GW Mulholland, J Yang, TG Cleary, ZG Yuan

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[SAME]] (metadata)

## Mentions
_The target concept or entity appears in the document's text; the matching passage is the evidence._

- [[Smoke]] — “Smoke: Characterization of Smoke Particulate for Spacecraft Fire Detection” (text)
- [[Particle size]] — “Smoke: Characterization of Smoke Particulate for Spacecraft Fire Detection” (text)
- [[Smoke detection]] — “Smoke: Characterization of Smoke Particulate for Spacecraft Fire Detection” (text)
