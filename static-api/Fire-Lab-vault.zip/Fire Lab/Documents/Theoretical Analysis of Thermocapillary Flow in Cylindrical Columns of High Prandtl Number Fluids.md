---
id: "pub:359"
type: "document"
tags: ["fire-lab/document"]
doi: "10.1115/1.2824346"
generated: "Fire Lab knowledge engine"
---

# Theoretical Analysis of Thermocapillary Flow in Cylindrical Columns of High Prandtl Number Fluids

Kamotani Y., Ostrach S.

DOI: [10.1115/1.2824346](https://doi.org/10.1115/1.2824346)

## Describes
_The source is a publication or note whose subject is the target investigation._

- [[STDCE-1]] (metadata)
