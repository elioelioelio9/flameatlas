---
id: "entity:space-shuttle"
type: "entity"
aliases: ["space shuttle", "shuttle", "sts-"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Space Shuttle

spacecraft

## Linked from
- [[STDCE-1]] · mentions
