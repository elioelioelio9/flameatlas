---
id: "entity:drop-tower"
type: "entity"
aliases: ["drop tower", "zero gravity research facility", "2.2 second", "5.2 second"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Drop tower

facility

## Linked from
- [[BASS]] · mentions
- [[ACME Flame Design]] · mentions
- [[STDCE-1]] · mentions
