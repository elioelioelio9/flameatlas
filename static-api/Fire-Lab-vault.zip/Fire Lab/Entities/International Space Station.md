---
id: "entity:iss"
type: "entity"
aliases: ["international space station", "iss", "space station", "station spatiale"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# International Space Station

spacecraft

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[SAFFIRE-II]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Quantitative Studies of Cool Flame Transitions at Radiation Stretch Extinction Using Counterflow Flames]] · mentions
- [[Atmosphere — ISS Earth-normal cabin]] · contains related data
- [[Atmosphere — Exploration atmosphere 10.2 psia 26.5 % O2]] · contains related data
- [[Atmosphere — Exploration atmosphere 8.2 psia 34 % O2]] · contains related data
- [[Atmosphere — Spacesuit (EVA)]] · contains related data
