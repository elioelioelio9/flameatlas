---
id: "entity:cygnus"
type: "entity"
aliases: ["cygnus"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Cygnus cargo vehicle

spacecraft

## Linked from
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
