---
id: "entity:mars"
type: "entity"
aliases: ["mars", "martian", "martien", "martienne", "martiens"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Mars

planetary body

## Linked from
- [[Atmosphere — Mars surface habitat]] · contains related data
