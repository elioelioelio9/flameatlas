---
id: "entity:earth"
type: "entity"
aliases: ["earth", "terrestrial", "normal gravity", "1-g", "1g", "terre"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Earth

planetary body

## Linked from
- [[BASS]] · mentions
- [[BASS-II]] · mentions
- [[SAFFIRE-I]] · mentions
- [[SAFFIRE-II]] · mentions
- [[SAFFIRE-III]] · mentions
- [[SAME-R]] · mentions
- [[SAME]] · mentions
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[SLICE]] · mentions
- [[SPICE]] · mentions
- [[DAFT DAFT-2]] · mentions
- [[Concurrent Flame Spread Modeling using Flamelet Generated Manifolds in Microgravity with Comparison to BASS Ex]] · mentions
- [[Computational and Experimental Analysis of SPICE Data Sets]] · mentions
- [[Utilization of the Smoke Aerosol Measurement Experiment Data for Advanced Modeling and Simulation of Smoke Gen]] · mentions
- [[Effect of External Thermo-Convective Perturbation on Cool Flame Dynamics A Multidimensional Multi-Physics CFD ]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[STDCE-1]] · mentions
