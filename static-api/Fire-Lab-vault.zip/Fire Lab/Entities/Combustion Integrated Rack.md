---
id: "entity:cir"
type: "entity"
aliases: ["combustion integrated rack", "cir"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Combustion Integrated Rack

facility

## Linked from
- [[FLEX]] · depends on
- [[FLEX-2]] · depends on
- [[CFI]] · depends on
- [[ACME CFI-G]] · depends on
- [[ACME Flame Design]] · depends on
- [[ACME BRE]] · depends on
- [[ACME CLD Flame]] · depends on
- [[ACME E-FIELD Flames]] · depends on
- [[ACME s-Flame]] · depends on
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
- [[ACME CFI-G]] · mentions
- [[ACME Flame Design]] · mentions
- [[ACME BRE]] · mentions
- [[ACME CLD Flame]] · mentions
- [[ACME E-FIELD Flames]] · mentions
- [[ACME s-Flame]] · mentions
