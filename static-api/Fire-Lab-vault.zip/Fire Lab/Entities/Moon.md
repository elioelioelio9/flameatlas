---
id: "entity:moon"
type: "entity"
aliases: ["moon", "lunar", "lune", "lunaire", "artemis"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Moon

planetary body

## Linked from
- [[SAME]] · mentions
- [[Structure and Properties of Pb-Sn and Pb-free Sn-Ag-Cu Solders Produced in Terrestrial vs. Microgravity Enviro]] · mentions
- [[Atmosphere — Moon base pressurized rover]] · contains related data
