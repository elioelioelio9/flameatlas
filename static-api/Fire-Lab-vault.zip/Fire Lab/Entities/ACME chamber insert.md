---
id: "entity:acme-insert"
type: "entity"
aliases: ["acme insert", "chamber insert"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# ACME chamber insert

facility
