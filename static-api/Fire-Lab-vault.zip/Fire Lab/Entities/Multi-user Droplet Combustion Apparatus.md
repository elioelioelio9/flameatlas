---
id: "entity:mdca"
type: "entity"
aliases: ["multi-user droplet combustion", "mdca"]
tags: ["fire-lab/entity"]
generated: "Fire Lab knowledge engine"
---

# Multi-user Droplet Combustion Apparatus

facility

## Linked from
- [[FLEX]] · depends on
- [[FLEX-2]] · depends on
- [[CFI]] · depends on
- [[FLEX]] · mentions
- [[FLEX-2]] · mentions
- [[CFI]] · mentions
